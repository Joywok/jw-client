import request from "../../utils/request";
function firstFetch(url,parame) {
  return request(url, {
    method: 'GET',
    body:parame
  });
}
export default {
	namespace: "<%name%>",
	state: {
		loading:{
			loading:true,
			hide:false,
			fix:true
		},
		list:[],
		firstFetch:true,
    page:{
      pageno:'0',
      pagesize:'10'
    }
	},
	reducers: {
		changeData(state,action){
      return { ...state, ...action.payload };
    }
	},
	effects: {
		*fetch({payload,dispatch}, { call, put ,select}) {
      NProgress.start();
      let datas = yield select();
      yield put({
        type: 'changeData',
        payload:_.extend({
          loading:{
            loading:true,
            fix:(typeof(payload['pageno'])!='undefined' && payload['pageno']=='0'?true:false),
            hide:false
          }
        },payload)
      })
      let firstData = yield call(firstFetch,'/api/list/'+(payload['pageno'] || 0),payload);
      let list = []
      if(typeof(payload['pageno']) !='undefined'&& payload['pageno']!="0"){
        list = datas["<%name%>"]['list'].concat(firstData['data']['list'])
      }else{
        list = firstData['data']['list']
      }
      let loading = datas["<%name%>"]['loading'];
      loading['loading'] = false;
      let noMore = false;
      console.log(firstData['data']["page"]['num'],parseInt(datas['<%name%>']["page"]['pageno'])+1,datas['<%name%>']["page"]['pagesize'])
      if(firstData['data']["page"]['num']<=(parseInt(datas['<%name%>']["page"]['pageno'])+1)*datas['<%name%>']["page"]['pagesize']){
        noMore = true
        loading['hide'] = true;
      }else{
        noMore = false;
        loading['hide'] = false;
        loading['fix'] = false;
      }
      let allData = _.extend({
        loading:loading
      },{
        list:list,
        page:firstData['data']['page'],
        noMore:noMore
      })
      if(datas["<%name%>"]["firstFetch"]){
        allData['firstFetch'] = false
      }
      NProgress.done();
      yield put({
        type: 'changeData',
        payload: allData,
      });
    },
	},
	subscriptions: {
	},
};