const registerModel = (app, model)=>{
  if (!(app._models.filter(m => m.namespace === model.namespace).length === 1)) {
    app.model(model)
  }
}
module.exports = {
	path: "<%name%>",
	indexRoute: {
		getComponent(nextState, cb) {
			jw.setTitle({
				title:'列表'
			})
			require.ensure([], (require) => {
				let model = require("../models/<%name%>/index")["default"];
				registerModel(app,model);
				cb(null, require("../chunk/<%name%>/Index")["default"]);
			}, "chunk/<%name%>/Index")
		}
	},
	childRoutes:[
    {
      path:'info',
      indexRoute: {
          getComponent(location, cb) {
          	jw.setTitle({
							title:'详情'
						})
            require.ensure([], function (require) {
            	let model = {
            		namespace:'info',
            		state:{
            		},
            		reducers: {
									changeData(state,action){
							      return { ...state, ...action.payload };
							    }
								},
            	}
							registerModel(app,model);
              cb(null, require('../chunk/<%name%>/Info')["default"])
            }, 'chunk/<%name%>/Info')
          }
        }
    }
  ]
}