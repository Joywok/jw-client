import React , {Component} from "react";
import {connect} from "dva";
import { Router,hashHistory,browserHistory} from "dva/router";
import request from '../../utils/request';
import LoadMore from '../../components/LoadMore';
class <%name%> extends Component{
	state={
		containerHeight:'auto',
	}
	openInfo(e,data){
		let href = window.location.origin + '/#/<%name%>/info';
		window.localstore = new Store('Joywok:cache:tabs:info');
		let datas = {
			namespace:"info",
			type:"cache",
			id:'tab:cache',
			data:data,
		}
		window.localstore.update(datas);
		// jw.pushWebView(href)
		window.location.href = href;
	}
	_init_item(data){
		return <div className="<%name%>-list-item" onClick={(e)=>this.openInfo(e,data)}>
      					<div className="<%name%>-list-item-c">
      						<div className="<%name%>-list-item-pic">
      							<img src={data['pic']}/>
      						</div>
      						<div className="<%name%>-list-item-info">
      							<div className="<%name%>-list-item-name">{data['name']}</div>
      							<div className="<%name%>-list-item-creator"><span>{data['creator']}</span><span>{data['update_at']}</span></div>
      						</div>
      					</div>
      					<div className="<%name%>-list-item-other">
        					<div className="<%name%>-list-item-data">
        						<div className="<%name%>-list-item-data-label">目前状态</div>
        						<div className="<%name%>-list-item-data-value">{data['status']}</div>
        					</div>
      					</div>
      				</div>
	}
  render(){
    var self=this;
    let data = this.props.<%name%>;
		let todoHtml="";
		let loadMoreHtml=''
		if(data['loading']['loading']){
			loadMoreHtml=	<LoadMore container='main-c' data={{
							hide:data["loading"]['hide'],
							loading:data["loading"]['loading'],
							fix:data["loading"]['fix']
						}} onEndReached={(e)=>{this.onEndReached(e)} } />
		}else{
			if(data.list.length==0){
				let strTip = '没有搜索到数据'
				todoHtml = <div className="todos-null">
		       <div className="icon-todos-null">
		          <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAAD6CAYAAAH/62qrAAAAAXNSR0IArs4c6QAALWJJREFUeAHtnQm8HUWV/6vfSwKERAUkLBJIIJAEBREHUARhRhQFzYdFREFAFoFxdAQRJIA48mdEZVBm3BA3EEZAXAYVETcUlQwBjMCQlwQIhN2AyBIIeXl59/+turfv63tf33ur+1bvp9+n3+2u5dQ5v1OnqrpWpXpctZoa6BEkWe/aYlVLMoXe0m2gNojCAIh5UcKr2hI1O1KEHoFB7PNJo9aDhZx514bURd1YmtDNM64fiW5C1n1Kx/fmds8TvTNhBC7Q/dFG/43EbaI6QYBEryexAwIJLuR598B7x8doJtORjFIwsQiw5xJkHvDfqIN6O3aHvwu5/rww7alGFf2RiRc7u4SH1P7xWI4RC4jnBaPVHo5YXFO/ZIZUkPHIz7Wlau/IkVxHALrra/epWa7p5otetwyC3+Nh3HaLExY+lls6iQypGe3ckfAn293C3mv3qu3C3CO59SNlP3EjMZlYYBfmFVUNrQ2SYXVv39KtVfdFodHaIBlUu3fSY3vd3imcGlSbxmeAmO0JdSLWKRzF9Ss7xQlzb1VBWIiGW1Di4HOXKFZe1gwEJQ4+W6XSJZA1A11o9OWVOQMtrWI+KP5Ci/a1fYnkqTv5GNmlLxq5iKxzusvcnrhQqG+ddSKFksxaqqwD9kK1tdJxxG2vRP1knCYekuhOfkJhvy0FTVgAG7eWROdS4TZyfK86wUkx6ydifqOYmo1kUcNoJFrQCCFAeTAjxDmeE4mdz5fwOfFiO4hl2+sJow/q5Kx1ToSLe/HnedZ9xNsA+2W96DX9g73fRLzL9+ilWz9c8NePYy05kcfMskbdz6WJ+Dk9SLzXc5w4hqZO0Oe8VyLib41AXEjjxBuf4byxnOxzTO6+33/u+OupX3T0y71HHOiCQkWN3wq7p+4IEov8XCTom6UWmepMJJ1N6fyBdonDSqRQiD31KeKvIfzn2ml0fW8kHhqmPaH292Ak/D4RfO/23KrzDiG15DD3Ke0N8VPDkOgQ1c65m+R2FOqhnEseJfEoYa1gj0IwSthmbteRumUkW6LO80O3hF0w3I1+kn6Zqj1JwaxoY+WXa+3VlqttrCJkFAg+b8ooaUm2dAi0lLZFkM58Qgb6I/op3Z12ESUBHrb+ehprtzdpDzWf+n7IXWlP4fs5UwD7n8i+4J76Ol/uzwYl7kfrmk5uNN+pvaAFxO/zaP/0oOAA8UjLe4yX3Nt8N1BiyJv/KNj5c5rL2v1qa4T/m2uOayvVFNc0ndMDhKXOiaZFUGdZBPhrp6zbzodtuPZ4tu+Gn8fUZNvwscIh8G/DIiYtXFiavpsRvK6MI3y3zH/TBKT2gNo8FYFrK9RGjJG0VE++oLhvyfMLqTCSh0SizkZJg2freh47Xk5DY2biTHnqSWZLTEs8HdsEmAo2nWy62Da8Hy44juW79foF5BtcTD3rlY61v2+rNhFg/sI4QgdpR0kvGM/5c1aMpJFu1686k/089WfniNoQZMQl6qxJG7LWYdJAvxszmaWfWcJtaCTJR2i2J7ttyvdyNtm9TXj4+AWF6Ix2ZxfvocKrEXU8s0JOjpIAGrqY+73d4iDEobTujuwWZpzfgDqK9sXh49wdODjryaHH5RSdRanmrgmbANPoePxBr7VnDmSyJuFMeJ2i36cGCFfzOqYtT80HkM/qIDpcXi6nwvtCAYLO/l1NwA+b5W+4zWfJUYppdxJ+hRpVB6bIR7ekdsNY7ukWQPzSRIBqazkju5ulmaartDpl9570EfrT5rv+JfUEz9/pGaFMAXRdXiZ5ciUL4C4iR53lnCnTAsup5hoNI+cya4KxbTwRbtqJDqjPtDvJuyAgCFQDAUr6/+6nOk3kSy1J6BH4TloPO/fbgiiM4Gj37wD6ihaBB9XRcUHOVUdBmBBoeBRhg3z+hnBv0WH9jpCweL3ccqvxpv0GG8UbMy3kabWql1A2/rkTvClwG/dauy1+9ovd2ijVX3MjeItQQVYRkE7LgXH+c9T6wWBRn3PRZKUrumW7oqYQA+qMUKEJQGfmcDNcjIdgoREjutsodEtPZGGwEcgvuMZpupGk7x+Xg9xkdS0AWlyrf3xhEPp6/7nl11M/a3kvywtV2IvtsgDCj7X2O+WA9vDd3l3Q6EY/th+Mmb2SjKA193N5Afa62MwlFRFhm9tiNQSflFRauaWLZn6XW+ZcMqY17JJeJrRMNtWFUWC5Ri9G+p1k1I0+fNyVOLAk8Hw7E70S7eXfTi/Ke22Z2kXT9+8oca3DQvz31oEbAdFGop2K5KTBRIXWcugEOgmO3yntfkkL7afHJOD1NQD+e+a/RR17CwWuk9bR7rf9CHyYHOY/l+o3THiymvk2CPNLW/jmB0ESCZvqSVdnnroK+ltg/fv2+1WVBJ+J0syDlhMVsCjErbN6WhrLlSlQGv8JwV8TR5vEfcQ2nlkHszgn00w102lpO820EulsBKjz0fRJtprOZTiEuJXVR3PSYo4N4TcmzexnVdtmcx2OenuiC4Bs0+wnLWe9rLkqjS0Q6Wrj2OkdapLa3oKO2yBT1SaZZvc0slwnxJJOu6vGOzFVBveOgoP4Ir6l+t/jPy5KWWX3pLOaDR5J8tBR4zaMFTlMqOCZZ3Mf0bSze5JZzJfJ9jcpXro2YKIm2qsR45qeLXhh4boK3kuQIEFboaLQDNJ3/Rxq464TySM9d4LPVRO7aV375UXbWhHOBGcaxwi9qV8PE964eRHXmmaRTcKYj8KHjh+8o8RtD9svL+30/PeuhZsfKOpvnrJ0J96dZfVOCeTVXQTPq2aS4ks0nhSyeaUbXqpPVZOTqkYiAxHxuOjI9LOIoMfLAfirWaRd5TStB0xdg0Tv9duYK2BOT27Qfj1tn+wHUVwLmkN6mSgdC5/EtPw1ATweRuFbB97lsawIsPHUVlj8F8oqX67lAvgbzLd0/bCcXPOaN+bATS8DNZc+Dh0sx/ae9z3y9guTZttlo3TdkTKkjskbj3nlB6wWtPPGzNWvtLvl8p06Vh/8tGcumcs5U+A2H4N5gd+buEdrSe8VnnM8hD1BQBAQBAQBRf3/Rd2WShuK8K7ItLmoSHoo+FeIul9T3FGe6PZtvqf0IEpPCGimaW/ASlR9os70Lkn81ZuuVnfxT8Qrkx65RCTJmChF9UwK6iHu9WxZyWrIXSzdVkNt4VDy29ms6oamsy6qw64BdRDh/mecl9cy7jDOO0kHsXRLdPkG/zhWfKFVcE+tZG+jzajD9bY/oQtbsrJyzb9YegctouTvoOQPNL1t2tie+geUfQdxH+jaKh+IeJ57kwk3D2LpDRxR1EKUvFsMWBdjta/W8aDxQ2gc0otGllaueRNLb2gIC93dV5Y5QHyNuhsFTvXdxv1OUlt7s9TD2h1ln0jYr3P3vgazP5pCLL23mkwIiutv8bA1VvpWPwpuekH63f67zW/WVq55FKXbaKpHGI73fTlNtiuw9Hd1DTqg5nhzsjsNlz2j5no78Fkplx0CjJW/qr1xxmfb7G6x9ZnMFP0/0PH4XdctbJJ+hg9//cGQuizJtEpDWw+XjlP4kHqXUWYDzCII6w/7VnbidyQlPas+FFIXH92g8c4Qv0jk0wrsbTl+49i00i5MOuZoYN0pE3JRXI+EOOfGyUw+zQ03jhhBKL2f48Hcp1LfHq7fHZE2ZKivz0Cxz7qkmSYtU/UsUW9KM81E00IZb+yUQEPYzt/XnSIG3KH/DEr/YsCpMI+00PcwGPgNN/17b+u2IYX4ZMOKJ/ChsVbNVYMsBe40tNFUDEr7I59Pq4Pf1E3Pkj4g84XIHFoVIfJCsNijUKI3rHdmFKZNnKXqlbZxCH8fwD1gGz7P4ZqWPlTgb3KEuNlYewSkzUIKfYp3jwtFv8+AlMBpAD2STtQbuR5LNIE0iKMYPc040mbfKN56QkMaMkgaMRDwe8VoZL2nV3QyyFPch7aHw+0XxrJZUtXuJ+8FQAAF3sj9vTBWtWKD7kbRFOVBN3kuOALU+RP5XNlWDyoYBS9R5+FWiK+TgkOfPftY/oXc87PnJL8cJGIJ5ryNNeodiJ1eQ8ojrVH1n9j2yc7g9tQdDIXmfxVqRIGdzpyhWN2C9H/IdgNvAPxTeV4TkZ94wWuscR9VK9kN7p8h4C4jj6rfI9NkpjbO8rZX98djruSxTF3a1oBKUmRTj9NKTzSNRndmkmmkTdvZ0Cr16ALD/MT6JMGkBNGzVEzm4hBsfcgmc9use91i8cQevDoeacp+OEEAUcTWDUVEmi8WpNHrmUz1HPdI1J65XnRt/Em3vlNH28CFTdzShkmiWAfo7zUy0h15AC4JGfMgVyweUM5tDeXsEItAQSI1zo3R+9xWu5g3nSH1hs6iguiuLzalmAe+KhZ5ZZA5dusd4evWneVhLn3ZbczIVW3NM2FwlsnxRdgzLaZuu0WrZDFfhiKum1Jt/IqMQeTivbLFentOqEoxX/VivV3vlSjmEXJEF2vtwlf5vYjFvPUoGwo/DXUPMoZlVmbyfj/v2yai8AlqRxerK5kjtyMTp+9JhMfGFiPgsTM43AUeH2Ec4EuJpOWYqLXSSbe+d8qA+qvmAQETOXcT8BawYGgxVclmLPpfGVdePRu2ofBLmPOth1yTuQbU42Y9ao0h2IJckRtyics1qD5h0lirvtFXWiPqmyb+JPWpvuiUMHLulE6xfjNF5iMUmfOoL/2VoZGgp7Q4gvj7E+nn/ZQWkRItUODcKV1jR9UxHcWfxOPlpqGkd1+0uBh21Ysaa/z9N/HfRLF+oEW0ygWJUqenCg6Kv5QEL8VqT2S7zRdRpn89gUIv5X6IKVIz+H0XSn6t8dQba0xUuzK1qRIDQD4gUX9zq3RfEF/5/rv+ZbGDbjFvw5yZa7xp6pNBP3nujUDulR4mAjNU78Jd33LFQCCXdXoMOSRKBARE6RHAKktQUXpZNBlBDnul12hDK3UrCwoy2w8tglzpBR3g+6FgVySGzTdwwQRMi136BCJhmRZfuUvHbLybO67Kz5B98Z4EFmvUn5IgKzS7I5CZ0msPqPXpYNH7ra7ozqL4ukYgM6Wrl9SqhjB6SdSDrgUTep0RSL3xwTj5NLbJfgSW6uPzPm8edj9BbUC/eTrLm/10K/ibuqWboU5PfbkF6wG1LX3sA6LwFlTK90KR/i/6E1DvwVo+6USijggwbPpiR0/xSAyB1Iv3NkkOansv3Kse76fEWsvvUr0zRiEEgNkZDaaf0zNPCsF0TpgEu2u53+mzw/OjWWya4Kdv/Wvq1fpy40zPGbFmOEcBwe7BdnZwy/369dbivcZwilz2CHhq2bjAntp6nFvOHLSSXwjwdEngWR57IVBT+waDULx/kPdjg265fWZhwKvN2WK55TCfjDVm365B2bdwP8P9X/nkVLgSBAQBQUAQEAQEAUFAEBAEBIH4COil1HTkvMCA05bxqcSLmfp4ejw2yxOLz7qdkGYRswdMl3cWEyoLuaypiFkAZe+Lom/iHru8bCaMiNLHVJDIkzlZalRd06JsPyUvm8WXUrz7CnD8i2V/GEV334NGzxbS08RSvsTSHQOOsj+NGs+1UWUWCtfiitIdKZ2W+NcgdbKNsk2SnrrTUdKRyYjSI0PWGgHL/iGKPqTVte3NY1FHre0s88GOJyC3RXb/KnV6TEyx7D8Qda+u0T31HMr+DmE+2h4ui081nwexdB8Ji18zFWqJuhtFzrEI/n3C3Uy41uneFhGTDiJKt0C4tlJN4SCwezmNfHOL4PpkuH9kDtJkFnVfHxreU5eHuqfkKMV7F6BZb7c5y6+WYbFTuwRr9ZrLSZCc94rC/9LqEXib1N9umAFKsR5F6SGw0aEym+3K/g+vKCXhCurpGfq4bxT+SAjZplOW9blmQs+Rk6uBAC3xPWmg1VD4EpzsFe6pC4zCdTXQQ+HQzXyBh71gJc4aKHt8v7itvANqDluc6YUOg9T5eouW7teAOqt7gOR9pXhvYIzSPJT2e173toLdU+tYdNk0GlNCWETMumjXLErx3lCU7hJFIW82ShlQF/fQ38I4Cu9BMzVvUXoI1BTXpxrlD4bsQj2gTsBvDz8aFm6/nt7Lx1nsUrz72uvyq9cFcPDAHZSLW3mzx47uRuFPE22jLlFbvTy1LyWErkIyvUTpMeGn8bc/7fyfEH2SLQlTetgGTjCcFO8xwcVib0SJ6zUUeQzNQPtiPmaa/USrrRgrkUTplkhSlL8G6/5FWHAU/10ywfomA3jqSDLAS+PCDTSOFxnnkZLDi+oB+D8tpdTKkQxKH6an7mRfGgC80n/u9Evv3OGE0wcU1IKW1il8Uu7wcIvhQR+xtmysEZpUeqWgqxd3atCCwhgQtTI5mivontdn+Mxs0kZeMenKF4CtxMo/GwzUVLpWPBYd9MvjM51PUpXbKkbvbNlu5TpuU+lDaqEtLQlXEAS0hWDp+7Sza5Q+xNCMXNVBwCi9oBszSTnfJZ+i2F+Fedf0OXHMjqG/Xg48CAOoqG40zt6hrTmMfzN9KswjJ26mSlqqdu/ETnNosFOAvLpTz+6ASg4w/E2gd2wHBkZdXuvUzyEXuqKUs+D8HaxdpuiO1hImZNanXJejmx1l/7upT+vfyM/y/Lh5D2lsxUWRNG7kLmSrHCufEMBnQVwMchXPdJR0+ObUPWYo6/Z+GIbGlhq0fmhkGRf5X2oqvW4Yd7fzU5iGnBGE1rK3nXqWBlTopxLj4Jegrp0R/Avtglq/j6pHaaQdah0+RwHB6CHkX6+FpRpjBlr5gQGXQpT5RhhP3cegxj+1CNThRQvZGP3qEKJczhTpen7eaqQK35B4kBlBs82KnOIIrpUYhVvC/xlr/7dIcZaqveh9e0WUOHkLS9V0nsaqeQ8V9JOSOlyf8RJN6UvVnChxtLINUA+rjfOmyKj8kNk/2FR6LXyCR/7r9HVmxulwFOEpyvS8dftrtfo7gY/xppvpT/bxchiSKvAbsPUQ9wraPpFwy5U45N7I3+AUdeNWioYJBe1RLCN8zVlYhAK4Ucd7Mm7eQVEo/Fzu5R28xTlLBEy3YtR6Xc9glSsUgfzX6bBtvss99VuK4d7Lhnwx15oFiP5byy90VmHhH2txlJd8IoCilnCPn3QYwq5uwbY76w4K7c59a7ufvOcYART2qzCFBlmmEbMfYVoGRcgsl+l4NPCODYaV54IgoOt4zSpKXMMQ6LgFhyh4COWe7YvDuz5V6a/+u/wWGAGUfiDKXGcsuDF1ifcLzLu26j4HXwoMTTVY979LUfRVRunSeq+G4rWUKP1F7pOqI7FIaqYmCwyCgCDQhkAi4+nUqW9lIsJM0kqEfpsM9dcaG/EqBlo8dVWof3TH5xi8cEUreuoJxnCqFKYGb0yf2d8S5Dd90p6ajfKXpZ9wcim6nQ27Sn0RS9NTmS7n9zZ+x/WKORelxtmmNTWfuSN6f3WX89BnIMkn4FcP0xaiu9o5tjYE/e9jm7AuwtTuU7NMmktMVeKCZAsNaA9r+i2OJXhxloMB5xSDh6fOSw2XYfVHpli8jgmRDySS5kD9049PwPmJ0C86UYDRkxFSsYraY2pyWnhpmdKSKy2ZnFk66nbaKOwEAJnrWvVMy/HfnYK6cl/rilBe6DhROoqoj0170WagRgGBQZZJWNxaMtcBqU5vliI+XE1JF4E02KY10jg/nINkXZOWL1nux1N3+8k2nn5fLgyb7sbM1tu8WWolhFKpPjowrIv48IUEHSLk2bnv4p2i/eMNAc91JajeoRG6I3x1L+T3ja7oxqYjRXwrdK6LPp8ekyCOb00p2zefr2y5cJN6/op3T+1Jt+cCN+I5pVKaIr6v4h1rPMPA6o1NTeoX5pwqXHfEmo0DqW6q3VFTpiLPJrOWRd6+LN0GqJKFKUVHTWylN4s5r0LF3VgRf2bJMrOdOGUp6uykHQtVBrljW/oYDJV7KnwRH0vpFO1nNVRdvWJurIivViu+DEVcP+VT0eWPZen9AFaSuIUu4iMrvdJFu59jq1bEF71o8/XW72+RcYhs6f2CVaL4hS3iIym92SGjVPVa7e25dayILzcWRS7S2nXm4r2oeESydBdAlYxGIYt4a6Wz/ts/iqrcxVmUXFn2Ip763Oz4EAWTKoQtYhFvP3MmsMe63pGQPRxDt992oOhFTHHe1QEdvUHBEqZMz3ZBaxyNuWoCW525XDs3LomkHKyL9yADCJvkSpbXoaxLg+nFeYbG5YkpnMN0i6rwSFimVYy5SscVnV4gpZVOLz6i+Mey9CgJSNj8IVBupSdbDeVPm5Yc5U/pnvqp5p1is7702VKQYDDiHt14/7eguzxHRCCtuquxULGv5cFp8aohTDOtiCrrGDx3lk6rWJ9GYM5EowV+U0fOO3ighF8bL0/9uEMQcbZFIO0c7aeH4q+LwON3G/F0xknl8vlMJTFHidh3zjhK0JrMXHPs1Dq+teeh+NVqfbWRNzN822+qBH1E1TPQnsI9QufOJOt0Khgwt0qnmNc9fh6WtArFb4jaV/OsFyz/lFsX4c/j/jbu9wZOeFmIwveooB4jiWy95lsXY5pyqrtANEQx23uvU7/htdMa8SFse9/GOvZGrHR+ssQlroS5tfSgQI3TA02RzRlqm6s1akcK9L9726tFwXDybIdAIZQeFIV6/Qne9S1XTARy98kWUw6JFgEBUXoEsMoSVJReFk1GkEOUHgGssgQVpZdFkxHkEKVHAKssQUXpZdFkBDlE6RHAKkvQKJ0zcj5pSbQeRekykFFBpf8PMh/kDzCURH5XYlzhilAadKzrdEbXDmZI82zul9JgrCBpDIPHfLDx5+QVhO0Ks8nkjE+zRm+XCkMgogsC5UaAvYyP1c0TjH2E7eVfV25pRbqqI2A9WapMQGHg5yPP2W0y3cPm3m/jhLfH2tzlVRAoPAKVMnRq732Y26k7G17RUXP6e9TjgNXZ6ksJr8fuyIJ4CAKuEYjSBes67dToYeDvJLGLMPIduibqmXn0/87ZrZeJkXdFSjwLhkClanStG77Nj8PgL+UeDOjqBWrxXTkvaFnATR4FAUGg6AhQy1/V6Ix7ivUy6xddHuFfEBAEOiCAoX8Tg9+3g7c4p4wAa80HzHrzlNOtQnItTffaShbzP8dq0O3U8sa68FJjQKby5Fs8OxVTyG7CJ9TVcLAft16CvoCRjzW4vYHnA7jvYlH6u1l6fh/PcvWDALXaFgD+lGnG6nHl4D2k/qMf2hJXEOiEAH0l80xeW6Le3yXMP5I3R7lP6xRG3O0Q0Du5PEjQbToGH1CHM7b8/Y7+4iEIxEAA472DaCvoAD2kW3Ty5+fw/xBTTqd2Cyd+3RHQ857/t2MQvaHqBPXnjv7iIQjERaCmbiV37dOzI9RT+5NE5zwaN/0qxmObrt0pOe8xTan6tNAXKXEv4Bu2EuPsVdR5HmQmj53LPUoz/ou1h9UGPk+6Qw63M/B7iTxZqBVDvgx5+23pjMsbc8JPNRBgYdFcDsA5Hml35h5kToM+budKmvULqoGASCkICAKCgCAgCAgCgoAgIAgIAoKAICAICAKCgCAgCJQcATYc2ZRe/fMZdTqo5KLSvymXIFARBGr3qVlqrTqDHv1jELl+Zpun/o/e/Z3KDoGMk5ddwxWWj2G7PdSImk91Ng/jrh/eOh6Pj493Kp+L1Ojl02llJaIZfiDmfA5GrRfF2Fy/ZmrtW20CFj2M1OhF12BF+Wf23ES1lAUxo9TYSm3fhMEcA9t86/4wqCpRm2sQxNC7ZwXxzQkCdJy9jNlzJ1Nbn8Y9LXBkdlwOr+Sw3jvjRi5aPGm6F01jFeGXue5bYtAf4z4ZkTd0LvYGaguvfiizc9J5JCg1eh61UkGeqLF3pEf8TL6xj8C4B2mSx7meIP5k4r+sR+QLq2TkGgup0XvkCPFOBgHGrvfGmM/GKPUy1PiXXkqt1Ge5t+bpyJ6EPLWaHQI3xtArdcyU1Og9c4YE6BcBOs4GWI92MIaoD82on4qzrl+q6h6qqUOgeTiUzotA7ZyqGbnGRmr0CDlEgtohYDaTWKOOxQj15JQZdrGsQo2QY89kgstFrFU/ghhXQt8+D3vqceJuaZVSyQJJjV4yhWYhTm2F2ki9qD6C0X2U9Demcez6utVsErm9eoQm/14Y+Yuk1dyoIkJilRlOa8fEvjRsjynvlUWgtpw9Bteo0wHgeAxu/USAqB+N9SH2K/yOpm+mrw6rP/K4Wcz0FjE5ZteYcQsfTWr0wqsweQHM0dLr1FmkdCiGPZBoN5anfkU676OJ/TctGVtMbcxBWX9Qw/TK93MNVGdyTBhMUqOHoVJxN6aSvpUvX90jvk8qUHicJjCgjmECiz4A01x04E1iUsz1vOzXcOrn5+fU5gf2Q6DoccXQi65Bh/ybDRpXqaMhqSeqdD+Q0kW6nrqWIxyO86apVUFyFDTf5F3vIefmmqB29HZwMJfODTeZUBFDzwT24iRK59duTD09jRr+3Rh/8GDKeEJ46klo6bMCbmonQCfbmaRxQbt7n+/fpjZ3V2j0yUxW0cXQs0K+oOnW7lcvZwbbSRjkv3K/yloMT32DlRUf8banG6/tYrrrYdC6mlufM+Du8sz8umn+9747wsWjJIZePJ3ljmNq/bdgUnroan+MNZinHsJ0D6X2vj2MaZroejnpr7ndz2XXCXrqMxi5nqRT+SuolMqDIQC4QUBv0cReLk9zgGXo/Ddq8JkUCH/i3sJNiqFUVrFb/MbwsDbUt2KObptKFQNPxA1HgOb5k52MXMeghn+AmnZLtQETbTz1AW7duz4cTi2mq6fOEiMfw05q9DEs5MkhAgyP6Tkaoxhb5HVojbXnevunw6ChPwfWi8jaQ3TAbRMxTmmC02I6B9RnBjshxdBLo978CMK393fh5ijuhWS2PVxxVluppjCN5l3Q0wXA2ykAwqfBDqjDaDX8wFW6RaFjCsi16pfwO4a5x9Hnc8xkp6KIIXwWAQGM/PPcNYbKngoenOjzTmZcz/gvVsP8XmzmyfueMX9rT6gNqcXeQ5rXcv82JpnCR9NYIv9vGvhqHXzQF0pqdB8J+e0bATLWfGrZz/DN/byarLbxtlF/bydKD/3udNHd2u5OnCW4fZRvd10jydUHAhj6wYx2jNKquc4nI3PdfSTkty8EMHI9m65u5IrvwxAjNwmsMyemhqX1azHyMFiiu/G59OP2WGLo7YjIe2QE9NJRaumLqJWfpSbvbOSasqdeS4EQvJ5W66tdvW3ViqCjPAsCgkCBEaBZeXPgG9L1dNcCIyOsCwIlQoAm/rMY+hPsQrN5icQSUQSBciKAwf7E1MxD6hZbCYkzg1uva5crJgKMLpzOHIX+FxfFTF+iVQQBvU4cY13aaH5fUxGxcyEmRj4vLu4yvJaCCjEOPXi0D51Q7+dJL/d8ecdkPbWSLRf28rZT93YMk5EHK9e2Zu3ZPSQ/hfvD9O5+JSNWKpcsBq7PiAsOPa4gn+zuzSK/WFxi6BYg9RuEGvAyjPsYjPxx7mu4f0kv9V8wlMd92mZyyUvMYRpRIwwz3a3dTQFxL+POU9Td3pZsiJjhRW1yHNMqvwXv65jcuhvz2RdlyE6lktbNdbD/fKjQHp9Ok9U7Ow5nNiKJoYeiF98R45xI7f0lKLyAwZ4WnxKGvthsZrgAGpMwsN8xDPUOL4ODByiorqOgmgcPj3LPZSLG8/3IJXHtEGDY8lUY+G1g33uVnx7arKljqTzGjaHr1GT1mh3mVqEoed/NhkXDAH4SEZ6yitQlEEr7M/d6aOkEaO7LNsrPM4X01V2iJOX1cwz8RAqurcTIk4K4TpdCdRPu+RTyq2g7PWJl5Dpq/XPwR8R9jPsyColXBjmVGj2IRh/PKOa9RL+Ke4Q6fSZN20f6IDcuKsp7Pcqsb+AwSW3Pt9l94wKJQykQwEjnYOTfQJi9egqkP6X0QZRz1bdYKdg6FalnZAkQCQH9La1LYO4a9ymRIkcITIvhjEYayyJEixSUNHYmjRdMOkvYLkquTBFAH8dRyI809K7zV/D+ZKbMVS1xFPHGhgKGk5SdAmWQtF5qGOE/uUzLFFZD6meGNieh8IlQPyPNZSJCKzYC6P3LLUa+VB0Um5hEjIeAPmusqQTdgZLgRTpXNIzxAlfJkIk+0uR/yHQkuiItdBwiQO3+fqOnJZEOlXTIgZAyCFArFmqREAa+JxlHrwvXa5dv1+u6RZX5RgA9/Ydu2eWbywpwZ0pd/S3teuviBLCD16kY+dHcvYdvEkhfSAoChUWAEvcLjRpylN+DXQsCzRMa9C+KShvDng1/x9QeY4qFXJVCQMbRHaubseaPMeb8SgY6lkP6Rxil7sHW0xfdXF7z1JEnbQjqlgXGfYEuHJh8oXdxuZA5dlvaxJUwgoAgYIEAR/1Ow8juMjVw/Tv4gn6a9HT6vSJAa6duLJDu27gfDoT/OmlP6hZH/AQBQaAPBDAwPSx2EUb3Ar9HaFLGTU+XjXA1aOiOs1+GRYP+wdz+eL4OdwP3jLCw4lYtBGRmXEb6xiD1nOTgWOg9THX9GQ3sP+F+C58A5nxwnz2+r2fS9NafA3o7phMJtyG/fyDcHc0w+oSUtWyFPFVd7U1XT/vu8isIiKHnIA8YI1bqSAx5X9h5A7ce5nqGaY2bMnf+2zzrPdLbr6cxdH22WOROuXZC8i4ICAI5QICC4Cu0AHRTfGk/3/g5EEVYEAQEgTAEMPJzGka+Us/ACwsjboKAIFBwBMzJJssCR+wUXB5hXxAQBBoI6J5y7v+ShSWSJVwhkPvOOLMt8Gr1NTqe9OmaMsHHlebd0FmIXk6gQ9BsfeWGpFBJAoFcGzrfpl9F6H9OQnCh6RSB69gJJzhU6JS4ECsxAnRCfbTRCaUX3d/Meyk3QdBbQ9FMf6oh63KzT1gB9Aq/pxqe9WhAfURgfgHYriyLuazRyfxbsSHTQzTV6/yxWTLNw7ll0hLDZHoL6CXIuANPT/JR8mZvtpmLXhgxKaBugP+3NxmWLa6aUOTtIZ/rp0fU95tGrhGbwKaLJbv0/l6s/96VmWyjzGJbXUjxpjDJ53n1BLzXp/IOozdldq4tpDhlZjp3nVu6SYiRv7EJuqc+zUaL+tCAQl/Ufh/mXs39W18Qb3O2hC6qkSOEmWY7YHa89UV6HfJJE95HI0e/uWq6s9prOjXcikBtfg+dPK/JEV6RWOF7ezf26NQ7w25nInrqp9R9J7CDq9XpGpESyzAwxi1N+Azxt0k6X033YXUtTI8VPhNYoFGwq7ZM7YJxX05htTO/Whq9RfNs+hiWFUwUe3alCW+PVdVDUiuc1taLe27RMKETcVPkeBQ57mOU4E1F478ffpH32Db9SRO+H0DLGLe2XG3TlknuyrOceoN9DPoHTZ6XqgPyzG9avOkmfBMTPeR2b+OTJS0GJJ2OCOSj6b7GNNnHmPTy1WQnA+vOwdO5DzL9B/UmuV4b/j4G/a6REzIaqmtvwq81et214Ss/VUaAJt/pLbUAq7XyhIc2csPfkLqTmvwoxr/zUTjmCaQAL+jzuBZ9Si98AJ3sHsc6vjLggUwxtmuKTt9Td9JptUsGrEiSDhHQTXhaPmMTaSaqWQyR3u8wCSEVEYFsx9FrbU32SflqskfEUoL7COgmvGKg1L/qTXj/TX4zQCAzQ6fUP5NS//VNmT11lredurf5Lg+FRaAxkebkgAB6Is2ZgXd5TBmBTJrupjd2bcuxv4uYGCOdNikrP+nkpAmfNML29LOp0dubchOlyW6vsgKFlCZ8bpSVuqFTyp+F9MEjec+Ujprc5AenjEgT3imcfRFLtenOXPZZajjwHe6pO+hl/4e+JJDIuUdAmvDZqyjdGr0+l31M6kH1nrEXeSotAtKEz1y1qRl6o8keHCM/09uhcfJI5jAIA0kiIMtZk0TXjnYqTXdpstspo+yhpAmfnYbTqdGlyZ6dhvOUsjThM9NG4oYuTfbMdJu7hDv0wsty1hQ0lWjTXZrsKWiwgElIEz59pSVbo0uTPX2NFiFFacKnrqXEDJ1SWzfJpJc9dZXmP8EOTXiZC5+g6hJpukuTPUGNlYi0NOHTU2YyNfpa9T1zKIFSN/O7SMnEmPQ0WqSUpAmfmrac1+jsLnIw3P8oIMG5rEz7f/67OXKoxnrlUTXVd8vlr8dZMR6nxQyoxUzsuTWPPLLbzQBnu+wHb3q57w7ck/LIZ4Cn5+H4a5xIc6fvpnekIS98y38H83lMi/5p810enCDgflskT01DWT9hrfkzcPiMWl9d4XPK8tSXsR3BI/57rn9rcKfvUX4W8+upx9lEancW4GTOPzhuBY63qyG1Wa4xDGNuVJ3ICTVT9eEVxttTN7YE89Qc3sXQW0Dp/8W9oSu1EcYxr8nasLqS5wf1O0bynP7hG346RpTvGn0dZj2qdoTf73JPhN8tMC69O+3G3JldphYfMme0bdhg4iE4fTtF6EPwR7GU42srNcxGmnprzeC1JviCBMl8TrYkUr2XJAy9J4reLPVwz0D5CHAXHUaHYuT+2W8b8b4TTcu7M2NviVni6xu5bml8jU+Locz4kYQLgYCUnr3V9L8tQWoZr7jz1Fta+BlUt7S8y4sgEIKAGHoIKC1OU9RXeR9uunmcKLOCz5MMLjquptK0bXZsUpvfRm1+cwasSJIFQ0AMvYfCmNyhjzQ+phmspjZQL6oFzfeUHsy3eU0tJLmxnnVPnZBS8pJMwREQQ7dQIMODV1N7/mszaE3N5lv9mdr9auumW4IPHFm1GV/hj9FXoHuk69eA2s2bYzoHfRf5FQQ6IiCG3hGaVg864L6k1jNj1fVhoZp6uVqjVjD09k1q28HW0G7eoOtRoFyiXlJPQLE+lOYxvDeoNsXI9SmtcgkCVgiIoVvBVA+k952ndp9C7f69QLTjqW1HMMhbODJ524B77Ec9qYgC5HrojlKLn2QIeWbo7IMUONOZcPJUbOISsZIIZDK8VnSkMTZ9EsmRdI6dh/l90shT4yDGEXV/Y3LN3ygMrsBIv03YnkNxZm3AWnUUdI4izsyWkWaP+lypw6DzM5OO/BMEYiAghh4DND8KzedzeT7XTABaqy7GSA8xfjW1Cc+n8HyKMXw/QqffsT59P4SeVXg2J7VewgSTfE+C8TmW31wjIIbuQD2NCUCH+qQw/GnMUnsPxr43Nfve/G7h+7X8eupR3pdy/4X5YFfTJL+txV9eBAFHCIihOwIySAbDX8n7lxt30EueBYFMEJDOuExgl0QFgXQREENPF29JTRDIBAEx9Exgl0QFgXQREENPF29JTRDIBAEx9Exgl0QFgXQREENPF29JTRDIBAEx9Exgl0QFgXQREENPF29JTRDIBAEx9Exgl0QFgXQRSMLQ17aIMKomt7zLiyAQRGASW1sGL4/Jw3I5R8D9vu5DagZcLmd+9xhtz6yd1htCjjiXQAgWGQG9E/Ce5JWXNYUYUNuyWOiB5rs8OEFgzBidkKsTqT3Mlsir1O9Q4E4OyQqpMiPgsVvOJPVm1vw/W2Yxs5ItEUMPE8bseaY3J5ZLEGggELLHu2CTEAL/H+5mDgIT6DkqAAAAAElFTkSuQmCC" />
		       </div>
		       <div className="desc">{strTip}</div>
		    </div>
				loadMoreHtml="";
			}else{
				if(data.noMore){
				}else{
				  loadMoreHtml=	<LoadMore container='main-c' data={{
							hide:data["loading"]['hide'],
							loading:data["loading"]['loading'],
							fix:data["loading"]['fix']
						}} onEndReached={(e)=>{this.onEndReached(e)} } />
				}
			}
		}
    return(
    		<div className="root-container mescroll aaa" id="mescroll">
					<div className="root-container-w">
						<sesstion className="main">
							<div className="main-c" ref="listC" style={{
								height:this.state.containerHeight || 'auto'
							}}>
								<div className="main-w">
									<div id="todos-container">
										<div className="todos-refresh"></div>
										<div className="aaa-list">
					        		<div className="aaa-list-c">
					        			<div className="aaa-list-list">
					        				{
					        					_.map(data['list'],function(i){
					        						return self._init_item(i)
					        					})
					        				}
					        			</div>
					        		</div>
					        	</div>
										{loadMoreHtml}
									</div>
								</div>
							</div>
						</sesstion>
					</div>
				</div>
      );
  }
  getData(){
    let self = this;
  }
  onEndReached(e){
		let dispatch = this.props.dispatch;
		let datas = this.props.<%name%>;
		if(datas['loading']['loading']) return
		let page = datas["page"];
		let pageno =  parseInt(datas["page"]["pageno"])+1;
		page['pageno'] = pageno
		dispatch({
			type:"<%name%>/changeData",
			payload:{
				page:page
			}
		})
		dispatch({
			type:"<%name%>/fetch",
			payload:{
				pageno:pageno
			}
		})
	}
	setHeight(){
		let clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
		this.setState({
			containerHeight:clientHeight  - 6 +'px'
		})
	}
	componentDidMount(){
		let self = this;
		let dispatch = this.props.dispatch;
		let data = this.props.<%name%>;
		this.setHeight();
		setTimeout(function(){
  	 	dispatch({
	  	 	type:'<%name%>/fetch',
	  	 	payload:{
	  	 		payload:0
	  	 	}
  	 	})
		},0)
		window.onresize = function(){
			self.setHeight();
		}
	}
}

export default connect((state)=>{return state})(<%name%>);
