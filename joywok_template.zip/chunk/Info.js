import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'dva';
import LoadMore from '../../components/LoadMore';
class Info extends Component {
  constructor(props) {
    let dispatch = props.dispatch;
    let store = new Store('Joywok:cache:tabs:info');
    if(store['data']["tab:cache"]){
      dispatch({
        type:'info/changeData',
        payload:{
          parentData:store['data']['tab:cache']['data']
        }
      })
    }
    super(props);
  }
  render(){
    let self = this;
    let data = this.props.info
    let headerBg= {};
    headerBg['background'] = '#077655'
    return (
      <div className="root-container">
        <div className="root-container-w">
          <sesstion className="main">
            <header className="header" ref="header" style={headerBg}>
              <div className="header-bg-specail">
                <div className="header-bg"></div>
                <div className="header-bg-2" style={headerBg}></div>
              </div>
              <div className="header-c">
                <div className="user-card">
                  <div className="user-card-c">
                      <div className="user-card-avatar">
                        <img src={data['parentData']?data['parentData']["pic"]:'https://www.joywok.com/public/images/avatar/l.jpg'} alt=""/>
                      </div>
                      <div className="user-card-info">
                        <div className="user-card-info-i">
                          <div className="user-card-label">姓名</div>
                          <div className="user-card-val">翟磊</div>
                        </div>
                        <div className="user-card-info-i">
                          <div className="user-card-label">职位</div>
                          <div className="user-card-val">前端开发</div>
                        </div>
                        <div className="user-card-info-i">
                          <div className="user-card-label">联系方式</div>
                          <div className="user-card-val">183581010103</div>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </header>
            <div className="main-c info-list" ref="listC" style={{
              paddingBottom:"0"
            }}>
              <div className="main-w main-w-padding">
                {
                  data['parentData']?<div className="<%name%>-list-item">
                    <div className="<%name%>-list-item-c">
                      <div className="<%name%>-list-item-pic">
                        <img src={data['parentData']['pic']}/>
                      </div>
                      <div className="<%name%>-list-item-info">
                        <div className="<%name%>-list-item-name">{data['parentData']['name']}</div>
                        <div className="<%name%>-list-item-creator"><span>{data['parentData']['creator']}</span><span>{data['parentData']['update_at']}</span></div>
                      </div>
                    </div>
                    <div className="<%name%>-list-item-other">
                      <div className="<%name%>-list-item-data">
                        <div className="<%name%>-list-item-data-label">目前状态</div>
                        <div className="<%name%>-list-item-data-value">{data['parentData']['status']}</div>
                      </div>
                      <div className="<%name%>-list-item-data">
                        <div className="<%name%>-list-item-data-label">涉及客户</div>
                        <div className="<%name%>-list-item-data-value">{data['parentData']['client']}</div>
                      </div>
                      <div className="<%name%>-list-item-data">
                        <div className="<%name%>-list-item-data-label">交付时间</div>
                        <div className="<%name%>-list-item-data-value">{data['parentData']['time']}</div>
                      </div>
                    </div>
                  </div>:''
                }
              </div>
            </div>
          </sesstion>
          {self.getButton()}
        </div>
      </div>
    )
  }
  getButton(){
    return <div className="bottom-btn">
       <div className="button-btn-i refuse-btn" style={{
        width:'40%'
       }}>
        <span>拒绝</span>
      </div>
       <div className="button-btn-i agree-btn" style={{
        width:'60%'
       }} >
        <span>同意</span>
      </div>
    </div>
  }
  componentDidUpdate(){
    this.setHeight()
  }
  setHeight(){
    let clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
    let header = $('.header').height() || 0 ;
    let footer = $('.bottom-btn').height() || 0;
    $(".main-c").css({height:clientHeight - header  - footer - 20 +'px'})
  }
  componentDidMount(){
    NProgress.done();
  }
}

export default connect(function(state){return state})(Info);
