import React,{ Component } from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'dva';
class LoadMore extends Component{
	render(){
		let data = this.props.data;
		let style = {};
		return (
			<div className={"loading-bounce-w "+(data['hide']?'hide':'')+' '+(data['fix']?'fix':'')}>
				<div className="loading-bounce-bg"></div>
				<div className="loading-gif">
					{
						window.config && window.config['loadingImg'] && window.config['loadingImg'].length!=0?<img src={window.config['loadingImg']} />:<div className="sk-cube-grid">
							  <div className="sk-cube sk-cube1"></div>
							  <div className="sk-cube sk-cube2"></div>
							  <div className="sk-cube sk-cube3"></div>
							  <div className="sk-cube sk-cube4"></div>
							  <div className="sk-cube sk-cube5"></div>
							  <div className="sk-cube sk-cube6"></div>
							  <div className="sk-cube sk-cube7"></div>
							  <div className="sk-cube sk-cube8"></div>
							  <div className="sk-cube sk-cube9"></div>
							</div>
					}
				</div>
			</div>);
	}
	componentDidMount(){
		let self = this;
		let data = this.props.data;
		if(this.props['container']){
			console.log("container",this.props['container'],$("."+this.props['container']).length)
			$("."+this.props['container']).scroll(function(evt){
				if(data["loading"]['fix'] || data['loading']['loading']) return;
				let scrollTop = $('.'+self.props['container']).scrollTop();
				let clientHeight = $('.'+self.props['container']).height();
				let target = $('.loading-bounce-w');
				if(target.length==0) return;
				if(clientHeight>=target.offset().top){
					self.props.onEndReached(evt);
				}
			})
		}else{
		}
	}
};

LoadMore.propTypes = {
};

export default connect(function(state){return state})(LoadMore);