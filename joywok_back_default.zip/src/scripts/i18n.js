var jwDict = {
	"demo": {
		zh: '', en: ''
	},
}
window.i18n = function (key, re) {
	if (jwDict[key]) {
		if (re != window.undefined) {
			var str = jwDict[key][window.UILanguage];
			for (var i in re) {
				str = str.replace(eval('/\{ ' + i + ' \}/g'), re[i]);
			}
			return str;
		}
		return jwDict[key][window.UILanguage];
	}
	return key;
}