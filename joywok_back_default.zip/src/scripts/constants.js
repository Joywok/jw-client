import request from './utils/request';
export const registerModel = (app, model) => {
  let a = app._models;
  if (!(app._models.filter(m => m.namespace === model.namespace).length === 1)) {
    app.model(model)
  }
}
