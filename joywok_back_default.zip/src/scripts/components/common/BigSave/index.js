/*
用途：保存框的特殊风格 intents
props:bigSaveTip   弹框中成功提示文字 不传默认  保存成功
      bigSaveGuide   弹框中引导的文字  不传默认  请前往 Training 中训练成功后方能生效
      bigSaveBtnText   弹框中按钮的文字  不传默认  立刻前往

events :   closeIcon   右上角关闭按钮的回调函数
            goToDestine   立刻前往按钮的回调函数
*/
import React , {Component,Fragment} from 'react';
import {connect} from 'dva';
import { makeStyles,withStyles } from '@material-ui/core/styles';
import {JwPagination,Button} from 'joywok-material-components';
import Icon from '@material-ui/core/Icon';
import InputBase from "@material-ui/core/InputBase/InputBase";
import DeleteOutlinedIcon from '@material-ui/icons/DeleteOutlined';
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import '../../../../styles/Common/bigSave.css';
import ButtonUI from '../../ui/Button';
import CloseIcon from '@material-ui/icons/Close';
const useStyles = theme => ({
  
});

class BigSave extends  React.Component{
  constructor(props) {
    super(props);
    this.state = {
    }  
  }

componentDidMount(){
    let self = this;
  }
  componentWillUnmount(){
  }
  //右上角关闭按钮
  onCloseIcon(events){
    let self = this;
    self.props.closeIcon && self.props.closeIcon(events);
  }
//立刻前往按钮事件
goToDestine(events){
  let self = this;
  self.props.goToDestine && self.props.goToDestine(events);
}
  render(){
    let self = this;
    const { classes } = this.props;
    
    const {} = this.state;
    return (            
           <div className='bigSave'>
            <CloseIcon  className="bigSave_closeButton" onClick={this.onCloseIcon.bind(this)}></CloseIcon>
            <div className='bigSave_top'>
            </div>
            <div  className='bigSave_bot'>
              <div  className='bigSave_bot_tip'>
                  {this.props.bigSaveTip ? this.props.bigSaveTip : i18n("save.success")}
              </div> 
              <div  className='bigSave_bot_guide'>
                  {this.props.bigSaveGuide ?this.props.bigSaveGuide : i18n("bigSave.tip")}
              </div>
              <div  className='bigSave_bot_btn' onClick={this.goToDestine.bind(this)}>
                  <ButtonUI color="primary" variant="contained" >{this.props.bigSaveBtnText ?this.props.bigSaveBtnText : i18n("go.right.away")}</ButtonUI>
              </div>
            </div>
          </div>            
    )
  }
}

export default connect((state)=>{return state})(withStyles(useStyles)(BigSave));