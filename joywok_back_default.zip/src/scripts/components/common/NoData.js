/*
 *
 * 空页面
 * 页面描述 
 * 有阴影的盒子  和箭头指引
 * 下方是汉字
**/
import React , {Component} from 'react';
import {connect} from 'dva';
import '../../../styles/Common/SPublic.css'
class NoData extends Component{
  constructor(props) {
    super(props);
    this.state={
      
    }
    this.state.operation = window.curAgent.operation; //admin (超级管理员)  edit(管理员)
  }
  checkAuth(){
    //[0/超级管理者,10/管理者,20/查看者]
    let operation = this.state.operation,
        result;
    if(operation.indexOf('admin')!=-1 || operation.indexOf('edit')!=-1){
        result = false;
    }else{ //查看着
        result = true;
    }
    return result;
  }
  render(){
    return(
       <div className="dict-no-data">
        <div className="dict-no-data-arrow">
          {this.checkAuth()?<div style={{
            display: 'inline-block',
            width: '200px',
            height: '132px',
            marginRight: '10%'
          }}></div>: <img src={distPath+"/images/turn-arrow.png"} />}         
        </div>
        <div className="dict-no-data-img">
          <img src={distPath+"/images/empty-icon-s.png"} />
        </div>
        <p className="dict-no-data-text">{this.props.emptyDes?this.props.emptyDes:i18n("empty")}</p>
        {this.checkAuth()?<p className="dict-no-data-desc"></p>:<p className="dict-no-data-desc">{this.props.emptyTip?this.props.emptyTip:i18n('intents.emptyTip',{name:i18n("create.intents")})}</p>}        
      </div>
    )
  }
}
export default connect((state)=>{ return state})(NoData);
