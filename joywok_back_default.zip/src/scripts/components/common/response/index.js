/*
用途：选择引用 Response 来源  组件 
用法：* props:
     maxWidth  用于设置弹框的最大宽度  'xs' 'sm' 'md' 'lg' 'xl'
     title  用于设置弹框表头标题 string
     agentId   用户id
     checkValue  编辑传入的 选中的行数据（传入的是uuid）

    * events:  save(确定)  cancel(取消)  closeIcon(右上角关闭按钮)
    输出 一行的整个数据 格式如下
     {alias: null
        name: "WELFARE_BEAN_PROGRAM"
        tags: []
        uuid: "23de744f3fbd42bda52c54942c01b427"
    }  

    在自己页面调用  例子如下
    import Response from '../../components/common/response/index' //路径需要自行更改
    {
        this.state.dialogOpen?
        <Response  
            agentId='007b22a2e5904533b590e22b3cb96f04'
            maxWidth='md' 
            title='aaa'
            checkValue={this.state.checkValue} //没有写的话 默认没有选中项
            save={this.responseSave.bind(this)}
            cancel={this.responseCancel.bind(this)}>
        </Response>:''
    }
*/
import React , {Component,Fragment} from 'react';
import {connect} from 'dva';
import { withStyles } from '@material-ui/core/styles';
import { green } from '@material-ui/core/colors';
import {JwPagination,JwButton} from 'joywok-material-components';
import { Button,Dialog,DialogTitle,DialogContent,DialogActions,Radio,RadioGroup,FormControlLabel} from '@material-ui/core';
import InputBase from "@material-ui/core/InputBase";
import CloseIcon from '@material-ui/icons/Close';
import Loading from '../Loading'; //加载loading 
import EmptyView from '../EmptyView'; //空数据组件
import  '../../../../styles/Common/Response.css';
const useStyles = theme => ({
      search: {
        position: 'relative',
        height:'46px',
        borderRadius: theme.shape.borderRadius,
        backgroundColor: '#F1F1F1',
        marginRight: theme.spacing.unit * 2,
        marginLeft: 0,
        width: '100%',
        borderRadius: 4
      },
      Position:{
        right:'20px',
        top: '0px',
        cursor: 'pointer'
      },
      searchIconC: {
        width: theme.spacing.unit * 4,
        height: '100%',
        position: 'absolute',
        pointerEvents: 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: "#999",
        marginLeft:theme.spacing.unit * 1.5
      },
      inputRoot: {
        color: 'inherit',
        width: '100%',
      },
      inputInput: {
        marginTop:6,
        paddingTop: theme.spacing.unit,
        paddingRight: theme.spacing.unit,
        paddingBottom: theme.spacing.unit,
        paddingLeft: theme.spacing.unit * 6,
        transition: theme.transitions.create('width'),
        width: '100%',
        color: "#333",
        fontSize:14,
        lineHeight:1
      }
});
const GreenRadio = withStyles({
  root: {
    color: "#CCCCCC",
    '&$checked': {
      color: '#00C78B',
    },
  },
  checked: {},
})(props => <Radio color="default" {...props} />);
class Response extends  React.Component{
  constructor(props) {
    super(props);
    this.state = {
        maxWidth:this.props.maxWidth || 'md',
        title:this.props.title || '提示',
        agentId:this.props.agentId || '',
        radioValue:this.props.checkValue?this.props.checkValue:'',
        searchValue:'', //搜索的值
        paginationStatus:{},//分页数据
        loadStatus:false, //Loading 状态 
        responseData:[],//response  数据
    }
  }
  componentDidMount(){
    let self = this;
    this.init(1,self.state.searchValue);
  }
   //初始化列表
   init(page,val){
    const { dispatch } = this.props;
    this.setState({
        loadStatus:true
    })
      dispatch({
        type: 'Intents/intentsList',
        payload:{
          page:page,
          page_size:10,
          s:val,
          language:window.language,
          response:"true"
        },
        callback:(resp)=>{
            let data = resp.data;
            let status = resp.status;  
            this.setState({
                responseData:data,
                paginationStatus:status,
                loadStatus:false
            })        
        } 
    });
  }
   //切换分页
   paginationStatusChange(val){
    this.init(val,this.state.searchValue)
  }
  //键盘摁下
  onKeyDown(e){
    let code = e.keyCode;
    if(code == '13'){
        this.init(1,this.state.searchValue);
    }
  }
  //input  输入
  inputChange(e){
    let value = e.target.value;
    this.setState({
        searchValue:value
    })
  }
  //关闭按钮
  // onCloseIcon(){
  //   this.props.cancel && this.props.cancel(); //传出去取消按钮事件
  //   this.props.closeIcon && this.props.closeIcon(); //传出去右上角关闭按钮事件
  // }
  //选中行数据 change 事件
   handleChange = event => {
    this.setState({
        radioValue:event.target.value
    })
  };
  //确定按钮
  responseSave(){
    let self = this;
    let obj = self.state.responseData.find((item)=>item.uuid==self.state.radioValue);
    self.props.save && self.props.save(obj); //传出去确定按钮事件
  }
  //取消按钮
  responseCancel(){
    this.props.cancel && this.props.cancel(); //传出去取消按钮事件
  }
  closeEmpty(){
    this.setState({
      searchValue:''
  })
  }
  render(){
    let self = this;
    const { classes } = this.props;
    const {responseData,radioValue,maxWidth,title,loadStatus} = this.state;
    return (
        <div className='response_dialog'>            
            <Dialog open={true} maxWidth={maxWidth} fullWidth={true} className='response_dialog_overxhidden'>
                <DialogTitle className='response_dialog_header response_dialog_header_spc'>
                    <div className="response_dialog_header_title">{title?title:i18n("response.source")}</div>
                      <CloseIcon className="response_closeButton" onClick={this.responseCancel.bind(this)} />
                        <div className={classes.search+' custom-search-input   response_search'}>
                          <div className={classes.searchIconC}>
                          <i className={'icon-search'}></i>
                          </div>
                          <InputBase
                          placeholder="搜索"
                          classes={{
                              root: classes.inputRoot,
                              input: classes.inputInput,
                          }}
                          value={this.state.searchValue}
                          onChange={(e)=>self.inputChange(e)}
                          onKeyDown={(e)=>self.onKeyDown(e)}
                          />
                           <div  className="response_empty"
                           style={this.state.searchValue?{display:"block"}:{display:"none"}}
                           onClick={self.closeEmpty.bind(self)}>
                              <i className={'icon-close'}></i>
                          </div>
                    </div>
                </DialogTitle>
                <DialogContent dividers className='response_dialog_con response_dialog_con_mar'>                    
                    <div style={{minHeight: '300px',marginTop: '30px'}}>
                        <RadioGroup aria-label="gender" name="gender1" value={radioValue} onChange={this.handleChange}>
                            {!loadStatus && responseData.length ?
                                _.map(responseData,function(item,index){
                            return <FormControlLabel className="response_dialog_formControlLabel" value={item.uuid} control={<GreenRadio/>} 
                                        label={<div className='response_dialog_contentDetail'>
                                            <div className='response_dialog_content'>{item.name}</div>
                                            <div className='response_dialog_tip' 
                                                style={item.alias?{lineHeight:'18px',paddingTop: '11px'}:{}}>
                                            {item.alias?item.alias:''}</div></div>} />
                                }):(responseData.length==0 && !loadStatus?<EmptyView desc={i18n("nofound")}/>:'')
                            }                                    
                        </RadioGroup>
                        {loadStatus? <Loading/> :''}
                    </div>
                    {
                    Object.keys(this.state.paginationStatus).length!=0 && self.state.paginationStatus.total_num != 0 && self.state.paginationStatus.total_num >10 && !loadStatus && responseData.length? 
                    <div className='entitieslist_pagination response_dialog_pagination'>
                        <JwPagination 
                        num={Math.ceil(self.state.paginationStatus.total_num/self.state.paginationStatus.page_size)} 
                        index={(self.state.paginationStatus.page)} 
                        onChange={self.paginationStatusChange.bind(self)}>
                        </JwPagination>
                    </div>
                    : ""
                    }
                </DialogContent>
                <DialogActions className='response_dialog_footer'> 
                    <Button className="contained" onClick={this.responseSave.bind(this)} disabled={radioValue==""}
  style={radioValue==""?{background:'#ccc'}:{background:'#00C78B'}}>{i18n("btn.save")}</Button>
  <Button className="outlined" onClick={this.responseCancel.bind(this)}>{i18n("btn.cancel")}</Button>
                </DialogActions>
            </Dialog>           
        </div>
    )
  }
}

export default connect((state)=>{return state})(withStyles(useStyles)(Response));