/** 
 * 使用页面: entities 创建/编辑
 * 用途: 用于上传文件 暂时只支持txt
 * 
 event  handleChange  接收两个参数  fileList(文件列表)  fileData(接口返回数据)
  
 */
import React , {Component,Fragment} from 'react';
import {connect} from 'dva';
import { withStyles } from '@material-ui/core/styles';
import { Upload,Icon,Button} from 'antd'; //集成antd 的上传
import AddIcon from '@material-ui/icons/Add';//添加按钮
import fetch from 'dva/fetch';//接口请求
import '../../../../styles/Common/UploadMod.css';
const { Dragger } = Upload;
const useStyles = theme => ({})

class UploadMod extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fileData:{},//接口返回数据
      fileList: this.props.fileList || [],//上传文件list
      uploading: false,//上传状态
      defaultFileList:[],//默认上传数据
    }   
  }
  componentDidMount(){
    let self = this;
  }
  //接受到新的状态(Props)时被触发，一般用于父组件状态更新时子组件的重新渲染。
  componentWillReceiveProps(nextProps){
    if (this.props.fileList !== nextProps.fileList){
      //通过新旧状态的对比，来决定是否进行其他方法
      if (nextProps.fileList){
        this.setState({
          fileList: nextProps.fileList,
        })
      }
    } 
    if (this.props.fileData !== nextProps.fileData){
      //通过新旧状态的对比，来决定是否进行其他方法
      if (nextProps.fileData){
        this.setState({
          fileData: nextProps.fileData,
        })
      }
    }  
  }
  //清空
  empty(){
    this.setState({
      fileList:[],
      uploading: false,
      fileData:{}
    },()=>{
      this.props.onChange(this.state.fileList,this.state.fileData)
    })
  }
  download(){
    const { dispatch } = this.props;
    const {fileData} = this.state;
    let url = "/api/v1/lookup_files/"+fileData.filename;
    jw.download(url);
    //window.location.href = "/api/v1/lookup_files/"+fileData.filename;
  }
  //上传
  handleUpload(){
    const { fileList } = this.state;
    const formData = new FormData();
    formData.append('file', fileList[0]);   //注意第一个参数是传给后台的参数名字，我的项目中叫file1
    this.setState({uploading: true});
    fetch('/api/v1/lookup_files', {
      method: "POST",
      body: formData,
    }).then(response => response.json())  ///解析json数据
    .then(data => {
      console.log(data)
      this.setState({fileData: data,uploading:false})  ////赋值到本地数据
      this.props.onChange(this.state.fileList,this.state.fileData)
    }).catch(e => console.log('错误:', e))   ///请求出错  
  }

  render(){
    const { fileList,uploading,fileData } = this.state;
    const uploadButton = (
      <div>
         <Icon className='addIcon' type={this.state.uploading ? 'loading' : 'plus'} />
        <div className="upload-text">{this.state.uploading ?  i18n("uploading") :'点击上传或将文件拖到此区域，只允许上传 txt 文本'}</div>
      </div>
     );
     const props = {
      beforeUpload: (file) => {
        this.setState({
          fileList:[]
        })
        this.setState(state => ({
          fileList: [...state.fileList, file],
        }),()=>{
          this.handleUpload();
        });        
        return false;
      },
      fileList,
      accept:".txt",
      showUploadList:false,
    };
    console.log('upload',fileList,uploading,fileData, Object.keys(fileData).length)
    return (     
      <div>       
      {
        fileList && fileList.length && !uploading?<div className='upload-list'>
          <div className='upload-list-file'>
              <div className='upload-list-file-img'>
                <img  src={distPath+"/images/txt.png"}/>
              </div>
              <div className='upload-list-file-con'>
                <div className='upload-list-file-name'>
                  {/* {this.state.fileData.filename} */}
                  {Object.keys(fileData).length==0?"":fileData.filename}
                {/* {fileList[0].name?fileList[0].name:fileList[0].filename} */}
                </div>
                <div className='upload-list-file-size'>
                {/* {fileList[0].size+'kb'} */}
                {/* {this.state.fileData.size+'B'} */}
                {Object.keys(fileData).length==0?"":fileData.size+'B'}
                </div>
              </div>
          </div>
            <div className='upload-list-text'>
                <span className='download words' onClick={this.download.bind(this)}>{i18n("download")}</span>
                <span className='point'></span>
                <Upload {...props}>
                  <span className='replace words'>{i18n("object.change")}</span>
                </Upload>                
                <span className='point'></span>
                <span className='empty words' onClick={this.empty.bind(this)}>{i18n("object.clear")}</span>
            </div>
        </div>:
        <div className="upload_txt">
          <Dragger {...props}>{uploadButton} </Dragger>
        </div>
      }
      </div>
    )
  }
}

export default connect((state)=>{return state})(withStyles(useStyles)(UploadMod));
