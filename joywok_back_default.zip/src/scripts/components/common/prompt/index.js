/*
用途：设置 添加/编辑prompt  and  synonym  组件  用于页面： 创建entities 实体等
用法：* props:
     maxWidth  用于设置弹框的最大宽度  'xs' 'sm' 'md' 'lg' 'xl'
     title  用于设置弹框表头标题 string

    * events:  
    输出填进去的数据    格式如下    数组的形式 [aa,bb,cc]...    
    涉及到的其他组件 使用
    InputGroup 是用于添加多个input 组件  用法详细说明在该组件里面

     在自己页面调用  例子如下
    import Prompt from '../../components/common/Prompt/index' //路径需要自行更改
    {this.state.dialogOpen?
      <Prompt 
           maxWidth='md' 
           title='设置 Promt' 
           save={this.responseSave.bind(this)}
            closeIcon={this.closeIcon.bind(this)}>
      </Prompt>:''}
*/
import React , {Component,Fragment} from 'react';
import {connect} from 'dva';
import { withStyles } from '@material-ui/core/styles';
import {JwPagination,JwButton,JwTextField} from 'joywok-material-components';
import { Dialog,DialogTitle,DialogContent,DialogActions,Typography,IconButton,
Radio,RadioGroup,FormControl,FormLabel,FormControlLabel} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import Button from '../../ui/Button';
import InputGroup from './inputGroup';
import  '../../../../styles/Common/Response.css';  //部分继承 response 样式
import  '../../../../styles/Common/Prompt.css';//独立的自己的样式
const useStyles = theme => ({});

class Prompt extends  React.Component{
  constructor(props) {
    super(props);
    this.state = {
        maxWidth:this.props.maxWidth || 'md',
        values: this.props.values || [],
        title:this.props.title || '提示',
    }
  }

  //初始化函数
  componentDidMount(){
    let self = this;
  }
  //接受到新的状态(Props)时被触发，一般用于父组件状态更新时子组件的重新渲染。
  componentWillReceiveProps(nextProps){
    if (this.props.values !== nextProps.values){
      //通过新旧状态的对比，来决定是否进行其他方法
      if (nextProps.values){
        this.setState({
          values: nextProps.values
        })
      }
    }  
  }
  //确定按钮
  responseSave(){
     let self = this;
     var resultArr = this.state.values.filter(function (s) {
        return s && s.trim(); //去掉空的值
    });
    self.props.save && self.props.save(resultArr);   //传出去确定按钮事件
    console.log('baocun ',resultArr)
  }
    //关闭按钮
    onCloseIcon(){
      let self = this;
      var resultArr = this.state.values.filter(function (s) {
          return s && s.trim(); //去掉空的值
      });
      this.props.closeIcon && this.props.closeIcon(resultArr); //传出去右上角关闭按钮事件
    }  
   changeInputGroup(data) {
    let self = this;
    self.setState({
      values: data,
    })
  }
  render(){
    let self = this;
    const { classes } = this.props;
    const {values,maxWidth,title} = this.state;
    return (
        <div className='response_dialog'>
            <Dialog  open={true}  maxWidth={maxWidth} fullWidth={true}>
                <DialogTitle className='response_dialog_header'>
                    <div className="response_dialog_header_title">{title?title:i18n("response.source")}</div>
                        <CloseIcon className="response_closeButton" onClick={this.onCloseIcon.bind(this)} />
                </DialogTitle>
                <DialogContent dividers className='response_dialog_con prompt_dialog_con'>
                    <InputGroup values={values} displaysample={true} minNums={1} onChange={(data) => { self.changeInputGroup(data) }}></InputGroup>
                </DialogContent>
                <DialogActions className='response_dialog_footer prompt_dialog_footer'>                
    <Button color="primary" variant="contained" onClick={this.responseSave.bind(this)} disabled={values.length?false:true}>{i18n("btn.save")}</Button>
                </DialogActions>
            </Dialog>
        </div>
    )
  }
}

export default connect((state)=>{return state})(withStyles(useStyles)(Prompt));