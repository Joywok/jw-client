/*添加多个input 组件 
       	minNums: 最少保留几个输入框，达到数量就不再显示删除按钮, 默认为0
 		maxNums: 最多允许添加几个输入框，达到数量就不再显示新增按钮，默认不限制
 		displaysample: 是否展示样例(一个都没有填的时候，展示一个空的输入框)，默认为true, 可设置为false
         values: ['xxxxx','xxxxxx'] 默认值
         addBtnText: 添加按钮右侧的话术
 * events:
 		onChange: (values)  values: ['xxxx','xxxxx','xxxxx']
*/
import React, { Component, Fragment } from 'react';
import { connect } from 'dva';
import { withStyles } from '@material-ui/core/styles';
import InputBase from "@material-ui/core/InputBase/InputBase";
import DeleteOutlinedIcon from '@material-ui/icons/DeleteOutlined';
import '../../../../styles/Common/Response.css';  //部分继承 response 样式
import '../../../../styles/Common/Prompt.css';//独立的自己的样式
const useStyles = theme => ({});

class InputGroup extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            addIcon:distPath + "/images/addIcon.png",
            values: this.props.values || [],
            minNums: this.props.minNums || 1,
            maxNums: this.props.maxNums || '',
            displaysample: this.props.displaysample || true,
            addBtnText:this.props.addBtnText ? this.props.addBtnText : '添加话术'

        }
        if (this.state.displaysample === true && (!this.props.values || (this.props.values && this.props.values.length == 0))) {
            this.state.values = [''];
            this.setState({
                values: this.state.values
            })
        }
    }
    componentDidMount() {
        let self = this;
    }
    //input change 
    onChange(index, e) {
        let self = this;
        let values = JSON.parse(_.clone(JSON.stringify(this.state.values)));
        values[index] = e.target.value;
        this.setState({
            values: values,
        }, () => {
            this.props.onChange(this.state.values)
        })
    }
    //删除按钮  逻辑删除
    delInput(index) {
        this.setState({
            values: _.filter(this.state.values, function (value, i) { return i != index; }),
        }, () => {
            this.props.onChange(this.state.values)
        })
    }
    //添加按钮 添加input
    addInput() {
        this.state.values.push('');
        this.setState({
            values: this.state.values
        })
    }
    render() {
        let self = this;
        let totalValues = this.state.values.length;
        return (
            <div className='prompt_input_group'>
                {
                    _.map(this.state.values, (item, index) => {
                        return (<div className="prompt_input_item">
                            <InputBase
                                placeholder={i18n("default.user.name")}
                                className='inputInput'
                                value={item}
                                onChange={(e) => this.onChange(index, e)}
                            />
                            {
                                self.state.minNums > 0 && totalValues <= self.state.minNums ?
                                    '' :
                                    <div className="prompt_input_del" onClick={() => self.delInput(index)}> <DeleteOutlinedIcon /></div>
                            }
                        </div>)
                    })
                }
                {
                    (typeof (this.state.maxNums) == 'number' && totalValues >= this.state.maxNums) ?
                        '' :
                        <div className="prompt_add_btn" onClick={() => self.addInput()}>
                            <img className='prompt_add_btn_icon' src={this.state.addIcon} />
                            <span className="prompt_add_btn_text">{this.state.addBtnText}</span>
                        </div>
                }
            </div>
        )
    }
}

export default connect((state) => { return state })(withStyles(useStyles)(InputGroup));