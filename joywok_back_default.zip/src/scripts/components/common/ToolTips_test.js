import React, { Component } from 'react';
import { connect } from 'dva';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Tooltip from '@material-ui/core/Tooltip';
import Button from '@material-ui/core/Button';
function arrowGenerator(color) {
  return {
    '&': {
      // top: '-105px!important',
      left: '10px!important'
    },
    '&[x-placement*="bottom"] $arrow': {
      top: 0,
      left: '20px',
      marginTop: '-0.95em',
      width: '3em',
      height: '1em',
      '&::before': {
        // borderWidth: '0 1em 1em 1em',
        borderWidth: '0 1.5em 1em 0',
        borderColor: `transparent transparent ${color} transparent`,
      },
    },
    '&[x-placement*="top"] $arrow': {
      bottom: 0,
      left: '20px',
      marginBottom: '-0.95em',
      width: '3em',
      height: '1em',
      '&::before': {
        // borderWidth: '1em 1em 0 1em',
        borderWidth: '1em 1.5em 0 0em',
        borderColor: `${color} transparent transparent transparent`,
      },
    },
  };
}

const styles = theme => ({
  tooltip: {
    // position: 'relative',
    // padding: '30px',
    padding: '20px 15px',
    lineHeight: '17px',
    backgroundColor: '#404A53',
    // backgroundColor: '#fff',
    fontSize: '12px',
    // maxWidth: '311px',
    width: '311px',
    // maxWidth: '570px',
    // width: '500px',

    boxShadow: '0px 0px 10px 0px rgba(0,0,0,0.15)',
    // marginLeft: '200px',
  },
  lightTooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
  },
  arrowPopper: arrowGenerator('red'),
  arrow: {
    position: 'absolute',
    fontSize: 6,
    width: '3em',
    height: '3em',
    '&::before': {
      content: '""',
      margin: 'auto',
      display: 'block',
      width: 0,
      height: 0,
      borderStyle: 'solid',
    },
  },
  bootstrapPopper: arrowGenerator(theme.palette.common.black),
  bootstrapTooltip: {
    backgroundColor: theme.palette.common.black,
  },
  bootstrapPlacementTop: {
    margin: '8px 0',
  },
  bootstrapPlacementBottom: {
    margin: '8px 0',
  },
  htmlPopper: arrowGenerator('#dadde9'),
  htmlTooltip: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
    '& b': {
      fontWeight: theme.typography.fontWeightMedium,
    },
  },
});

class ToolTipTest extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      arrowRef: ''
    }
  }
  handleArrowRef = node => {
    this.setState({
      arrowRef: node,
    });
  };
  render() {
    const { classes } = this.props;
    console.log('tool--', classes);
    return <Tooltip
      title={
        <React.Fragment>
          {this.props.title || 'wer'}
          {/* s撒大声地所发的是撒大声地所发的是撒大声地所发的是撒大声地所发的是撒大声地所发的是撒大声地所发的是 */}
          <span className={classes.arrow} ref={this.handleArrowRef} />
        </React.Fragment>
      }
      classes={{ popper: classes.arrowPopper }}
      placement="top"
      // {...this.props}
      PopperProps={{
        popperOptions: {
          modifiers: {
            arrow: {
              enabled: Boolean(this.state.arrowRef),
              element: this.state.arrowRef,
            },
          },
        },
      }}
    >
      {/* <div className={classes.button}> */}
      {this.props.children}
      {/* </div> */}
      {/* <Button className={classes.button}>Arrow</Button> */}
    </Tooltip>
  }
}
export default connect((state) => { return state })(withStyles(styles)(ToolTipTest));