/* 
用途：用来hover展示图片的提醒信息

参数说明：
 placement:Tooltip placement.
 eleHtmlTitle:右侧的title
 eleHtmlTxt：右侧下面的内容
 i:鼠标放在这个上面会出现弹框
 picIconClass:左侧的图片

 demo：
    <ToolTipsPic placement="bottom" eleHtmlTitle="Media"
      eleHtmlTxt="use " picIconClass="icon-iphone-pic">
      <i className="icon-notice"></i>
    </ToolTipsPic> 
*/

import React, { Component } from 'react';
import { connect } from 'dva';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Tooltip from '@material-ui/core/Tooltip';
import Button from '@material-ui/core/Button';

function arrowGenerator(color) {
  return {
    '&': {
      opacity: 1,
    },
    '&[x-placement*="bottom"] $arrow': {
      top: 0,
      // left: 0,
      left: '50%',
      marginTop: '-0.95em',
      marginLeft: '-1em',
      width: '2em',
      height: '1em',
      '&::before': {
        borderWidth: '0 1em 1em 1em',
        borderColor: `transparent transparent ${color} transparent`,
      },
    },
    '&[x-placement*="top"] $arrow': {
      bottom: 0,
      left: '50%',
      // marginLeft: '-0.5em',
      marginLeft: '-1em',
      marginBottom: '-0.95em',
      width: '2em',
      height: '1em',
      '&::before': {
        borderWidth: '1em 1em 0 1em',
        // borderWidth: '1em 1.5em 0 0em',
        borderColor: `${color} transparent transparent transparent`,
      },
    },
  };
}

const styles = theme => ({
  tooltip: {
    position: 'relative',
    padding: '30px',
    lineHeight: '17px',
    backgroundColor: '#fff',
    // backgroundColor: '#404A53',
    fontSize: '12px',
    maxWidth: '570px',
    // width: '500px',
    width: '400px',
    boxShadow: '0px 0px 10px 0px rgba(0,0,0,0.15)'
  },

  arrow: {
    position: 'absolute',
    fontSize: 6,
    '&::before': {
      content: '""',
      margin: 'auto',
      display: 'block',
      width: 0,
      height: 0,
      borderStyle: 'solid',
    },
  },
  popper: arrowGenerator('#fff'),
  // popper: arrowGenerator('#404A53'),
  root: {
    width: 50,
  },
})
class ToolTipsPic extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      arrowRef: false
    };
  }

  render() {
    console.log('sss', this.props)
    let { classes } = this.props;
    let self = this;
    let props = this.props;
    // const [arrowRef, setArrowRef] = React.useState(null);
    // const {class}
    let { arrowRef } = this.state;
    let title = this.props.title;

    return (
      <div className={this.props.className || ""}>
        <Tooltip placement={this.props.placement} {...this.props}
          classes={classes}
          title={
            <React.Fragment>
              <div className="toast-pic">
                {/* <div ><i className="icon-iphone-pic" /></div> */}
                <div ><i className={this.props.picIconClass} /></div>
                <div className="toast-pic-right">
                  <div className="toast-pic-title">{this.props.eleHtmlTitle}</div>
                  <div className="toast-pic-content">{this.props.eleHtmlTxt}</div>
                </div>
                {/* <span className={classes.arrow} /> */}
              </div>
            </React.Fragment>
          }
        >
          {this.props.children}
        </Tooltip>
      </div>
    )
  }
}




export default connect((state) => { return state })(withStyles(styles)(ToolTipsPic));