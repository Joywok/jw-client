import React , {Component,Fragment} from 'react';
import {connect} from 'dva';
import {Button,TextField,Radio,Checkbox,Select,Switch,Datepicker,DatepickerTwo,
  JwAppBar,JwBottomNav,JwChips,JwDialog,JwSnackbar,JwTabs,JwTab,JwTips,JwPaper,Menu} from 'joywok-material-components';

let styles = theme =>({
	menu:{
		width:theme.spacing.unit*20
	}
});

 class CustomMenu extends React.Component{
 	constructor(props) {
    super(props);
    this.state = {
    	check:false,
    }
  }
 	handleClose(){}
 	render(){
 		let data = this.props.data;
 		let options = data['options'];
 		return (
 				<Menu {...this.props}>
		      {options.map(option => (
		        <MenuItem key={option} selected={option === 'Pyxis'} onClick={this.handleClose} className={this.props.classes.menu}>
		          {options}
		        </MenuItem>
		      ))}
		    </Menu>
 		)
 	}
 }

export default connect((state)=>{return state})(withStyles(styles)(CustomMenu));