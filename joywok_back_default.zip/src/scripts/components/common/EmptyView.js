/**
 * 其他页面空数据组件
 * 页面描述：有个搜索图片  下方是文字
*/
import React , {Component} from 'react';
import ReactDOM from 'react-dom';
import {connect} from 'dva';

class EmptyView extends Component{
  render(){
    return(
        <div className="simple-empty-view">
          <p><i className="icon-empty-icon"/></p>
          <p>{ this.props.desc }</p>
        </div>
    )
  }
}

export default connect((state)=>{return state})(EmptyView);