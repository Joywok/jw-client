/**
输入框修改组件接收参数：
value: 展示内容
fontSize: 展示字体大小
iconColor: 图标颜色
inputWidth: 输入框宽度 默认100px
showSize: 最多显示的字数
type: (string) number、url、可不传不做限制
required: true为必填
amount: 字数最大限制
name: 为字段名
id: 需要的id
idName: id的字段名
handleDelete(): 删除回调
handleOk(): 点击对号回调
**/

import React from 'react';
import DeleteIcon from '@material-ui/icons/Delete';
import CheckIcon from '@material-ui/icons/Check';
import ClearIcon from '@material-ui/icons/Clear';
import EditIcon from '@material-ui/icons/Edit';
import Tooltip from '@material-ui/core/Tooltip';
import TextField from '@material-ui/core/TextField';
import UIInput from '../../components/ui/Input';
import '../../../styles/Common/ChangeIuput.css';

export default class ChangeInput extends React.Component {

constructor(props) {
    super(props);
    this.state = {
        showInput:false,     //输入框显示隐藏
        valueCon:'',         //input框回显字段
    }
}
//点击展示输入框
handleChangeClick = () => {
  this.setState({
      showInput:true
  })
};
//点击关闭输入框
handleCloseClick = () => {
    this.setState({
        showInput:!this.state.showInput
    })
};
//去空格
trim = (str) => {
    return str.replace(/^(\s|\u00A0)+/,'').replace(/(\s|\u00A0)+$/,'');
};
//点击确定按钮
handleAffirmClick = () => {

    //判断不为空
    if(this.props.required&&this.trim(this.state.valueCon)===''||this.props.required&&this.trim(this.state.valueCon)==='-') {
        message.error(`此字段不能为空及特殊字符'-'`);
        return false
    }

    //判断为数字
    // if(this.props.type&&this.props.type==="number"&&isNaN(this.trim(this.state.valueCon))) {
    //     message.error(`请输入数字`);
    //     return false
    // }

    // //判断网址
    // let reg=/^\\{2}[\w-]+\\(([\w-][\w-\s]*[\w-]+[$$]?$)|([\w-][$$]?$))/;
    // if(this.props.type&&this.props.type==="url"&&!reg.test(this.props.valueCon)){
    //     message.error("这网址不是以http://https://开头，或者不是网址！");
    //     return false
    // }

    // //判断字数长度
    // if(this.trim(this.state.valueCon).length>this.props.amount){
    //     message.error(`字数不得超过${this.props.amount}个字`);
    //     return false
    // }



    //回调确定方法
    let obj = {};
    // obj.value = this.state.valueCon;
    // obj.label = this.props.name;
    obj[ this.props.name] = this.state.valueCon;
    //判断是否需要id
    if(this.props.idName){
        obj[this.props.idName] = this.props.id;
    }
    this.props.handleOk(obj);

    //关闭输入框
    this.setState({
        showInput:this.props.isShow
    })
};
//input改变
handleChange = (e) => {
    console.log(e.target.value);
    this.setState({
        valueCon:e.target.value
    })
};
componentDidMount() {
    this.setState({
        valueCon:this.props.value,
    })
}
handleDeleteClick = () =>{
    let obj = {};
    // obj.value = this.state.valueCon;
    // obj.label = this.props.name;
    obj[ this.props.name] = this.state.valueCon;
    //判断是否需要id
    if(this.props.idName){
        obj[this.props.idName] = this.props.id;
    }
    this.props.handleDelete(obj);
};
render() {
    const {value,fontSize,iconColor,inputWidth,showSize} = this.props;
    return (
        <div>
            {!this.state.showInput? 
                <div className="change_input">
                    <span className="change_input_name"  style={{fontSize:fontSize}} >
                        {showSize&&value.length>showSize?
                             <Tooltip title={value}>
                                 <span>{value.slice(0,showSize)+"..."}</span>
                            </Tooltip>
                             :<span className='only_text'>{value}</span>
                        }
                        <EditIcon  
                         style={{color:iconColor}}
                         className="change_input_hide_change editIcon"
                         onClick={this.handleChangeClick}
                         />
                        {this.props.handleDelete&&
                            <DeleteIcon   
                            style={{color:iconColor}}
                            className="change_input_hide_change"
                            onClick={this.handleDeleteClick}
                        />
                        }
                    </span>

                </div>
                :
                <div className="write_input">
                    <div className="write_input_name">
                        {/* <TextField placeholder="请输入"
                               defaultValue={this.props.value==='-'?'':this.props.value}
                               onChange={this.handleChange}
                               style={{height:'25px',margin:'0',width: '100%'}}
                        /> */}
                        <UIInput
                         className="no-border" 
                         placeholder="请输入"
                         defaultValue={this.props.value==='-'?'':this.props.value}
                        onChange={this.handleChange}
                        style={{height:'25px',margin:'0',width: '100%'}}>                            
                        </UIInput>

                    </div>
                    <div className="write_input_hide" style={{color:iconColor}}>
                        <CheckIcon className="write_input_hide_yes" onClick={this.handleAffirmClick}/>
                        <ClearIcon className="write_input_hide_no" onClick={this.handleCloseClick}/>
                    </div>
                </div>
            }
        </div>
    )
}
}


