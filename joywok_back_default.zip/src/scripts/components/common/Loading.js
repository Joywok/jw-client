/**
 * Loading 
 * 页面描述
 * 上方三个点
 * 下方是文字
*/
import React , {Component} from 'react';
import ReactDOM from 'react-dom';
import {connect} from 'dva';
import '../../../styles/Common/SPublic.css'
class Loading extends Component{
  render(){
    return(
      <div className="loader dimission-loader">
        <div className="spinner">
          <div className="bounce1"></div>
          <div className="bounce2"></div>
          <div className="bounce3"></div>
        </div>
        <div className="loading-txt">{this.props.loadText?this.props.loadText:i18n("loadinghard")}</div>
      </div>
    )
  }
}

export default connect((state)=>{return state})(Loading);