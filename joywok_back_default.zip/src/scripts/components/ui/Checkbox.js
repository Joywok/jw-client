// Checkbox.js
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/core/styles';
import Checkbox from '@material-ui/core/Checkbox';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';

const styles = {
  container: {
    display: 'flex'
  }
};

class CustomCheckbox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }
  onChange(e,item){
  	let list = this.props.value;
  	let checked = event.target.checked;
  	if(checked){
  		list = [...new Set(list.concat(item.key))]
  	}else{
  		list = list.filter(function(i){return i!=item.key})
  	}
  	this.props.onChange && this.props.onChange(list);
  }
  render() {
    let self = this;
    const { classes } = this.props;
    this.props.className = classes.input+' jw-custom-checkbox ' + (this.props.className || '');
    let value = this.props.value;
    return (
      <div className={'jw-custom-checkbox-w'}>
      	{
      		this.props.options.map(item=>(
      			<FormControlLabel className="jw-custom-checkbox-i"
			        control={
			          <Checkbox
					        checked={value.indexOf(item.key)!=-1?true:false}
					        value={item.key}
					        onChange={(e)=>this.onChange(e,item)}
                  disabled={this.props.disabled}
					      />
			        }
			        label={item.value}
			      />
      		))
      	}
      </div>
    );
  }
  componentDidMount(){
  }
}
export default withStyles(styles)(CustomCheckbox);