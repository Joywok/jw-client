import React from 'react';
import {connect} from 'dva';
import { createMuiTheme,MuiThemeProvider} from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';
let styles = theme =>({
});
class Tags extends React.Component{
	render(){
		let data = this.props;
		return (
			<div className="jw-tag-mini">
				{
					_.map(data.tags,function(i){
						let style={}
						if(typeof(i['bg_color'])!='undefined'){
							style['background'] = i['bg_color']
						}
						if(typeof(i['fore_color'])!='undefined'){
							style['color'] = i['fore_color']
						}
						return <div className="jw-tag-mini-i ellipsis" style={style} title={i.value}>{i.value}</div>
					})
				}
			</div>
		)
	}
}
export default connect((state)=>{return state})(withStyles(styles)(Tags));