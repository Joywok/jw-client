// ExpansionPanels.js
// Checkbox.js
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ToolTips from '../common/ToolTips.js';
const styles = {
};

class ExpansionPanels extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show:props.show || true,
      toolTipTitle:props.toolTipTitle || ""
    }
  }
  handleChange(){
  	this.setState({
  		show:!this.state.show
  	})
  }
  render() {
    let self = this;
    const { classes } = this.props;
    this.props.className = ' ' + (this.props.className || '');
    return (
      <div className={'jw-custom-expansion-w '+(this.props.className || '')}>
      	<ExpansionPanel expanded={this.state.show} onChange={(e)=>this.handleChange()}>
	        <ExpansionPanelSummary
	          expandIcon={<ExpandMoreIcon />}
	          aria-controls="panel1bh-content"
	          id="panel1bh-header"
	          className="jw-custom-expansion-h"
	        >
	          <div className="jw-custom-expansion-title">{this.props.title}</div>            
            {
              this.state.toolTipTitle==''?
              <i className="icon-business-question"></i>:
              <ToolTips  placement="top" title={this.props.toolTipTitle}>
                <i className="icon-business-question"></i>
              </ToolTips>}
	        </ExpansionPanelSummary>
	        <ExpansionPanelDetails className="jw-custom-expansion-c">
	          {this.props.children}
	        </ExpansionPanelDetails>
	      </ExpansionPanel>
      </div>
    );
  }
  componentDidMount(){
  }
}
export default withStyles(styles)(ExpansionPanels);