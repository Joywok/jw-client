// Checkbox.js
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/core/styles';
import Switch from '@material-ui/core/Switch';
import FormControlLabel from '@material-ui/core/FormControlLabel';
const styles = {
  container: {
    display: 'flex'
  },
};

class CustomSwitch extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }
  onChange(event){
  	this.props.onChange && this.props.onChange(event,event.target.checked);
  }
  render() {
    let self = this;
    const { classes } = this.props;
    this.props.className = classes.input+' jw-custom-switch ' + (this.props.className || '');
    return (
      <div className={'jw-custom-switch-w'}>
      	<FormControlLabel
	        control={
	          <Switch {...this.props} checked={this.props.value} onChange={(e)=>this.onChange(e)}value="checkedA"/>
	        }
	        className="jw-custom-switch-label"
	        label={this.props.label}
	      />
      </div>
    );
  }
  componentDidMount(){
  }
}
export default withStyles(styles)(CustomSwitch);