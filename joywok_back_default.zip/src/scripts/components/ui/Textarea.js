// Textarea.js
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';

const styles = {
  container: {
    display: 'flex'
  }
};

class CustomTextarea extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }
  render() {
    let self = this;
    const { classes } = this.props;
    const { anchorEl } = this.state;
    let data = this.props;
    data.className = classes.input+' jw-custom-textarea ' + (data.className || '')
    return (
      <div className={'jw-custom-textarea-w'}>
        <TextField multiline {...data}/>
      </div>
    );
  }
  componentDidMount(){
  }
}
export default withStyles(styles)(CustomTextarea);