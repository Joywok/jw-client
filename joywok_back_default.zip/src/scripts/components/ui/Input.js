import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/core/styles';
import Input from '@material-ui/core/Input';

const styles = {
  container: {
    display: 'flex'
  }
};

class CustomInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }
  render() {
    let self = this;
    const { classes } = this.props;
    const { anchorEl } = this.state;
    let data = this.props;
    data.className = classes.input+' jw-custom-input ' + (data.className || '')
    return (
      <div className={'jw-custom-input-w'}>
        {this.props.icon?this.props.icon:''}
        <Input
          {...data}
        />
      </div>
    );
  }
  componentDidMount(){
  }
}
export default withStyles(styles)(CustomInput);