import React , {Component,Fragment} from 'react';
import {connect} from 'dva';
import {Button,TextField,Radio,Checkbox,Select,Switch,Datepicker,DatepickerTwo,
  JwAppBar,JwBottomNav,JwChips,JwDialog,JwSnackbar,JwTabs,JwTab,JwTips,JwPaper,Menu} from 'joywok-material-components';

import { withStyles } from '@material-ui/core/styles';
class Empty extends React.Component{
  constructor(props) {
    super(props);
  }
  render(){
    let self = this;
    let data = this.props;
    return(
        <div className={"empty-components "+(this.props.arrow?'has-arrow':"")}>
           <div className="">
              {this.props.arrow?<div className="empty-components-arrow">
                <img src={window.jwimgsrc + "/images/turn-arrow.png"}/>
              </div>:""}
              <div className="empty-components-icon empty-components-icon">
                <img src={window.jwimgsrc + "/images/empty-icon-s.png"}/>
              </div>
              <div className="empty-components-value">{this.props.emptyValue || '暂无任何数据'}</div>
            </div>
        </div>
    )
  }
}

export default connect((state)=>{return state})(Empty);

