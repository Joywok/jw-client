// Checkbox.js
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/core/styles';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';

const styles = {
  container: {
    display: 'flex'
  }
};

class CustomRadio extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }
  onChange(event){
  	this.props.onChange && this.props.onChange(event.target.value);
  }
  render() {
    let self = this;
    const { classes } = this.props;
    this.props.className = classes.input+' jw-custom-radio ' + (this.props.className || '');
    let value = this.props.value;
    return (
      <div className={'jw-custom-radio-w'}>
      	<RadioGroup aria-label="gender" name="gender1" value={value} onChange={(e)=>this.onChange(e)}>
	      	{
	      		this.props.options.map(item=>(
	      			<FormControlLabel className="jw-custom-radio-i"
	      				checked={item.key == value ?true:false}
				        control={<Radio/>}
				        value={item.key}
				        label={item.value}
                disabled={self.props.disabled?true:false}
				      />
	      		))
	      	}
      	</RadioGroup>
      </div>
    );
  }
  componentDidMount(){
  }
}
export default withStyles(styles)(CustomRadio);