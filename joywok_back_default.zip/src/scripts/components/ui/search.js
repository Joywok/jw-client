import request from './../../utils/request';
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
// import AsyncSelect from 'react-select/lib/Async';
import Typography from '@material-ui/core/Typography';
import Popper from '@material-ui/core/Popper';
import SearchIcon from "@material-ui/core/SvgIcon/SvgIcon";
import InputBase from "@material-ui/core/InputBase/InputBase";
import Fade from '@material-ui/core/Fade';
import Paper from '@material-ui/core/Paper';
import Tags from "./tag";
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
const styles = theme => ({
  root: {
    width: '100%',
  },
  search: {
    position: 'relative',
    height:'46px',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: '#f7f7f7',
    marginRight: theme.spacing.unit * 2,
    marginLeft: 0,
    width: '100%',
    borderRadius: 4
  },
  searchIconC: {
    width: theme.spacing.unit * 4,
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: "#999",
    marginLeft:theme.spacing.unit * 1.5
  },
  inputRoot: {
    color: 'inherit',
    width: '100%',
  },
  inputInput: {
    marginTop:6,
    paddingTop: theme.spacing.unit,
    paddingRight: theme.spacing.unit,
    paddingBottom: theme.spacing.unit,
    paddingLeft: theme.spacing.unit * 6,
    transition: theme.transitions.create('width'),
    width: '100%',
    color: "#333",
    fontSize:14,
    lineHeight:1
  },
  list:{
    maxHeight:'300px',
    overflowY:'auto'
  }
});
class CustomSearch extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      open:false,
      value:'',
      loading:false,
      list:[],
      check:[],
      anchorEl:null
    }
    this.fetchTime = null
  }
  handleClick = event => {
    this.setState({
      anchorEl: event.currentTarget,
    });
  };
  handleClose = () => {
    this.setState({
      anchorEl: null,
    });
  };
  inputChange(e){
    let self = this;
    let value = e.target.value;
    let target = e.currentTarget;
    self.setState({
      value:value
    })
    clearTimeout(this.fetchTime);
    if(value.length!=0){
      this.fetchTime = setTimeout(function(){
        self.setState({
          loading:true,
          anchorEl:target
        })
        self.setState({
          open:true
        })
        let url = '/api/v1/resources?s='+value
        request(url,{
          method:'GET',
        }).then(function(resp){
          self.setState({
            list:resp.data["data"]['list'] || [{id:1},{id:2},{id:3}],
            loading:false
          })
        })
      },800)
      $(document).off('click').one('click',function(){
        self.setState({
          open:false,
        })
      })
    }else{
      self.setState({
        open:false,
        list:[],
        loading:false
      })
    }
  }
  onKeyDown(e){
    let code = e.keyCode;
    if(code == '38' || code == '40'){
      let item = $('.custom-search-popper .search-item');
      let nowActive = $('.custom-search-popper .search-item.active').eq(0);
      if(nowActive.length!=0){
        let nowIndex = parseInt(nowActive.attr('data-index'));
        item.removeClass('active');
        if(code == '38'){
          nowIndex = nowIndex - 1;
          if(nowIndex==-1){
            $('.custom-search-popper .search-item').eq(item.length-1).addClass('active');
          }else{
            $('.custom-search-popper .search-item').eq(nowIndex).addClass('active');
          }
        }else{
          nowIndex = nowIndex+ 1;
          console.log(nowIndex,'123123123');
          if(nowIndex==item.length){
            $('.custom-search-popper .search-item').eq(0).addClass('active');
          }else{
            $('.custom-search-popper .search-item').eq(nowIndex).addClass('active');
          }
        }
      }else{
        item.removeClass('active');
        if(code == '38'){
          $('.custom-search-popper .search-item').eq(item.length-1).addClass('active');
        }else{
          $('.custom-search-popper .search-item').eq(0).addClass('active');
        }
      }
      e.preventDefault()
      //上下
    }
    if(code == '13'){
      //确定
      let index = $('.custom-search-popper .search-item.active').attr('data-index');
      let data = this.state.list[index];
      this.choseItem(e,data);
      e.preventDefault();
    }
  }
  onMouseOver(index){
    let item = $('.custom-search-popper .search-item');
    item.removeClass('active');
    item.eq(index).addClass('active');
  }
  onMouseOut(index){
  }
  choseItem(e,data){
    // window.location.href = (window.location.origin + window.location.pathname+'#/'+window.appId+'/'+model.detail_page+'/'+data['id'])
    this.props.onChange && this.props.onChange(data)
  }
  onClickAway(){
    console.log('asdasdasd');
  }
  render() {
    let self = this;
    const { classes } = this.props;
    const { anchorEl } = this.state;
    return (
      <div className={classes.root+' custom-search'}>
        <div className={'custom-search-c'}>
          <div className={classes.search+' custom-search-input'}>
            <div className={classes.searchIconC}>
              <i className={'icon-search'}></i>
            </div>
            <InputBase
              placeholder={i18n("setting.usermanage.search")}
              classes={{
                root: classes.inputRoot,
                input: classes.inputInput,
              }}
              value={this.state.value}
              onChange={(e)=>self.inputChange(e)}
              onKeyDown={(e)=>self.onKeyDown(e)}
            />
          </div>
          <div className={'custom-search-popover'}>
            <Popper
            id="custom-search-popper"
            open={this.state.open}
            placement={'bottom-start'}
            anchorEl={anchorEl}
            modifiers={{
            }}
            className={'custom-search-popper'}
            style={{
              width:$('.custom-search-input').width()+'px',
              marginTop:'10px',
              zIndex:"1001"
            }}
              transition
            >
              {({ TransitionProps }) => (
                <Fade {...TransitionProps} timeout={350}>
                  {
                    self.state.loading?<Paper><div className={'custom-search-loading'}>加载中…</div></Paper>:
                    <Paper className={classes.list}>
                      {
                        self.state.list.length!=0?_.map(self.state.list,function(i,index){
                          return <div className={"search-item"} data-index={index} data-id={i['id']} onMouseOver={(e)=>self.onMouseOver(index)} onMouseOut={(e)=>self.onMouseOut(index)} onClick={(e)=>self.choseItem(e,i)}>
                            <div className={"search-item-info"}>
                              <div className={'search-item-info-l'}>
                                <div className={'search-item-info-i name ellipsis'} title={i['name']}>
                                  {i['name']}
                                </div>
                              </div>
                            </div>
                          </div>
                        }):<div className={'custom-search-none'}>暂无数据</div>
                      }
                    </Paper>
                  }
                </Fade>
              )}
            </Popper>
          </div>
        </div>
      </div>
    );
  }
  componentDidMount(){
  }
}
export default withStyles(styles)(CustomSearch);
