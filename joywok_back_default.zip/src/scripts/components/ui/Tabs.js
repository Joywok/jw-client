import React , {Component,Fragment} from 'react';
import {connect} from 'dva';
import {Button,TextField,Menu,Radio,Checkbox,Select,Switch,Datepicker,DatepickerTwo,
  JwAppBar,JwBottomNav,JwChips,JwDialog,JwSnackbar,JwTabs,JwTab,JwTips,JwPaper} from 'joywok-material-components';
import { createMuiTheme,MuiThemeProvider} from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';

/*
	1.传入的数据
		 let tabsData = {"id":"64b8a43e715be6a8cc52cd49423478b3","name":"首页-联系人-详细资料","type":"tabs","sub_type":"list","is_bottom":0,"default_tab":"73b006a393a3b17a87f5209f8a0bf9b3","tab_items":[{"id":"73b006a393a3b17a87f5209f8a0bf9b3","style":{"label":"详细资料","label_style":{"normal":"#9A9A9A","active":"#47515A"}},"action":[{"type":"act_jw_switchto","trigger":"ontap"}],"binding":{"type":"page","id":"5f0e7c2a0e1c6408da518f396268c5ec"}}]}
	2.使用方法
		<Tabs {...tabsData}></Tabs>
	3.触发的事件
		tabs:change:64b8a43e715be6a8cc52cd49423478b3
		传出的数据为 tab_items的单条所有数据
*/
let styles = theme =>({
	root:{
		color:'#00C78B'
	},
	tab:{
    color: '#b0b0b0',
    fontSize:15,
	}
});

class Tabs extends React.Component{
  constructor(props) {
    super(props);
    this.state = {
    }
  }
  handleChange(event,value){
  	let data = this.props;
  	let nowData = _.findWhere(this.props.options,{value:value});
  	this.props.onChange && this.props.onChange(nowData);
  }
  render(){
  	let self = this;
  	let data = this.props;
    return(
      <JwTabs
	      value={0}
	      onChange={(e,value)=>this.handleChange(e,value)}
	      value={data['value']}
	      className={self.props.classes.root}
	      textColor="primary"
	    >	
	    	{
	    		_.map(this.props.options,function(i){
	    			return <JwTab label={i["label"]} value={i['value']} classes={{
	    			}}/>
	    		})
	    	}
	    </JwTabs>
    )
  }
}

export default connect((state)=>{return state})(withStyles(styles)(Tabs));