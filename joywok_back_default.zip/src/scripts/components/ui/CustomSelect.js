// customSelect.js
import request from './../../utils/request';
import React from 'react';
import { withStyles } from '@material-ui/core/styles';

import Fade from '@material-ui/core/Fade';
import Paper from '@material-ui/core/Paper';
import Popper from '@material-ui/core/Popper';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';

const styles = theme => ({
  root: {
    width: '100%',
  },
  search: {
    position: 'relative',
    height:'46px',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: '#f7f7f7',
    marginRight: theme.spacing.unit * 2,
    marginLeft: 0,
    width: '100%',
    borderRadius: 4
  },
  searchIconC: {
    width: theme.spacing.unit * 4,
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: "#999",
    marginLeft:theme.spacing.unit * 1.5
  },
  inputRoot: {
    color: 'inherit',
    width: '100%',
  },
  inputInput: {
    marginTop:6,
    paddingTop: theme.spacing.unit,
    paddingRight: theme.spacing.unit,
    paddingBottom: theme.spacing.unit,
    paddingLeft: theme.spacing.unit * 6,
    transition: theme.transitions.create('width'),
    width: '100%',
    color: "#333",
    fontSize:14,
    lineHeight:1
  },
  list:{
    maxHeight:'300px',
    overflowY:'auto'
  }
});

class customSelect extends React.Component {
	constructor(props) {
    super(props);
    this.state = {
      open:false,
      value:'',
      loading:false,
      list:[],
      check:[],
      anchorEl:null
    }
    this.fetchTime = null
  }
  render(){
  	return (<div className="custom-select">
  		</div>)
  }
}

export default withStyles(styles)(customSelect);