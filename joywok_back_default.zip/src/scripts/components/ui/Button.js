// Checkbox.js
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
const styles = {
  container: {
    display: 'flex'
  },
  button:{
  	background: "#00C78B",
    paddingLeft: "10px",
    paddingRight: "10px",
    color:"#fff",
    textTransform:"none"
  }
};

class CustomButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }
  render() {
    let self = this;
    const { classes } = this.props;
    this.props.className = classes.input+' jw-custom-button ' + (this.props.className || '');
    return (
      <div className={'jw-custom-button-w'}>
      	<Button {...this.props} style={Object.assign({
          background:"#00C78B",
          "padding":"4px 12px",
          "color":"#fff",
          textTransform:"none",
          "fontSize":"13px"
        },this.props.style || {})} >{this.props.children}</Button>
      </div>
    );
  }
  componentDidMount(){
  }
}
export default withStyles(styles)(CustomButton);