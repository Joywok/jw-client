// Select.js
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/core/styles';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';

const styles = {
  container: {
    display: 'flex'
  }
};
const MenuProps = {
  PaperProps: {
    style: {
      background:"#fff"
    },
  },
};

class CustomSelect extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    let self = this;
    const { classes,options} = this.props;
    this.props.className = classes.input+' jw-custom-select ' + (this.props.className || '')
    this.props.MenuProps=MenuProps;
    return (
      <div className={'jw-custom-select-w'}>
        <Select {...this.props}>
	        {
	        	options.map(i => (
	            <MenuItem key={i.key} value={i.key} className={this.props.checkIcon?'has-check-icon':""}>
                {self.props.key == i['key']?this.props.checkIcon:''}
	              {i.value}
	            </MenuItem>
	          ))
          }
	      </Select>
      </div>
    );
  }
  componentDidMount(){
  }
}
export default withStyles(styles)(CustomSelect);