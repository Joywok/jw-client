// RangeInput.js
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/core/styles';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import Popper from '@material-ui/core/Popper';
import Fade from '@material-ui/core/Fade';
import Paper from '@material-ui/core/Paper';
import request from './../../utils/request';
import Loading from "../../components/ui/Loading";
import Input from '../../components/ui/Input';
import Textarea from '../../components/ui/Textarea';
// import AloneTip from 'joywok-material-components/lib/tips/aloneTip';
const styles = {
  container: {
    display: 'flex'
  }
};
class RangeInput extends React.Component {
  constructor(props) {
    super(props);
    this.id = generateMixed(16);
    this.state = {}
    
  }
  emitChange(){
    let self = this;
    let data = this.state.backupHtml;
    self.props.onChange && self.props.onChange(data)  
  }
  render() {
    let self = this;
    const { classes } = this.props;
    const { anchorEl } = this.state;
    let data = this.props;
    // console.log(this.state,'asdasdasdasdasdsadasdasdasdas');;
    // {this.state.edit?<Input className="has-border" placeholder="请输入" value={this.state.backupHtml} onChange={(e)=>self.changeInput(e)}></Input>:""}
    return (
      <div className={'jw-custom-rangeinput-w '+(this.props.className||"")+(this.state.edit?' editing':"")}>
      	<ClickAwayListener onClickAway={(e)=>this.handleClickAway(e)}>
    			<Input className=" " placeholder="请输入"></Input>
      		<div className="jw-custom-rangeinput-show">
    				<div className={"jw-custom-rangeinput "+this.id} dangerouslySetInnerHTML={{__html: this.state.value}}></div>
			        <Popper className="jw-custom-rangeinput-select" id={this.id} open={this.state.open} anchorEl={null} transition
			        	placement="bottom"
			       		style={Object.assign({
				        	position:"absolute",
				        	zIndex:'222'
				        },this.state.posi)}>
				        {({ TransitionProps }) => (
				          <Fade {...TransitionProps} timeout={350}>
				          	{
				          		self.state.loading?<Paper className="jw-custom-rangeinput-select-c"><Loading show={true}></Loading></Paper>:
				          		<Paper className="jw-custom-rangeinput-select-c">
					            </Paper>
				          	}
				          </Fade>
				        )}
				      </Popper>
    			</div>
				</ClickAwayListener>
      </div>
    );
  }
  componentDidUpdate(){
  }
}
export default withStyles(styles)(RangeInput);