import dva from 'dva';
import createLoading from 'dva-loading';
import EventEmitter from 'events';
import { Base64 } from 'js-base64';
import Underscore from 'underscore';
import { createMuiTheme } from '@material-ui/core/styles';
import request from './utils/request';
window.Underscore = Underscore;
window.onerror = function () {
  // console.log(arguments, 'onerror');
}
window.EventEmitter = EventEmitter;
window.Events = new EventEmitter();
//
let a = 'xxxxxx';
let b = 'cccccc';
window.dva = dva;
const app = dva();
window.dvaApp = app;
window.unit = 10;

window.theme = createMuiTheme({
  palette: {
    primary: {
      main: '#00C78B'
    },
    secondary: {
      main: '#00C78B',
    },
    text: {
      primary: "#494949",
    },
  },
  spacing: {
    unit: unit
  },
  button: {
    height: window.unit * 3 + 'px',
    lineHeight: 1,
    background: "#00C78B"
  }
});

app.router(require('./router'));
app.start("#root");





