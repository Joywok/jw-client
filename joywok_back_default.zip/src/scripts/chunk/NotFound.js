import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'dva';

class NotFound extends Component {
	render(){
		return(
			<div className="error-404">
	      <img src="images/empty-todos.png"/>
	      <p>哇哦 您访问的地址不存在</p>
	    </div>
		)
	}
}

function mapStateToProps() {
  return {};
}

export default connect(mapStateToProps)(NotFound);

