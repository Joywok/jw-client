import React , {Component,Fragment} from 'react';
import {connect} from 'dva';
import Form from 'jw-new-form/dist/form';
import TurnSchemaForm from 'jw-new-form/dist/schema';
import { createMuiTheme,MuiThemeProvider} from '@material-ui/core/styles';
import EventsTrigger from 'events-trigger';
let events = new EventsTrigger();

import {TextField} from "joywok-material-components"
import Input from '../components/ui/Input';
import Textarea from '../components/ui/Textarea';

import Select from '../components/ui/Select';
import CustomSelect  from '../components/ui/CustomSelect';
import Menu from '../components/ui/Menu';

import Checkbox from '../components/ui/Checkbox';
import Radio from '../components/ui/Radio';
import Button from '../components/ui/Button';
import Switch from '../components/ui/Switch';

import {JwPagination} from 'joywok-material-components';
import { CustomSelect as CustomTag } from 'joywok-material-components';

import { JsonEditor } from "joywok-material-components";
import Tabs from "../components/ui/Tabs";
import Empty from "../components/ui/Empty";
import Loading from "../components/ui/Loading";

import ExpansionPanels from "../components/ui/ExpansionPanels";


class IndexPage extends React.Component{
  constructor(props) {
    super(props);
    this.state = {
    }
  }
  render(){
    return(
      <div className="ui-demo">
      	<div className="ui-demo-i">
      		<h1>输入框</h1>
      		<h3>默认的输入框1</h3>
	      	<TextField id="standard-name" label="输入点东西吧" margin="normal" />
		      <h3>默认输入框2</h3>
	      	<Input className=" " placeholder="请输入"></Input>
	      	<h3>没有border的输入框</h3>
	      	<Input className="no-border" placeholder="请输入"></Input>
	      	<h3>带border默认输入框</h3>
	      	<Input className="has-border" placeholder="请输入"></Input>
	      	<h3>多行输入框</h3>
	      	<Textarea></Textarea>
      	</div>
      	<div className="ui-demo-i">
      		<h1>下拉框</h1>
      		<h3>Select</h3>
		      <Select value={'1'} options={[{key:'1',value:"1"},{key:'2',value:"2"},{key:'3',value:"3"}]} onChange={(e)=>{console.log(e)}}></Select>
		      <h3>Menu</h3>
		      <Menu value={'1'} options={[{key:'1',value:"1"},{key:'2',value:"2"},{key:'3',value:"3"}]} onChange={(e)=>{console.log(e)}}></Menu>
          <h3>带Icon的</h3>
          <Menu checkIcon={<i className="icon-business-check"></i>} showView={<div className="" onClick={(e)=>(console.log(this,'aaaaaa'))}>1231231</div>} value={'1'} options={[{key:'1',value:"1"},{key:'2',value:"2"},{key:'3',value:"3"}]} onChange={(e)=>{console.log(e)}}>
          </Menu>
      	</div>
      	<div className="ui-demo-i">
      		<h1>按钮</h1>
      		<h3>多选</h3>
      		<Checkbox value={["1","3"]} options={[{key:"1",value:'1'},{key:"2",value:'2'},{key:"3",value:'3'},{key:"4",value:'4'}]} onChange={(e)=>{console.log(e)}}></Checkbox>
      		<h3>单选</h3>
      		<Radio value={'1'} options={[{key:"1",value:'1'},{key:"2",value:'2'},{key:"3",value:'3'},{key:"4",value:'4'}]} onChange={(e)=>{console.log(e)}}></Radio>
      		<h3>Button</h3>
      		<Button style={{
      			width:"200px"
      		}}>xxxxx</Button>
      		<h3>滑块</h3>
      		<Switch value={true} onChange={(e)=>{console.log(e)}} label={'测试'}></Switch>
      	</div>
      	<div className="ui-demo-i">
      		<h1>其他组件</h1>
      		<h3>分页</h3>
      		<JwPagination num={51} index={1}></JwPagination>
      		<h3>标签</h3>
      		<CustomTag className={'no-border'} url={"/api/api?s={jw.form.search}"} checked={[{id:1,name:'1'},{id:2,name:'2'},{id:3,name:'3'}]} onChange={(e)=>{console.log(e)}}></CustomTag>
          <h3>Tab</h3>
          <Tabs options={[{label:"111",value:"111"},{label:"222",value:"222"}]} value={"111"} onChange={(e)=>{console.log(e)}}></Tabs>
          <h3>JSON编辑器</h3>
          <JsonEditor value={'{\n"JSON":"JSON"\n}'}   onChange={(e)=>{console.log(e)}}></JsonEditor>
          <h3>Empty组件</h3>
          <Empty emptyValue={"暂无数据哦"}></Empty>
          <h3>Loading组件</h3>
          <Loading show={true}></Loading>
          <h3>ExpansionPanels组件</h3>
          <ExpansionPanels title={"哈哈哈哈"}>
            <div className="">里面塞一点东西吧</div>
          </ExpansionPanels>
      	</div>
      </div>
    )
  }
  componentDidMount(){
    let self = this;
    setTimeout(function(){
      self.props.changeState({
        loading:false
      })
    },0)
  }
}
const theme = createMuiTheme(window.theme);
function CustomStyles(props) {
  return (
    <MuiThemeProvider theme={theme}>
      <IndexPage {...props}/>
    </MuiThemeProvider>
  );
}

export default connect((state)=>{return state})(CustomStyles);
