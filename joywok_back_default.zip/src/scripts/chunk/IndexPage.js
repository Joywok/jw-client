import React, { Component, Fragment } from 'react';
import { connect } from 'dva';
import request from '../utils/request';
import { matchRoutes, renderRoutes } from 'react-router-config'
import LinearProgress from "@material-ui/core/LinearProgress/LinearProgress";
import { createMuiTheme, MuiThemeProvider, withStyles } from '@material-ui/core/styles';
import AloneTip from 'joywok-material-components/lib/tips/aloneTip';
import { JwFullDialog, DialogFD, JwCustomDialog } from 'joywok-material-components';
const styles = {
};
class IndexPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false
    }
    this.a;
  }
  render() {
    let self = this;
    let { classes } = this.props;
    return <div>
      {
        <div className="content">
          首页<br/>
          <a href="#/ui">UI组件</a><br/>
        </div>
      }
    </div>
  }
  componentDidMount() {
    let self = this;
    setTimeout(function(){
      self.props.changeState({
        loading:false
      })
      // self.showDialog();
    },0)
  }
}

const theme = createMuiTheme(window.theme);
function CustomStyles(props) {
  return (
    <MuiThemeProvider theme={theme}>
      <IndexPage {...props} />
    </MuiThemeProvider>
  );
}

export default connect((state) => { return state })(CustomStyles);