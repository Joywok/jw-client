import request from '../utils/request';
function firstFetch(url,parame) {
  return request(url, {
    method: 'GET',
    body:parame
  });
}
export default {
	namespace: 'index',
	state: {
		loading:{
			loading:true,
			fix:true,
			hide:false
		}
	},
	reducers: {
		changeData(state,action){
      return { ...state, ...action.payload };
    }
	},
	effects: {
    *fetch({payload,dispatch}, { call, put ,select}) {
      let datas = yield select();
      let firstData = yield call(firstFetch,datas["config"]["url"],payload);
      // let firstData = firstFetch()['data'];
      let loading = datas["file"]['loading'];
      loading['loading'] = false;
      loading['hide'] = true;
      let allData = _.extend({
        loading:loading
      },firstData)
      yield put({
        type: 'changeData',
        payload: allData,
      });
    }
  },
	subscriptions: {
	},
};
