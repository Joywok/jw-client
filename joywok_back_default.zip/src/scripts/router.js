import React, { Component } from 'react';
import { connect } from 'dva';
import { Router, HashRouter, BrowserRouter, history, Redirect } from 'dva/router';
import { matchRoutes, renderRoutes } from 'react-router-config'
import dynamic from 'dva/dynamic';
import LinearProgress from "@material-ui/core/LinearProgress/LinearProgress";

module.exports = function ({ history, app }) {
  class Root extends React.Component {
    constructor(props) {
      super(props);
      window.dvaHistory = props.history;
      let urlMatch = window.location.hash.split('#')[1].split('/');
      this.state = {
        loading: true,
        header: {
        },
        sidebar: {
        },
        history,
      };
    }
    onChange() {
    }
    changeState(data) {
      this.setState(data);
    }
    render() {
      var self = this;
      return (
        <div>
          {this.state.loading ? <LinearProgress className="linear-progress" /> : ''}
          <div className="ai-content">
            <div className="ai-main">
              {renderRoutes(this.props.route.routes, {
                changeState: (data) => self.changeState(data),
                rootState: self.state
              })}
            </div>
          </div>
          <div className="animater-container"></div>
        </div>
      )
    }
    componentDidMount(){
    }
    componentDidUpdate(){
      $("body").removeClass('overflowhidden');
    }
  }
  const Index = dynamic({ app, models: () => [import('./models/Index')], component: () => { return import('./chunk/IndexPage') } });
  const NotFound = dynamic({ app, models: () => [import('./models/Index')], component: () => { return import('./chunk/NotFound') } });
  const Ui = dynamic({ app, models: () => [import('./models/Index')], component: () => { return import('./chunk/Ui') } });

  const routes = [
    {
      component: Root,
      routes: [
        {
          path: '/',
          exact: true,
          component:Index
        },
        {
          path: '/ui',
          component: Ui,
          onEnter: function () {
          }
        },
         {
          path: '*',
          component: NotFound,
          onEnter: function () {
          }
        }
      ]
    }
  ]

  return (
    <HashRouter>
      {renderRoutes(routes)}
    </HashRouter>
  );
};