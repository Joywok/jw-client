if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(searchString, position){
      position = position || 0;
      return this.substr(position, searchString.length) === searchString;
  };
}
window.Store = function(name) {// 读取本地数据 并将数据以JS对象的形式输出
  this.name = name; 
  var store = localStorage.getItem(this.name);
  this.data = (store && JSON.parse(store)) || {};// json 格式化存的数据
};
_.extend(Store.prototype, {

  // Save the current state of the **Store** to *localStorage*.
  save: function() {
    localStorage.setItem(this.name, JSON.stringify(this.data));
  },

  // Add a model, giving it a (hopefully)-unique GUID, if it doesn't already
  // have an id of it's own.
  create: function(model) {
    if (!model.id) model.id = model.attributes.id = guid();
    this.data[model.id] = model;
    this.save();
    return model;
  },

  // Update a model by replacing its copy in `this.data`.
  update: function(model) {
  	var self = this;
    this.data[model.id] = model;
    this.save();
    return model;
  },
  // Retrieve a model from `this.data` by id.
  find: function(name) {
    return this.data[model.id];
  },
  // Return the array of all models currently in storage.
  findAll: function() {
    return _.values(this.data);
  },
  // Delete a model from `this.data`, returning it.
  destroy: function(model) {
    delete this.data[model.id];
    this.save();
    return model;
  }
});

// 生成ID
var jschars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
var jschars2 = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
function generateMixed(n,type) {
  var res = "";
  for(var i = 0; i < n ; i ++) {
    var id = Math.ceil(Math.random()*(typeof(type)!="undefined"?35:61));
    res += (typeof(type)!="undefined"?jschars2[id]:jschars[id]);
  }
  return res;
}
function S4() {
  return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
};
function guid() {
  return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
};

String.prototype.LengthW = function () {
  return Math.ceil((this.replace(/[^\x00-\xff]/g, "**").length) / 2);
}

// 是否是合法的链接地址
String.prototype.isURL = function(){
  var re=/^((http|https|ftp):\/\/)?(\w(\:\w)?@)?([0-9a-z_-]+\.)*?([a-z0-9-]+\.[a-z]{2,6}(\.[a-z]{2})?(\:[0-9]{2,6})?)((\/[^?#<>\/\\*":]*)+(\?[^#]*)?(#.*)?)?$/i;
  return re.test(this);
}
String.prototype.IsURL = function(){
  var re =  /((http|ftp|https):\/\/)(([a-zA-Z0-9\._-]+\.[a-zA-Z]{2,6})|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,4})*(\/[a-zA-Z0-9\&%_\.\/-~-]*)?/
  return re.test(this)
}
// 判断域名是否合法
String.prototype.isSite = function(){
  return /^[A-Za-z0-9\-]*$/.test(this);
}


window.Store = function(name) {// 读取本地数据 并将数据以JS对象的形式输出
  this.name = name;
  var store = localStorage.getItem(this.name);
  this.data = (store && JSON.parse(store)) || {};// json 格式化存的数据
};
_.extend(Store.prototype, {

  // Save the current state of the **Store** to *localStorage*.
  save: function() {
    localStorage.setItem(this.name, JSON.stringify(this.data));
  },

  // Add a model, giving it a (hopefully)-unique GUID, if it doesn't already
  // have an id of it's own.
  create: function(model) {
    if (!model.id) model.id = model.attributes.id = guid();
    this.data[model.id] = model;
    this.save();
    return model;
  },

  // Update a model by replacing its copy in `this.data`.
  update: function(model) {
    var self = this;
    this.data[model.id] = model;
    this.save();
    return model;
  },
  // Retrieve a model from `this.data` by id.
  find: function(name) {
    return this.data[model.id];
  },
  // Return the array of all models currently in storage.
  findAll: function() {
    return _.values(this.data);
  },
  // Delete a model from `this.data`, returning it.
  destroy: function(model) {
    delete this.data[model.id];
    this.save();
    return model;
  }
});