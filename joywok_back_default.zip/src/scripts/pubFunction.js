jw.setTitle = function(title){
	$("title").html(title)
	$(".page-title").text(title);
	if(title != jw.appmaker.config.name){
		$("#menu-button").hide()
		$("#return-button").show()
	}else{
		$("#menu-button").show()
		$("#return-button").hide()
	}
}

jw.pushWebview = function(url){
	window.location.href=url; 
}

jw.newWebView = function(el,url){
	$('.animater-container').css({})
	moveElOffset = {
		left:el.offset().left,
		top:el.offset().top - (document.documentElement.scrollTop||document.body.scrollTop),
		width:el.width(),
		height:el.height()
	}
	let newEl = el.html();
	let classItem = el.attr("class")
	$('.animater-container').css(moveElOffset).removeClass('hide').html('<div class="copy-item '+classItem+'">'+newEl+'</div>');
	$('.container>.main').addClass('visibility');
	// window.aaaa = setTimeout(function(){
		window.location.href = url	
	// },10000)
}

window.newOpenPage = function(url){
	let alink = document.createElement('a');
	alink.href = url;
	alink.id="open-newpage";
	alink.target="_blank";
	alink.innerHTML = url;
	document.body.appendChild(alink);
	setTimeout(function(){
		$('#open-newpage')[0].click();
		$('#open-newpage').remove()
	},100)
}

jw.download = function(data){
	let alink = document.createElement('a');
	alink.href = data;
	alink.id="download-link";
	alink.innerHTML = data;
	document.body.appendChild(alink);
	setTimeout(function(){
		$('#download-link')[0].click();	
		$('#download-link').remove()
	},100)
}
