"use strict";
import fetch from 'dva/fetch';
import { notification } from 'antd';
import AloneTip from 'joywok-material-components/lib/tips/aloneTip';
// var base64js = require('base64-js')
// import base64js from 'base64-js';

function checkStatus(txt) {
  const error = new Error(txt);
  throw error;
}
function checkError(response, url, requestParams) {
  if (response['msg']) {
  }
}
function combineUrlParam(url, params) {
  if (params) {
    if (url.indexOf('?') != -1) {
      url += '&'
    } else {
      url += '?'
    }
  }
  let newArray = [];
  _.each(params, function (item, key) {
    if (item) {
      newArray.push(key + '=' + item)
    }
  })
  return url + '' + newArray.join('&');
}
/**
 * Requests a URL, returning a promise.
 *
 * @param  {string} url       The URL we want to request
 * @param  {object} [options] The options we want to pass to "fetch"
 * @return {object}           An object containing either "data" or "err"
 */
export default async function request(url, options) {
  let requestParams = _.extend({}, options);

  switch (options.method) {
    case 'POST':
      requestParams['headers'] = _.extend({}, requestParams['headers'], {
        'Accept': 'application/json',
        'Content-Type': 'application/json; charset=utf-8'
      })
      break;
    case 'PUT':
      requestParams['headers'] = _.extend({}, requestParams['headers'], {
        'Accept': 'application/json',
        'Content-Type': 'application/json; charset=utf-8'
      })
      break;
    case 'PATCH':
    case 'DELETE':
      // requestParams = options;
      if (typeof (options.body) != 'undefined') {
        url = combineUrlParam(url, JSON.parse(options.body));
      }
      // console.log(options.body,'asdasdasda');
      break;
    default:
      requestParams = {
        method: 'GET',

      }
      url = combineUrlParam(url, options.body);
      break;
  }

  // if(requestParams['headers']){
  //   // requestParams['headers']['cookie']='PHPSESSID=c5a2j1pg93l6ps77ekb1qel2a1'
  // }else{
  //   requestParams['headers'] = {}
  //   // requestParams['headers']['cookie']='PHPSESSID=c5a2j1pg93l6ps77ekb1qel2a1'
  // }
  requestParams['credentials'] = 'include';
  // {'Header-Field':'value'}
  // requestParams['headers'] =  {'AccessToken':'value'}
  requestParams['headers'] = _.extend({}, requestParams['headers'], { 'Access-Token': window.AccessToken, 'HTTP_ACCESS_TOKEN': window.AccessToken, "Accept-Language": window.UILanguage})
  // requestParams['headers'] = _.extend({}, requestParams['headers'], { 'Access-Token': window.AccessToken })
  // console.log(requestParams['headers'],'之前')
  // 发起请求
  const response = await fetch(url, requestParams);
  // 校验返回状态
  // checkStatus(response, url, requestParams);
  //const data = await response.json(); 
  let data = {
    "status": response.status
  };
  if (response.status == 200 || response.status == 201) {
    data = await response.json();
    const ret = {
      data,
    };
    return ret;
  }
  if (response.status == 204) {
    const ret = {
      data,
    };
    return ret;
  }

  if (response.status == 400 || response.status == 403) {
    $('.alone-tips').remove();
    let data = await response.json();
    let txt = '请求参数错误，请联系管理员'
    let a = AloneTip({ type: 'error', duration: 3000, hasclose: false, autoHideDuration: 3000, message: data.message })
    const error = new Error(txt);
    //throw error;
  }
  if (response.status == 302) {
    let data = await response.json();
    window.location.replace(data.message);
  }
  if (response.status == 401) {
    $('.alone-tips').remove();
    let txt = '未授权，用户未登录'
    let a = AloneTip({ type: 'error', duration: 3000, hasclose: false, autoHideDuration: 3000, message: txt })
    const error = new Error(txt);
    throw error;
  }
  if (response.status == 404) {
    $('.alone-tips').remove();
    let txt = '请求数据不存在，请联系管理员'
    let a = AloneTip({ type: 'error', duration: 3000, hasclose: false, autoHideDuration: 3000, message: txt })
    const error = new Error(txt);
    //throw error;
  }
  if (response.status == 409) {
    $('.alone-tips').remove();
    let txt = '数据冲突，请联系管理员'
    let a = AloneTip({ type: 'error', duration: 3000, hasclose: false, autoHideDuration: 3000, message: txt })
    const error = new Error(txt);
    throw error;
  }
  if (response.status == 500) {
    $('.alone-tips').remove();
    let data = await response.json();
    let txt = '服务器错误，请联系管理员'
    let a = AloneTip({ type: 'error', duration: 3000, hasclose: false, autoHideDuration: 3000, message: data.message })
    const error = new Error(txt);
    throw error;
  }
  // checkError(data, url, requestParams);
  // 拼装返回值


  // try {

  // }
  // catch (err) {
  //   let response = err.response;
  //   console.log('error--', response)
  //   let data = response ? await response.json() : {};
  //   if (data.message) {
  //     AloneTip({
  //       type:'error',
  //       duration:2000,
  //       hasclose:false,
  //       autoHideDuration:2000,
  //       message:data.message ? data.message : '未知错误'
  //     })
  //   }

  //   // return {
  //   //   data: {
  //   //     errcode: 'no-network',
  //   //     errmemo: '请求失败，请检查网络连接',
  //   //     errinfo: err,
  //   //     success: false,
  //   //     statusText: '请求失败，请检查网络连接'
  //   //   },
  //   //   headers: {},
  //   // }
  // }
}
