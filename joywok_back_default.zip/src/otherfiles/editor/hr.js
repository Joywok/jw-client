[
  "<blockquote tyle=\"font-size:14px;border:0px;padding:0px;margin:5px auto;white-space: normal;\"><section style=\"margin: 0.5em 0px; border-top-style: dashed; border-top-width: 1px; border-color: #4174d9; box-sizing: border-box;\"></section></blockquote>",
  "<blockquote style=\"font-size:14px;border:0px;padding:0px;margin:5px auto;white-space: normal;\"><hr style=\"margin: 0px; border: 0; border-top: 5px #4174d9 double;\"></blockquote>",
  "<blockquote style=\"font-size:14px;border:0px;padding:0px;margin:5px auto;white-space: normal;\"><hr style=\"margin: 0px; border: 0; border-top: 5px #4174d9 dotted;\"></blockquote>",
  "<blockquote style=\"font-size:14px;border:0px;padding:0px;margin:5px auto;white-space: normal;\"><hr style=\"margin: 0px; border: 0; border-top: 5px #4174d9 dashed;\"></blockquote>",
  "<blockquote style=\"font-size:14px;border:0px;padding:0px;margin:5px auto;white-space: normal;\"><hr style=\"margin: 0px; border: 0; border-top: 5px #4174d9 solid;\"></blockquote>"
]