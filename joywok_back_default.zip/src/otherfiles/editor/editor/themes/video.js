/**
 * 订阅号视频公共文件
 */
var jwplayer=jwplayer||{};

// 创建腾讯视频
jwplayer.createtencentvideo = function(mod_id,vid,width){
  var videoWidth = width ? width : window.innerWidth,
    videoHeight = parseInt(parseInt(videoWidth* (9/16) )),
    videoHeight = videoHeight > window.innerHeight ? window.innerHeight : videoHeight;

  // V2
  // var video = new tvp.VideoInfo();
  // video.setVid(vid);

  // var player = new tvp.Player();
  // player.create({
  //   width  : videoWidth,
  //   height : videoHeight,
  //   pic: tvp.common.getVideoSnapMobile(vid),
  //   video  : video,
  //   playerType: 'html5',
  //   modId  : mod_id
  // });

  // V3 腾讯最新版本
    var player = new Txplayer({
      containerId: mod_id,
      vid: vid,
      width: videoWidth,
      height: videoHeight,
      autoplay: false
    });
}

// 从classname中匹配腾讯视频id和modid
jwplayer.getmodidvid = function(classname){
  var reg = /tencent_video_w_(.*?)_end/ig,
        idstr = (reg.exec(classname))[1],
        idarr = idstr.split('_'),
        objid = idarr[0],
        vid = idarr[1];
  return {mod_id:objid,vid:vid};        
}

// 本地视频播放
jwplayer.createlocalvideo = function(obj){
  // 根据视频尺寸来放置播放按钮，以及重新计算比例
  obj.find('.ed_video_preview_btn').each(function(){
      var p = $(this).closest('.ed_video_p_w'),
        vleft = (p.width()-$(this).width())/2,
        vbottom = (p.height()-$(this).height())/2;
      // 按钮位置按实际宽度调整  
      $(this).css({'left':vleft,'bottom':vbottom}).show();
      // 视频比例重新计算
      // var cover = p.find('.ed_video_preview_img img');
      // var scale = (cover.height()/cover.width())*100+'%';
      // p.find('.ed_video_player').css('padding-bottom',scale);
  });

  // 绑定播放事件
  obj.on('click', '.ed_video_preview_btn',function(){
    var p = $(this).closest('.ed_video_p_w'),
        preview = p.find('.ed_video_preview'),
        video = p.find('video')[0];
    p.find('video').on('playing', function(){
      preview.hide();
    });
    p.find('video')[0].play();

    p.find('video')[0].addEventListener('ended', function() {
      preview.show();
      p.find('video')[0].pause();
    });
    // p.find('video')[0].addEventListener('pause', function() {
    //   preview.show();
    //   p.find('video')[0].pause();
    // });
  })
}
