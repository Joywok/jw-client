var jwpubvideotencentjs = false;
var jwpubvideojoywokjs = false;

// $.getScript("http://vm.gtimg.cn/tencentvideo/txp/js/txplayer.js",function(){
$.getScript("../public/scripts/editor/editor/themes/tvp.player_v3_jq.js",function(){
  jwpubvideotencentjs = true;
  jwpubvideonext();
})

$.getScript("../public/scripts/editor/editor/themes/video.js",function(){
  jwpubvideojoywokjs = true;
  jwpubvideonext();
})
function jwpubvideonext(){

  if(jwpubvideotencentjs && jwpubvideojoywokjs){
      $(document).ready(function(){
        // 绑定本地视频播放
        jwplayer.createlocalvideo($('body'));
        
        setTimeout(function(){
          $('p[class*="tencent_video_w_"]').each(function(){
            var videoinfo = jwplayer.getmodidvid($(this).attr('class'));
            $(this).attr('id',videoinfo.mod_id);
            createtencentvideo(videoinfo.mod_id,videoinfo.vid);
          });
        },0);
        
      });
  }

}

function restoreVideo(){
  setTimeout(function(){
    $('p[class*="tencent_video_w_"]').each(function(){
      var videoinfo = jwplayer.getmodidvid($(this).attr('class'));
      $(this).attr('id',videoinfo.mod_id);
      createtencentvideo(videoinfo.mod_id,videoinfo.vid);
    });
  },0);
}


function createtencentvideo(mod_id,vid,width){
  var videoWidth = width ? width : window.innerWidth,
    videoHeight = parseInt(parseInt(videoWidth* (9/16) )),
    videoHeight = videoHeight > window.innerHeight ? window.innerHeight : videoHeight;

  // V2版本
  // var video = new tvp.VideoInfo();
  // video.setVid(vid);

  // var player = new tvp.Player();
  // player.create({
  //   width  : videoWidth,
  //   height : videoHeight,
  //   // pic: tvp.common.getVideoSnapMobile(vid),
  //   video  : video,
  //   // playerType: 'html5',
  //   modId  : mod_id
  // });

  // V3 腾讯最新版本
    var player = new Txplayer({
      containerId: mod_id,
      vid: vid,
      width: videoWidth,
      height: videoHeight,
      autoplay: false
    });
}

