var jw = jw || {};
var UEDITOR_HOME_URL = '/public/scripts/editor/editor/';
jw.EDITOR = Backbone.View.extend({
	placeHolder: '',
	initialize: function(options){
		$.extend(this, options);
		var that = this;
		if(window.UE == undefined){
			async.parallel({
				css: function(cb){ $.get('/public/scripts/editor/editor/themes/jwpubaccount/css/jweditor.css?v='+version, function(d){ $('body').append('<style type="text/css">'+d+'</style>'); cb(null, 'css'); }); },
				config: function(cb){ $.get('/public/scripts/editor/editor/ueditor.config.js?v='+version, function(){ cb(null, 'config'); }); },
				editor: function(cb){ $.get('/public/scripts/editor/editor/ueditor.all.js?v='+version, function(){ cb(null, 'editor'); }); }
			}, function(err, ret){
				that.initEditor();
			});
		}else{
			that.initEditor();
		}
	},
	initEditor: function(){
		var that = this;
		if(this.editKey == undefined) this.editKey = 'content';
		this.id = this.editKey + Math.floor(Math.random()*100000000);
		this.$el.html('<scripts id="'+this.id+'" name="'+this.id+'" type="text/plain"></scripts>');
		if(this.toolbars == undefined){
			this.toolbars = [
				['undo', 'redo', '|', 'fontsize', '|', 'fontfamily', '|', 'blockquote', 'horizontal', '|', 'removeformat', 'formatmatch', 'link', 'unlink'],
				['bold', 'italic', 'underline', 'forecolor', 'backcolor', '|' , 'indent', '|', 'justifyleft', 'justifycenter', 'justifyright', 'justifyjustify', '|', 'rowspacingtop', 'rowspacingbottom', 'lineheight', '|', 'insertunorderedlist', 'insertorderedlist', '|', 'imagenone', 'imageleft', 'imageright', 'imagecenter']
			];
		}
		this.editor = UE.getEditor(this.id, {
			theme: 'jwpubaccount',
			toolbars: that.toolbars,
			insertorderedlist: {
				'decimal': '1,2,3...',
				'lower-alpha': 'a,b,c...',
				'upper-alpha': 'A,B,C...',
				'lower-roman': 'i,ii,iii...',
				'upper-roman': 'I,II,III...',
			},
			insertunorderedlist: {
				'circle': '',
				'disc': '',
				'square': ''
			},
			fontsize: [9, 10, 11, 12, 14, 16, 18, 20, 24, 36, 48, 72],
			elementPathEnabled: false,
			wordCount: false,
			initialFrameHeight: this.initHeight,
			autoHeightEnabled: this.autoHeight||true,
			// scaleEnabled: true,
			autoFloatEnabled: this.autoFloatEnabled||false,
			topOffset: this.topOffset||0,
			enableAutoSave: false,
			zIndex:1,
			imagePopup: false,
			autoSyncData: false
		});
		this.editor.ready(function(){
			var content = that.model.get(that.editKey);
			if( content == '' ){
				that.setPlaceHolder();
			}else{
				this.setContent( content );
				jwplayer.createlocalvideo($($("#editor_mater iframe")[0].contentWindow.document.body));
			}
			that.renderExtra();
			that.initUploader();
			that.trigger('ready');
		});
		this.editor.addListener('beforeExecCommand', function(a,b,c){
			if(b == 'inserthtml'){
				var val = this.getContentTxt();
				if(that.placeHolder == val){
					this.setContent('');
				}
			}
		});
		this.editor.addListener('contentchange', function(){
			var c = this.getContent();
			if( c!='<span style="color:#aaa">'+that.placeHolder+'</span>' && c!='<p><span style="color:#aaa">'+that.placeHolder+'</span></p>' ){
				var ym = that.model.get(that.editKey);
				if(ym!=c){
					that.model.set( that.editKey, c );
				}
			}
		});
		this.editor.addListener('focus', function(){
			var val = this.getContentTxt();
			if(that.placeHolder == val){
				this.execCommand('cleardoc');
			}
		});
		this.editor.addListener('blur', function(){
			if( !this.hasContents() ){
				that.setPlaceHolder();
			}
		});
	},
	changeModel: function(model){
		this.model = model;
		var content = this.model.get(this.editKey);
		if( _.isEmpty(content) ){
			this.setPlaceHolder();
		}else{
			this.editor.setContent( content );
			this.editor.focus(true);
			var that = this;
			$(this.editor.iframe.contentWindow.document).ready(function(){
				if(typeof that.editor.iframe.contentWindow.restoreVideo=='function'){
					that.editor.iframe.contentWindow.restoreVideo();
				}
			});
		}
		var extra = this.extra;
		if( extra!= undefined && extra.length>0 ){
			$.each(extra, function(i){
				$('#edui-editor-extra-'+extra[i].key+' input').val( model.get( extra[i].key ) );
			});
		}
	},
	setPlaceHolder: function(){
		this.editor.setContent('<span style="color:#aaa">'+ this.placeHolder +'</span>');
		// this.model.set(this.editKey, '');
	},
	bindExtraEvt: function(key, id){
		var input = $('#'+id).find('input');
		var that  = this;
		input.on('keyup', function(){
			that.model.set(key, input.val());
		});
	},
	renderExtra: function(){
		this.padding = this.padding||0;
		if(this.extra != undefined && this.extra.length>0 ){
			var toolbarsView = $(this.editor.container).find('.edui-editor-toolbarbox');
			var editorFrame = $(this.editor.container).find('.edui-editor-iframeholder');
			var extraView = $(this.editor.container).find('.edui-editor-extra');
			if(extraView.length==0){
				var that = this;
				this.extra.reverse();
				var w = toolbarsView.width() - this.padding;
				$.each(this.extra, function(i){
					var btmline = i==0?'<hr style="border-style:solid; width:'+(w+20)+'px; border-color:#eee; border-width:1px 0 0 0; margin:30px auto 20px;">':'';
					var str = '<div id="edui-editor-extra-'+that.extra[i].key+'" style="padding:30px 0 0;width:'+w+'px;margin:0 auto;"><input type="text" style="width:100%;outline:0;height:100%;font-size:'+that.extra[i].fontsize+'px; border:none; color:#333;" placeholder="'+that.extra[i].placeholder+'" value="'+that.extra[i].value+'"></div>' + btmline;
					toolbarsView.after(str);
					that.bindExtraEvt(that.extra[i].key, 'edui-editor-extra-'+that.extra[i].key);
				});
				editorFrame.width(w+16).css('margin', '0 auto');
			}
		}
	},
	uuid: function(len, radix) {
		var CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
		var chars = CHARS, uuid = [], i;
		radix = radix || chars.length;
		if(len){
			for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random()*radix];
		}else{
			var r;
			uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
			uuid[14] = '4';
			for (i = 0; i < 36; i++) {
				if (!uuid[i]) {
					r = 0 | Math.random()*16;
					uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
				}
			}
		}
		return uuid.join('');
	},
	initUploader: function(){
		this.uploadBtnId = this.uuid(5);
		var that = this;
		$('body').append('<div id="up_'+ this.uploadBtnId +'" style="display:none;position:relative;overflow:hidden;width:10px;height:10px;"><i></i></div>');
		this.uploader = new jw.uploader({
			element: $('body').get(0),
			uploadBtn: $('#up_' + this.uploadBtnId+' i'),
			// action: basurl+'/joychat/upload', avatar
			action: basurl+'/profile/cmnupfile',
			sizeLimit:jw.limitsize,
			params:{app_type:'jw_app_profile', app_id:'', type:'loginthumb'},
			secondUpload: false,
			EnterAppendEvt: function(){},
			LeaveAppendEvt: function(){},
			onSubmit: function(id, file){
				that.editor.execCommand('inserthtml', '<img id="tmp_loading_'+id+'" src="/public/images/loading.gif" />');
			},
			onProgress:function(id,name,loaded,total){
				console.log('onProgress', Math.floor(loaded/total*100) );
			},
			onComplete:function(id,fileName,responseJSON){
				that.insertImageToContent(id, responseJSON);
			}
		});
	},
    insertImageToContent: function(id, responseJSON){
		var iBody = this.editor.iframe.contentWindow.document.body;
		if(responseJSON.file_type == 'jw_n_image'){
			var img = responseJSON['link']
			// var img = responseJSON.preview.url;
			// if( responseJSON['ext_name']=='gif' ){
			// 	img = responseJSON.original.url;
			// }
			// if( (img+'').indexOf('/api2/')===0 ){
			// 	img += '&access_token=' + jw_sid;
			// }
			$(iBody).find('#tmp_loading_'+id).remove();
			this.editor.execCommand('insertimage', [{
                    src: img,
                    _src: img,
                    width: '',
                    height: '',
                    border: '',
                    floatStyle: '',
                    vspace: '',
                    title: '',
                    alt: '',
                    style: "width:" + responseJSON['width'] + "px;height:" + responseJSON['height'] + "px;"
            }]);
		}
	},
	insertImage: function(){
		$('#up_'+this.uploadBtnId+' input').click();
	},
	uploaded: false,
	tmpVideo: {},
	videoLayerHide: function(){
		$('#jw_editor_video_w, #jw_editor_video_w_bg').remove();
	},
	insertVideo: function(){
		var that = this;
		that.completevideo = false;
		that.cancelupload = false;
		that.canceldlgshow = false;
		this.videoLayerHide();
		var limitsize = i18n('label.pubsub-video-size-limit').replace('{ videosize }',jw.limitsize.formatFilesize());
		var limittypes = i18n('label.pubsub-video-type-limit').replace('{ videotypes }','MP4');
		$('body').append('<div class="jw_editor_video_w_bg" id="jw_editor_video_w_bg"></div><div class="jw_editor_video_w" id="jw_editor_video_w"><h2><span>'+i18n('label.video-select')+'</span><del id="jw_editor_video_close"></del></h2>\
			<ul class="jw_editor_tabs" id="jw_editor_tabs"><li class="cur">'+i18n('label.video-local')+'</li><li>'+i18n('label.video-link')+'</li></ul>\
			<div class="jw_editor_tab_divs" id="jw_editor_tab_divs">\
				<div class="jw_editor_tab_div">\
					<div class="ed_uploader_tip">\
						<div class="ed_uploader_tip_w">\
							<div class="ed_uploader_tip_w_l">'+i18n('label.video-upload')+'</div>\
							<div class="ed_uploader_tip_w_r">'+limitsize+'，'+limittypes+'</div>\
						</div>\
					</div>\
					<div class="ed_uploader ed_upload_wrap" id="ed_upload_wrap">\
						<div class="ed_upload_btn" id="ed_upload_btn">\
							<button type="button" class="jw-btn jw-btn4">'+i18n('label.select-file')+'</button>\
						</div>\
					</div>\
					<div class="ed_uploader ed_uploading_wrap hide" id="ed_uploading_wrap">\
						<div class="ed_uploading_tip_t">\
							<span class="ellipsis" id="ed_uploading_progress_name"></span><u>正在处理...</u><del>'+i18n('label.file-upload-cancel')+'</del><strong></strong><i id="ed_uploading_progress_ps">0%</i>\
							<div class="uploading_cancel_confirm hide">\
								<p>'+i18n('label.pubsub-video-upload-cancel')+'</p>\
								<div class="confirm_btns">\
									<button id="cancelno" type="button" class="jw-btn jw-btn4">'+i18n('label.pubsub-video-upload-continue')+'</button>\
									<button id="cancelyes" type="button" class="jw-btn jw-btn2">'+i18n('btn.sure')+'</button>\
								</div>\
							</div>\
						</div>\
						<div class="ed_uploading_progress">\
							<div class="ed_uploading_progress_bg"></div>\
							<div class="ed_uploading_progress_bar" id="ed_uploading_progress_bar"></div>\
						</div>\
						<div class="ed_uploading_tip_b">'+i18n('label.pubsub-video-uploaded')+'：<span id="ed_uploading_progress_data">0/0</span></div>\
					</div>\
					<div class="ed_uploader ed_uploaded_wrap hide" id="ed_uploaded_wrap">\
						<div class="ed_uploaded_mov">\
							<div class="ed_transload_wrap" id="ed_transload_wrap">\
								<div style="width:50px;height:50px;" class="startloading">\
									<div class="jwLoading_1"></div>\
									<div class="jwLoading_2"></div>\
									<div class="jwLoading_3"></div>\
									<div class="jwLoading_4"></div>\
								</div>\
								<div class="ed_transload_tip"><p>'+i18n('label.processing')+'</p></div>\
							</div>\
							<div class="ed_uploaded_mov_content hide" id="ed_uploaded_mov_content">\
								<div class="ed_uploaded_mov_pic" id="ed_uploaded_mov_pic">\
									<div class="ed_uploaded_mov_preview" id="ed_uploaded_mov_preview">'+i18n('label.pubsub-video-cover-making')+'</div>\
									<div class="ed_uploaded_mov_time" id="ed_uploaded_mov_time">0:00</div>\
								</div>\
								<div class="ed_uploaded_mov_name ellipsis" id="ed_uploaded_mov_name"></div>\
							</div>\
						</div>\
					</div>\
					<div class="ed_uploader_tip_btm">\
						<ul>\
							<li rel="sizeInfo">'+i18n('label.pubsub-video-size')+'\
								<div class="sizeInfo upload_video_tip">'+limitsize+'</div>\
							</li>\
							<li rel="typeInfo">'+i18n('label.pubsub-video-type')+'\
								<div class="typeInfo upload_video_tip">'+limittypes+'</div>\
							</li>\
							<li rel="timeInfo">'+i18n('label.pubsub-video-duration')+'\
								<div class="timeInfo upload_video_tip">'+i18n('label.pubsub-video-duration-limit')+'</div>\
							</li>\
						</ul>\
					</div>\
				</div>\
				<div class="jw_editor_tab_div video-link-tab-div hide">\
					<div class="video-link-input">\
                        <div class="video-link-input-title">'+i18n('label.pubsub-video-link')+'</div>\
                        <div class="video-link-input-c"></div>\
                    </div>\
                    <div class="ed_uploading_wrap hide"><div class="ed_link_uploading"></div></div>\
                    <div class="ed_uploader ed_uploaded_wrap" id="vlink_uploaded_wrap">\
						<div class="ed_uploaded_mov hide">\
							<div class="ed_uploaded_mov_pic" id="vlink_uploaded_mov_pic">\
							</div>\
							<div class="ed_uploaded_mov_name ellipsis" id="vlink_uploaded_mov_name"></div>\
						</div>\
					</div>\
				</div>\
			</div>\
			<div class="jw_editor_tab_btns">\
				<button type="button" id="ed_insert_video_btn" class="jw-btn jw-btn2 didabled" disabled="didabled">'+i18n('btn.ok')+'</button><button id="ed_insert_video_btn_cancel" type="button" class="jw-btn jw-btn4">'+i18n('btn.cancel')+'</button>\
			</div>\
		</div>');
		that.curtab = 0;
		$('#jw_editor_tabs li').unbind('click').click(function(){
			var index = $(this).index();
			$('#jw_editor_tabs li.cur').removeClass('cur');
			$(this).addClass('cur');
			$('.jw_editor_tab_div').addClass('hide');
			$('.jw_editor_tab_div').eq(index).removeClass('hide');
			that.curtab = index;
		});
		$('.ed_uploader_tip_btm li').mouseenter(function(){
			var tipobj = $('.'+$(this).attr('rel'));
			tipobj.show();
			tipobj.css('left','-'+tipobj.width()/2+'px');
		}).mouseleave(function(){
			$('.'+$(this).attr('rel')).hide();
		});

		var fileSupport = typeof File!="undefined" && typeof (new XMLHttpRequest()).upload!="undefined";
		this.moveUploader = new jw.uploader({
			element: $('#jw_editor_video_w').get(0),
			uploadBtn: $('#ed_upload_btn button'),
			action: basurl+'/joychat/pubsubvideoupload',
			params:{app_type:'jw_app_joychat', app_id:'', type:'loginthumb'},
			multiple: false,
			sizeLimit:jw.limitsize,
			allowFiletypes: ['mp4'],
			EnterAppendEvt: function(){},
			LeaveAppendEvt: function(){},
			onLoadFile: function(id, flag){
				if(flag==false){
					$('.ed_uploading_tip_t u').show();
					$('.ed_uploading_tip_t del').hide();
				}else{
					$('.ed_uploading_tip_t del').show();
					$('.ed_uploading_tip_t u').hide();
					$('.ed_uploading_tip_t strong').show().html(i18n('label.upload.bigfile.stop')).data('stop', false).click(function(){
						if( $(this).data('stop')==true ){
							$(this).data('stop', false).html(i18n('label.upload.bigfile.stop'));
							that.moveUploader.handler.continueSecXhrs(id);
						}else{
							$(this).data('stop', true).html(i18n('label.upload.bigfile.continue'));
							that.moveUploader.handler.pauseSecXhrs(id);
						}
					});
				}
			},
			onSubmit: function(id, file){
				that.tmpVideo = {};
				that.uploaded = false;
				that.canceldlgshow = true;
				$('#ed_upload_wrap').addClass('hide');
				$('#ed_uploading_wrap').removeClass('hide');
				$('#ed_uploading_progress_bar').css('width', '1px');
				$('#ed_uploading_progress_data').html('0MB/'+(file.size+'').formatFilesize() );
				$('#ed_uploading_progress_ps').html('0%');
				$('#ed_uploading_progress_name').html(file.name);
			},
			onProgress:function(id,name,loaded,total){
				var p = Math.floor(loaded/total*100);
				if(p==100){
					// that.transLoad();
					$('#ed_uploading_wrap').addClass('hide');
					$('#ed_uploaded_wrap').removeClass('hide');
					$('#ed_transload_wrap').removeClass('hide');
					$('#ed_uploaded_mov_content').addClass('hide');
				}
				$('#ed_uploading_progress_bar').css('width', p+'%');
				$('#ed_uploading_progress_data').html((loaded+'').formatFilesize() + '/'+(total+'').formatFilesize() );
				$('#ed_uploading_progress_ps').html(p+'%');
				// console.log('onProgress', Math.floor(loaded/total*100) );
				that.localvid = id;
			},
			onComplete:function(id,fileName,responseJSON){
				that.canceldlgshow = true;
				if(that.cancelupload == false){
					$('#ed_uploading_wrap').addClass('hide');
					$('#ed_uploaded_wrap').removeClass('hide');
					$('#ed_transload_wrap').addClass('hide');
					$('#ed_uploaded_mov_content').removeClass('hide');
					$('#ed_uploaded_mov_preview').css('background-image', 'url(/openfile/getfile?type=jw_video_preview&id='+responseJSON.id+')');
					$('#ed_uploaded_mov_preview').html('&nbsp;');
					$('#ed_uploaded_mov_time').html( responseJSON['media']['duration'] );
					that.uploaded = true;
					that.tmpVideo = responseJSON;
					$('#ed_insert_video_btn').removeClass('didabled').removeAttr('disabled');
					$('#ed_uploaded_mov_name').html(fileName);
				}
				that.completevideo = true;
				that.completevid = responseJSON.id;
			},
			onError: function(error){
				switch(error.type){
					case 20112 : 	error.desc = i18n('label.file-type-not-allow-upload');break;
					case 20113 : 	error.desc = i18n('label.file-size-limit');break;
					case 20114 : 	error.desc = i18n('label.file-is-empty');break;
					case 20526 : 	
						error.desc = i18n('ser.pubsub-video-duration-error');
						$('#ed_upload_wrap').removeClass('hide');
						$('#ed_uploading_wrap').addClass('hide');
						break;
					default  : 	error.desc = i18n('label.file-type-not-allow-upload');break;
				}
				new jw.FormNotice({
					text: error.desc
				});
			}
		});
		// 取消上传
		$('#ed_uploading_wrap del').unbind('click').click(function(){
			var l = $('.ed_uploading_tip_t del').offset().left;
			$('.uploading_cancel_confirm').css('left',l-$('.ed_uploading_wrap').offset().left-$('.uploading_cancel_confirm').width()/2).removeClass('hide');
		})
		
		$('#cancelno').click(function(){
			$('.uploading_cancel_confirm').addClass('hide');
		});

		$('#cancelyes').click(function(){
			that.cancelupload = true;
			$('#ed_uploading_wrap').addClass('hide');
			$('#ed_upload_wrap').removeClass('hide');
			$('.uploading_cancel_confirm').addClass('hide');
			if(that.completevideo == true){
				that.deleteVideoHandler();
			}else{
				that.moveUploader && that.moveUploader.cancel(that.localvid);
			}
			that.completevideo = false;
		});

		//网络视频input
        this.video_link_input = new jw.input({
            el:$('.video-link-input-c'),
            tip: i18n('label.pubsub-video-link-limit')
        })
        this.video_link_input.bind('change',function(str){
            that.webVideoHandler(str);
        })
        this.video_link_input.bind('keydown',function(evt){
            if(evt.keyCode == 13){
            	console.log('回车');
            }
        })
        new jw.loading($('.ed_link_uploading'));
		$('#ed_insert_video_btn').unbind('click').click(function(){
			if(that.curtab==0){
				that.insertVideoToContent();
			}else{
				that.insertWebVideoToContent();
			}
		});
		$('#ed_insert_video_btn_cancel, #jw_editor_video_close').unbind('click').click(function(){
			if(that.canceldlgshow==true){
				that.confirmcancel();
			}else{
				that.videoLayerHide();
			}
		});
	},
	// 确认取消
	confirmcancel: function(){
		var that = this;
		this._dlgcontent = $('<div class="ed_cancel_confirm_wrap">\
				<img width="104" height="88" src="/dist/images/pub/cancelvideotip.png" />\
				<h3>'+i18n('label.pubsub-video-upload-confirm')+'</h3>\
				<p>'+i18n('label.pubsub-video-upload-cancel')+'</p>\
				<div class="ed_cancel_btn_wrap">\
					<button type="button" class="btn-ok jw-btn jw-btn2">'+i18n('btn.sure')+'</button>\
					<button type="button" class="btn-cancel jw-btn jw-btn4">'+i18n('btn.cancel')+'</button>\
				</div>\
			</div>');
		this._dlg=new jw.dialog({
			style:'custom',
			content:this._dlgcontent,
			modal:true,
			CloseOnEscape:true
		});
		this._dlgcontent.find('.btn-ok').unbind('click').bind('click',function(){
			that._dlg._close();
			that.videoLayerHide();
			that.deleteVideoHandler();
		})
		this._dlgcontent.find('.btn-cancel').unbind('click').bind('click',function(){
			that._dlg._close();
		})
	},
	// 删除视频
	deleteVideoHandler: function(){
		if(this.completevideo == true){
			this.completevideo = false;
		}
		if(this.completevid){
			// 通过后台去抓取视频名称
			$.ajax({
				type:'get',
				url:basurl+'/file/removefile?id='+this.completevid,
				success: function(d){
					if(d.data && d.data.errcode){
						new jw.FormNotice({
							text: d.data.errcode+':'+d.data.errmemo
						});
					}else if(d.data){
						
					}
				}
			});
		}
	},
	// 取视频信息
	webVideoHandler: function(str){
		var that = this;
		var link_reg = /https?:\/\//g;
		var video_wrap = $('#vlink_uploaded_wrap .ed_uploaded_mov');
		if(!link_reg.test(str)){
			this.web_video = '';
			// video_wrap.empty().removeClass('show').addClass('hide');
			video_wrap.find('.tencent_video_w_'+that.objId+'_'+that.vid+'_end').remove();
			video_wrap.removeClass('show').addClass('hide');
			$('#ed_insert_video_btn').addClass('didabled').attr('disabled');
			return;
		}
		$('#ed_insert_video_btn').removeClass('didabled').removeAttr('disabled'); 
		$.ajax({
			type:'POST',
			data:{url:str},
			url:basurl+'/subscribe/getttvid',
			success: function(d){
				if(d.data){
					if(d.data.url==''){
						new jw.FormNotice({
							text: d.data.errcode+':'+d.data.errmemo
						});
					}else{
						$('#vlink_uploaded_mov_name').html(d.data.title);
						var qq_reg = /https?:\/\/v.qq.com(.*\/)?(.{11})\.html/;
						var matches = qq_reg.exec(d.data.url);
						if (matches == null){
							new jw.FormNotice({
								text: i18n('label.pubsub-video-link-error')
							});
						}else{
							that.canceldlgshow = true;
							that.vid = matches[2];
							that.objId = that.uuid(11);
							video_wrap.find('.tencent_video_w').remove();
							that.web_video = '<p class="tencent_video_w tencent_video_w_'+that.objId+'_'+that.vid+'_end" id="'+that.objId+'"></p>';
							video_wrap.removeClass('hide').addClass('show');
							video_wrap.find('.ed_uploaded_mov_pic').append(that.web_video);

							setTimeout(function(){
								jwplayer.createtencentvideo(that.objId,that.vid,video_wrap.width());
							});
						}

					}
				}
			}
		});



		// var qq_reg = /https?:\/\/v.qq.com(.*\/)?(.{11})\.html/
		// var matches = qq_reg.exec(str);
		// if (matches == null){
		// 	new jw.FormNotice({
		// 		text: i18n('label.pubsub-video-link-error')
		// 	});
		// }else{
		// 	that.canceldlgshow = true;
		// 	that.vid = matches[2];
		// 	that.objId = that.uuid(11);
		// 	video_wrap.find('.tencent_video_w').remove();
		// 	that.web_video = '<p class="tencent_video_w tencent_video_w_'+that.objId+'_'+that.vid+'_end" id="'+that.objId+'"></p>';
		// 	video_wrap.removeClass('hide').addClass('show');
		// 	video_wrap.find('.ed_uploaded_mov_pic').append(that.web_video);

		// 	console.log('that.vid:',that.vid);
		// 	setTimeout(function(){
		// 		jwplayer.createtencentvideo(that.objId,that.vid,video_wrap.width());
		// 		// 通过后台去抓取视频名称
		// 		$.ajax({
		// 			type:'POST',
		// 			data:{url:str},
		// 			url:basurl+'/subscribe/gettencentvideo',
		// 			success: function(d){
		// 				if(d.data && d.data.errcode){
		// 					new jw.FormNotice({
		// 						text: d.data.errcode+':'+d.data.errmemo
		// 					});
		// 				}else if(d.data){
		// 					console.log(d.data, 'd.data')
		// 					$('#vlink_uploaded_mov_name').html(d.data.vname);
		// 				}
		// 			}
		// 		});
		// 	},0)
			
			
		// }
		

	},
	insertVideoToContent: function(){
		if(this.uploaded!=false){
			this.editor.execCommand('inserthtml', '<p><p class="ed_video_p_w" contenteditable="false">\
				<span class="ed_video_player"><video src="/openfile/getfile?type=jw_n_video&id='+this.tmpVideo['id']+'" controls="controls"></video></span>\
				<span class="ed_video_preview">\
					<span class="ed_video_preview_img"><img src="/openfile/getfile?type=jw_video_preview&id='+this.tmpVideo['id']+'"></span>\
					<span class="ed_video_preview_btn"></span>\
				</span>\
			</p></p><p>&nbsp;</p>');
			jwplayer.createlocalvideo($($("#editor_mater iframe")[0].contentWindow.document.body));
			this.videoLayerHide();
			// $(this.editor.iframe.contentWindow.document.body).find('p:last-child').focus();
		}
	},
	insertWebVideoToContent: function(){
		if(!this.web_video) return;
		this.editor.execCommand('inserthtml', '<p><p class="tencent_video_div tencent_video_w_'+this.objId+'_'+this.vid+'_end" id="'+this.objId+'" contenteditable="false">&nbsp;</p></p><p>&nbsp;</p><p style="display:none;font-size:1px;">video</p>',true);
		$("#editor_mater iframe")[0].contentWindow.createtencentvideo(this.objId,this.vid);

		this.videoLayerHide();
	}
});























