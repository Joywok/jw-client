/**
 * 编辑头像组件
 */
(function($){

var store = new Store('Joywok:saas:login');
var cache = store.find({id:'login'});
var pf_tmp_num = {};
jw.Profile=jw.Profile||{};
jw.Profile.Container={width:432,height:324};

jw.Profile.M_Edit=Backbone.Model.extend({
	defaults:{
		img:{width:0,height:0},
		imgcontainer:{width:0,height:0},
		selarea:{top:0,left:0,width:0,height:0}
	},
	initialize:function(){
		_.bindAll(this,'initSelArea','calPreview');
		this.bind('change:imgcontainer',this.initSelArea);
	},
	// 初始化默认选择区
	initSelArea:function(){
		var container=this.get('imgcontainer'),
			width=177,height=82,top=100,left=150;
		// 如果
		if(container.width<100&&container.height<100){
			width=Math.min(container.width,container.height);
			left=container.left;
			top=container.top;
		}else{
			left=(container.width-177)/2;
			top=(container.height-82)/2;
		}
		this.set({selarea:{top:top,left:left,width:width,height:height}});
	},
	// 计算预览图参数
	calPreview:function(previewSize){
		if(!previewSize) previewSize={width: 177, height: 82};
		var selarea=this.get('selarea'),
			img=this.get('img'),
			imgcontainer=this.get('imgcontainer'),
			_zoom=imgcontainer.width/img.width,
			_zoomH=imgcontainer.height/img.height,
			rateX=(selarea.width/_zoom)/previewSize.width;
			rateY=(selarea.height/_zoom)/previewSize.height;
		return {
			width:img.width/rateX+'px',
			height:img.height/rateY+'px',
			top:-1*selarea.top/_zoom/rateY+'px',
			left:-1*selarea.left/_zoom/rateX+'px'
		};
	},
	saveEP:function(){
		var self=this,selarea=this.get('selarea'),
			img=this.get('img'),
			imgcontainer=this.get('imgcontainer'),
			_zoom=imgcontainer.width/img.width,
			_zoomH=imgcontainer.height/img.height,
			selwidth=(selarea.width/_zoom).toFixed(2),
			selheight=(selarea.height/_zoom).toFixed(2);
		var params='id='+this.get('fid') +'&width='+selwidth+'&height='+selheight+'&top='+(selarea.top/_zoomH).toFixed(2)+'&left='+(selarea.left/_zoom).toFixed(2);
		Backbone.sync('read',null,{
			url:basurl+'/pubaccount/epc?'+params,
			success:function(resp, status, xhr){
				if(typeof lite != 'undefined'){ 

				}else{
					if( typeof (store)!='undefined' && typeof (cache) !='undefined' ){ // @翟磊  需要加这个判断， 不然会报错 Mark
						store.update({id:'login',email:cache["email"],name:cache["name"],logo:resp["avatar_l"]})
					}
				}
				self.trigger('profileSucc',resp);
				$.publish('coverDone',resp);
			}
		});
	}
})
// /*
// 编辑头像页面总控
jw.Profile.EditView=Backbone.View.extend({
	initialize:function(){
		_.bindAll(this,'_onReSubmit','_onSubmit');
		this._fileResponse=$('.ep-pic-upload-w');
		this._fileUploadw=$('.ep-pic-upload');
		this._fileUploadingw=$('.ep-pic-uploading');
		this._uploaderr=$('.ep-pic-upload-err');
		this._oplayer=$('.ep-op-layer');
		this._imgmask=$('.ep-area-mask');		// 遮罩层
		this.resizebtns=$('.ep-area-move');		// 移动遮罩层 btn
		this._previewbig=$('.ep-big img');
		// this._previewsmall=$('.ep-small img');
		_.bindAll(this,'_onSubmit','_onProgress','_onComplete','SelArea','_cacheOrigin','saveEP','profileSucc','fileUploadErr');
		this._initUploader();
		this.model=new jw.Profile.M_Edit;
		this.model.bind('change:selarea',this.SelArea);
		this.model.bind('profileSucc',this.profileSucc);
		// 取消按钮
		$('#ep-cancel-btn').click(function(){
			pf_tmp_num = {};
			jw.ep_handle.close();
		})
	},
	// 拼装 uploader 参数
	_uploaderParam:function(){
		var self=this;
		return {
			element:this._fileResponse[0],
			action:basurl+'/profile/cmnupfile',
			multiple:false,
			allowFiletypes:['jpg','jpeg','png','bmp','gif'],
			params:{appid:'',apptype:'jw_app_profile',type:'avatar'},
			secondUpload: false,
			EnterAppendEvt:function(evt){
				self._fileResponse.addClass('dragging');
			},
			LeaveAppendEvt:function(evt){
				self._fileResponse.removeClass('dragging');
			},
			onSubmit:this._onSubmit,
			onProgress:this._onProgress,
			onComplete:this._onComplete,
			onError:this.fileUploadErr
		}
	},
	// 初始化上传文件按钮
	_initUploader:function(){
		this._upload=new jw.uploader(_.extend(this._uploaderParam(),{uploadBtn:$('.ep-pic-btnw button')[0]}));
	},
	// 拼装再次上传图片的按钮
	_prepareReupload:function(name,file){
		if($('.ep-desc-w').find('.jw-btn3').length==0){
			$('.ep-desc-w').html('<div class="ep-pic-btnw" title="'+i18n('label.profile-select-image')+'"><button class="jw-btn3 jw-btn">'+i18n('label.profile-change-image')+'</button></div><span>'+name+'</span>')
			this._upload=new jw.uploader(_.extend(this._uploaderParam(),{
				uploadBtn:$('.ep-desc-w .ep-pic-btnw button')[0],
				onSubmit:this._onReSubmit
				// onComplete
			}));
		}else{
			$('.ep-desc-w').find('span').html(name);
		}
	},
	// 重新上传文件
	_onReSubmit:function(id,file){
		// 1、准备上传进度显示环境
		$('.ep-pic-container').addClass('hide');
		$('.ep-pic-upload-w').removeClass('hide');
		this._onSubmit(id,file);
	},
	// 上传文件发生错误
	fileUploadErr:function(err){
		var desc='';// 描述
		if(err.type==20112) desc=i18n('label.profile-image-format-error');
		else if(err.type==20120) desc=i18n('label.profile-need-only-one');
		$('.ep-err-w').css('visibility','visible').find('span').html(desc);
		$('.ep-err-w').find('a').unbind('click').click(function(){
			$(this).closest('.ep-err-w').css('visibility','hidden');
		})
	},
	_onSubmit:function(id,file){
		pf_tmp_num[id] = true;
		var self=this;
		// trace('_onSubmit');
		// trace(id);
		// trace(file);
		this._fileUploadw.addClass('hide');
		this._fileUploadingw.removeClass('hide');
		if(jw.UploadHandlerXhr.isSupported()){
			if(file.type.indexOf('image')>=0){
				if(typeof FileReader!=="undefined"){
					this.reader && delete this.reader;
					this.reader = new FileReader();
					this.reader.onload = function(evt) {
						// console.log('1111')
						var img=self._fileUploadingw.find('img');
						img.attr('src',this.result);
						$('.pf-177-bg').addClass('hide');
						img[0].onload=function(){
							img.css(jw.PosImageCenter({width:432,height:324},{width:this.offsetWidth,height:this.offsetHeight}));
						}
					}
					this.reader.readAsDataURL(file);
					this._fileUploadingw.find('.probar-c').css('width',0);
					this._fileUploadingw.find('.probar-percent').html('0%');
				}else{
					// this._fileUploadingw.find('img').attr('src',webroot+'/dist/images/avatar/uploadimg.jpg');
					// trace(this._fileUploadingw.html());
					// this._fileUploadingw.find('img:first').attr('src',webroot+'/dist/images/loading.gif');
					// this._fileUploadingw.find('.probar-c').css('width',0);
					this._fileUploadingw.find('.probar-percent').html( i18n('btn.uploading')  );
				}
			}else{
				this._onUploadError();
			}
		}else{
			// 
			this._fileUploadingw.find('.probar-w').addClass('hide');
			var img=this._fileUploadingw.find('img');
			img.attr('src',webroot+'/dist/images/fileicon/photo_100.png');
			// img.css(jw.PosImageCenter({width:432,height:324},{width:100,height:100}));
			img.css({left:'166px',top:'50px'});
			this._fileUploadingw.append('<div style="position:absolute;top:180px;left:160px;width:122px;"><img style="float:left;margin:1px 5px 0 0;" src="'+webroot+'/dist/images/loading.gif" /><span style="color:#b0b0b0;">'+i18n('btn.uploading')+'</span></div>')
		}
	},
	_onProgress:function(id,name,loaded,total){
		// trace('_onProgress loaded['+loaded+'] total['+total+']')
		var percent=Math.round(loaded*100/total)+'%';
		this._fileUploadingw.find('.probar-c').css('width',percent);
		this._fileUploadingw.find('.probar-percent').html(percent);
	},
	_onComplete:function(id,name,response){
		if(pf_tmp_num[id]==window.undefined) return;
		if(response.data) response=response.data;
		if(response.fid){
			// 上传成功
			var self=this,
				srcimg=this._fileUploadingw.find('img'),
				css={top:srcimg.css('top'),left:srcimg.css('left'),width:srcimg.css('width'),height:srcimg.css('height')};
			var targetimg=$('.ep-pic-container').find('img');
			targetimg.css({'max-width':'432px','max-height':'324px'});
			if(jw.UploadHandlerXhr.isSupported()&&(document.documentMode!=10)){
				if(typeof FileReader!=="undefined"){
					targetimg.attr('src',srcimg.attr('src'));
					this._previewbig.attr('src',srcimg.attr('src'));
					// this._previewsmall.attr('src',srcimg.attr('src'));
					targetimg[0].onload=function(){
						css=jw.PosImageCenter({width:432,height:324},{width:parseInt(srcimg.css('width').replace('px','')),height:parseInt(srcimg.css('height').replace('px',''))});
						_.extend(css,{width:srcimg.css('width'),height:srcimg.css('height')});
						// trace(css);
						// self.model.set({fid:response.fid,img:{width:srcimg.width(),height:srcimg.height()}});
						self.model.set({fid:response.fid,img:{width:this.width,height:this.height}});
						// IE 10 特殊处理
						targetimg.css(css);
						// targetimg.css(css);
						
						$('.ep-pic-container').find('.ep-op-layer').css(css);
						css.top=0;css.left=0;
						$('.ep-pic-container').find('.ep-area-mask').css(css);
						$('.ep-pic-upload-w').addClass('hide');
						$('.ep-pic-container').removeClass('hide');
						self.model.set({
							imgcontainer:{width:parseInt(css.width.replace('px','')),height:parseInt(css.height.replace('px',''))}
						});
						self._bindMouseEvt();
					}
					$('.ep-opbar .jw-btn2').removeAttr('disabled').unbind('click').click(this.saveEP);
				}else{
					// Safari 特殊处理
					targetimg.attr('src',response.link);
					this._previewbig.attr('src',response.link);
					// this._previewsmall.attr('src',response.link);
					jw.loadimg(response.link,function(img){
						// trace('width['+img.width+'] height['+img.height+'] self.offsetWidth['+self.offsetWidth+'] self.offsetHeight['+self.offsetHeight+']')
						var scale,s_rect,
							container={width:432,height:324};
						if(img.width/img.height>container.width/container.height){
							// 以宽度算比例
							if(img.width<container.width) scale=1;
							else scale=img.width/container.width;
						}else{
							// 以高度算比例
							if(img.height<container.height) scale=1;
							else scale=img.height/container.height;
						}
						s_rect = {
							width:Math.round(img.width/scale),
							height:Math.round(img.height/scale)
						};

						css = jw.PosImageCenter(container,s_rect);
						// css = jw.PosImageCenter({width:432,height:324},s_rect);
						// trace(s_rect);
						_.extend(css,s_rect);
						self.model.set({fid:response.fid,img:{width:img.width,height:img.height}});
						targetimg.css(css);
						$('.ep-pic-container').find('.ep-op-layer').css(css);
						css.top=0;css.left=0;
						$('.ep-pic-container').find('.ep-area-mask').css(css);
						$('.ep-pic-upload-w').addClass('hide');
						$('.ep-pic-container').removeClass('hide');
						self.model.set('imgcontainer',s_rect);
						self._bindMouseEvt();
						$('.ep-opbar .jw-btn2').removeAttr('disabled').unbind('click').click(self.saveEP);
					});
				}
				
			}else{
				this._IELoadImg(response.fid,response.link);
			}
			this._prepareReupload(name,response);
		}else{
			if(response.errcode==50101){
				new jw.FormNotice({text:i18n('label.profile-image-size-error')});
				this._fileUploadw.removeClass('hide');
				this._fileUploadingw.addClass('hide');
			}
		}
	},
	_IELoadImg:function(imgid,link){
		var self=this,
			targetimg=$('.ep-pic-container').find('img');
		link=webroot+link;
		jw.loadimg(link,function(img){
			// 计算显示比例
			var container=jw.Profile.Container,scale;
			if(img.width/img.height>container.width/container.height){
				// 以宽度算比例
				scale=img.width/container.width;
			}else{
				// 以高度算比例
				scale=img.height/container.height;
			}
			var showrect={width:img.width/scale,height:img.height/scale};
			self.model.set({fid:imgid,img:{width:img.width,height:img.height}});
			var css=jw.PosImageCenter(container,showrect);
			targetimg.attr('src',img.src);
			targetimg.css(_.extend(css,{width:showrect.width+'px',height:showrect.height+'px'}));
			self._previewbig.attr('src',img.src);
			// self._previewsmall.attr('src',img.src);
			$('.ep-pic-container').find('.ep-op-layer').css(css);
			css.top=0;css.left=0;
			$('.ep-pic-container').find('.ep-area-mask').css(css);
			$('.ep-pic-upload-w').addClass('hide');
			$('.ep-pic-container').removeClass('hide');
			self.model.set({
				imgcontainer:{width:parseInt(css.width.replace('px','')),height:parseInt(css.height.replace('px',''))}
			});
			self._bindMouseEvt();
		});
		$('.ep-opbar .jw-btn2').attr('disabled',false).unbind('click').click(this.saveEP);
	},
	_onUploadError:function(){
		this._fileUploadw.addClass('hide');
		this._fileUploadingw.addClass('hide');
		this._uploaderr.removeClass('hide');
	},
	// 修改选择区域
	SelArea:function(){
		var selarea=this.model.get('selarea');
		this.posShadow();
		this.posMoveBtns();
		// 显示预览图
		this.showPreview();
	},
	// 定位遮罩层
	posShadow:function(){
		// 遮罩层定位
		var selrect=this.model.get('selarea'),
			imgcontainer=this.model.get('imgcontainer');
		this._imgmask.find('div').each(function(){
			if($(this).hasClass('ep-mask-t')) 
				$(this).css({top:0,left:0,width:'100%',height:selrect.top+'px'});
			else if($(this).hasClass('ep-mask-r')) 
				$(this).css({
					top:selrect.top+'px',
					left:(selrect.left+selrect.width)+'px',
					width:(imgcontainer.width-selrect.left-selrect.width)+'px',
					height:selrect.height+'px'
				});
			else if($(this).hasClass('ep-mask-l')) 
				$(this).css({
					top:selrect.top+'px',
					left:'0px',
					width:selrect.left+'px',
					height:selrect.height+'px'
				});
			else if($(this).hasClass('ep-mask-b')) 
				$(this).css({
					top:selrect.top+selrect.height+'px',
					left:'0px',
					width:'100%',
					height:(imgcontainer.height-selrect.top-selrect.height)+'px'
				});
		});
		// trace(selrect);
		this._oplayer.find('.ep-area-sel').css({
			width:selrect.width+'px',
			height:selrect.height+'px',
			top:selrect.top+'px',
			left:selrect.left+'px'
		});
	},
	posMoveBtns:function(){
		var self=this,selrect=this.model.get('selarea');
		this.resizebtns.each(function(i){
			if(i==0){
				// 右上角
				$(this).css({top:selrect.top-15+'px',left:(selrect.left+selrect.width-15)+'px'});
				$(this).unbind('mousedown').bind('mousedown',function(evt){
					// trace('rt mousedown');
					self._movetype=2;
					self._cacheOrigin(evt);
				});
			}else if(i==1){
				// 左下角
				$(this).css({top:selrect.top+selrect.height-15+'px',left:selrect.left-15+'px'});
				$(this).unbind('mousedown').bind('mousedown',function(evt){
					self._movetype=4;
					self._cacheOrigin(evt);
				});
			}else if(i==2){
				// 右下角
				$(this).css({top:selrect.top+selrect.height-15+'px',left:(selrect.left+selrect.width-15)+'px'});
				$(this).unbind('mousedown').bind('mousedown',function(evt){
					self._movetype=3;
					self._cacheOrigin(evt);
				});
			}else if(i==3){
				// 左上角
				$(this).css({top:selrect.top-15+'px',left:selrect.left-15+'px'});
				$(this).unbind('mousedown').bind('mousedown',function(evt){
					self._movetype=5;
					self._cacheOrigin(evt);
				});
			}
		});
	},
	// 鼠标按下时，缓存初始状态
	_cacheOrigin:function(evt){
		var rect=this.model.get('selarea');
		this._lastSelRect={top:rect.top,left:rect.left,width:rect.width,height:rect.height};
		this._lastMousePos=jw.getMousePosition(evt);
	},
	// 鼠标事件
	_bindMouseEvt:function(){
		var self=this,selrect=this.model.get('selarea'),
			imgcontainer=this.model.get('imgcontainer');;
		$('.ep-pic-container').find('.ep-area-sel').unbind('mousedown').bind('mousedown',function(evt){
			// trace('mouse down');
			self._movetype=1;
			self._cacheOrigin(evt);
		});
		
		$(document).unbind('mousemove mouseup').bind('mousemove',function(evt){
			// trace('mouse move', self._movetype);
			if(self._movetype>0){
				var pos = jw.getMousePosition(evt),
					x_move = pos.x - self._lastMousePos.x;
					y_move = pos.y - self._lastMousePos.y;
				if(self._movetype==1){
					var new_left=self._lastSelRect.left+x_move,
						new_top=self._lastSelRect.top+y_move;
					// console.log('y_move['+y_move+'] self._lastSelRect.top['+self._lastSelRect.top+']new_top['+new_top+']');
					//如果选择框左边距小于0，则设置选择框左边距为0
					if(new_left<0) new_left = 0;
					//如果选择框移出图像的右边，则重新设置选择框左边距
					else if((new_left+self._lastSelRect.width)>imgcontainer.width) 
						new_left=imgcontainer.width-self._lastSelRect.width;
					if(new_top<0) new_top=0;
					else if((new_top+self._lastSelRect.height)>imgcontainer.height)
						new_top=imgcontainer.height-self._lastSelRect.height;
						
					selrect.top=new_top;
					selrect.left=new_left;
				}else{
					var bi = 885/411;
					var new_left,new_top,newval,
						movenum=Math.abs(x_move)>Math.abs(y_move)?x_move:y_move;
					// trace('movenum ['+movenum+']')
					if(self._movetype==2){
						// 右上角
						new_left=self._lastSelRect.left;
						if(movenum==x_move){
							newval=self._lastSelRect.width+x_move;
							newvalH=self._lastSelRect.height+x_move;
							new_top=self._lastSelRect.top-x_move/bi;
						}else if(movenum==y_move){
							newval=self._lastSelRect.width-y_move;
							newvalH=self._lastSelRect.height-y_move;
							new_top=self._lastSelRect.top+y_move/bi;
						}
						
					}else if(self._movetype==3){
						// 右下角
						new_left=self._lastSelRect.left;
						new_top=self._lastSelRect.top;
						newval=self._lastSelRect.width+movenum;
						newvalH=self._lastSelRect.height+y_move;
					}else if(self._movetype==4){
						// 左下角
						if(movenum==x_move){
							new_left=self._lastSelRect.left+x_move;
							newval=self._lastSelRect.width-x_move;
							newvalH=self._lastSelRect.height-x_move;
						}else if(movenum==y_move){
							new_left=self._lastSelRect.left-y_move;
							newval=self._lastSelRect.width+y_move;
							newvalH=self._lastSelRect.height+y_move;
						}
						new_top=self._lastSelRect.top;
					}else if(self._movetype==5){
						// 左上角
						new_left=self._lastSelRect.left+x_move;
						// new_top=self._lastSelRect.top+y_move;
						new_top=self._lastSelRect.top+x_move/bi;
						newval=self._lastSelRect.width-x_move;
						newvalH=self._lastSelRect.height-y_move;
					}
					console.log((new_left+newval), imgcontainer.width, (new_top+newvalH), imgcontainer.height, 'sel');
					if(new_left<0||new_top<0||newval<32||newvalH<32||(new_left+newval)>imgcontainer.width||(new_top+newvalH)>imgcontainer.height) return;
					
					selrect.width=newval;
					selrect.height=selrect.width/bi;
					selrect.top=new_top;
					selrect.left=new_left;
					
				}

				self.model.set({selarea:selrect});
				// 遮罩层定位
				self.posShadow();
				self.posMoveBtns();
				self.showPreview();
			}
		}).bind('mouseup',function(evt){
			// trace(self._movetype, 'up')
			if(self._movetype>0) self._movetype=0;
		})
	},
	// 显示预览图
	showPreview:function(){
		this._previewbig.css(this.model.calPreview({width: 177, height: 82}));
		// this._previewsmall.css(this.model.calPreview(50));
	},
	// 保存头像
	saveEP:function(evt){
		var target = $(evt.currentTarget);
		target.attr({disabled:'disabled'}).html( i18n('btn.saving') );
		this._imgmask.css({zIndex:50});
		this.model.saveEP();
	},
	// 更新头像成功
	profileSucc:function(data){
		// console.log('xxxxxx')
		// 更新页面中所有自己的头像
		// 小头像
		this._imgmask.css({zIndex:36});
		$('.pf-177-bg').addClass('hide');
		// $('img[vcard-data="user:'+selfinfo.id+'"]').attr('src',data.avatar_s);
		// $('img.owner-pf').attr('src',data.avatar_s);
		// 大头像
		// $('img.pf-200[action-data="'+selfinfo.id+'"]').attr('src',data.avatar_l);
		// $('.pw-avatar img').attr('src',data.avatar_l);
		// $('.timeline-svc-avatar img[vcard-data="user:'+selfinfo.id+'"]').attr('src',data.avatar_s);
		jw.ep_handle && jw.ep_handle.close();
	},
	// 当对象删除时，需要去除拖拽事件的绑定
	destory:function(){
		delete this._upload;
	}
})

// */
}(jQuery))

$(function(){
	new jw.Profile.EditView({el:$('.ep-pic-w')})
})