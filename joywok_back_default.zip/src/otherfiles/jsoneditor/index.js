module.exports = require('./dist/jsoneditor')
