const path = require('path');
const webpack = require('webpack');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
module.exports = {
  // return{
  entry: {
    'scripts/index': ['babel-polyfill', path.resolve(__dirname, 'src/scripts/index.js')],
    'scripts/router': ['babel-polyfill', path.resolve(__dirname, 'src/scripts/router.js')],
  },
  // devtool: 'source-map',
  // devtool:'cheap-source-map',
  // mode: 'production',
  output: {
    path: path.resolve(__dirname, 'build'),
    filename: '[name].js',
    chunkFilename: "scripts/chunks/[name].js?v=[chunkhash:8]",
    // 为生产环境打包代码时，需把publicpath打开
    // publicPath: '/console/'
  },
  resolve: {
    modules: ['node_modules', path.join(__dirname, './node_modules')],
    extensions: ['.web.js', '.jsx', '.js']
  },
  module: {
    //加载器配置
    rules: [
      {
        test: /\.js$/,
        use: {
          loader: 'babel-loader',
        },
        include: path.join(__dirname, './src'),
        exclude: /node_modules/
      }, {
        test: /\.xml$/,
        use: ['xml-loader']
      }, {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'],
      }, {
        test: /.scss$/,
        use: ['style-loader', 'css-loader', 'sass-loader'],
      }, {
        test: /.less$/,
        use: ['style-loader', 'css-loader', 'less-loader'],
      }, {
        test: /\.(png|jpg)$/,
        use: ['url-loader?limit=8192']
      }, {
        test: /\.svg$/,
        use: ['file-loader'],
      }
    ]
  },
  plugins: [
    new webpack.DefinePlugin({ "global.GENTLY": false }),
    new webpack.DefinePlugin({ 'process.env': { 'NODE_ENV': '"production"' } })
  ],
  externals: {
    jquery: "window.$"
  },
  optimization: {
    minimizer: [new UglifyJsPlugin()],
  },
  devServer: {
    contentBase: path.resolve(__dirname, 'src'),
    historyApiFallback: true,
    hot: true,
    open: true,
    inline: true,
    proxy: {
      '/ceshi/*': {
        target: "https://aiapi.joywok.com:8452",
        changeOrigin: true,
        pathRewrite: { "^/ceshi": "" },
        secure: false,
      },
      '/api/gauss/files': {
        target: "http://192.168.1.17",
        // target: "https://192.168.1.241:5282",
        // target: "https://staging-gauss.joywok.com",
        changeOrigin: true,
        pathRewrite: { "^/ceshi": "" },
        secure: false,
      },
      '/api/*': {
        target: "https://aiapi.joywok.com:8452",
       // target: "https://staging-gauss.joywok.com",
        changeOrigin: true,
        pathRewrite: { "^/ceshi": "" },
        secure: false,
      },
      '/file/*': {
        target: "https://aiapi.joywok.com:8452",
        changeOrigin: true,
        secure: false,
      },
      '/openfile/*': {
        target: "http://192.168.1.17",
        changeOrigin: true,
        secure: false,
      },
      '/dist/joywok-web/*': {
        target: "http://192.168.1.17",
        changeOrigin: true,
        secure: false,
      },
      '/dist/*': {
        target: "http://192.168.1.17",
        changeOrigin: true,
        secure: false,
      },
      '/public/*': {
        target: "http://192.168.1.17",
        changeOrigin: true,
        secure: false,
      },
      '/v3/geocode/*': {
        target: "https://restapi.amap.com",
        changeOrigin: true,
        secure: false,
      },
      '/test/appmaker/*': {
        target: "https://aiapi.joywok.com:8452",
        changeOrigin: true,
        secure: false
      }

    }
  }
};
