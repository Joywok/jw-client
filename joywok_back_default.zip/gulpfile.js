let gulp = require('gulp');//引入gulp
let del = require('del');//引入删除文件
let imagemin = require('gulp-imagemin');
let pngquant = require('imagemin-pngquant');
let htmlmin = require('gulp-htmlmin');
let $ = require('gulp-load-plugins')();
let debug = require('gulp-debug');
let useref = require('gulp-useref');
let uglify = require('gulp-uglify');
let minifycss = require('gulp-minify-css');
let gulpif = require('gulp-if');
let autoprefixer = require('gulp-autoprefixer'); // 引入css样式自动加浏览器前缀功能
let express = require('express');
let router = express.Router();
var through = require('through2');
var runSequence = require('gulp-sequence');  
var base64Img = require('base64-img');
var fz = 41.4;
var version=Math.floor(Math.random()*10000);
gulp.task('css', ()=>{
  // 编译css
  var sass = require('gulp-ruby-sass');
  var concat = require('gulp-concat');
  return sass(['src/scss/**/*.scss'], {
    style: 'expanded',
    precision: 10
  })
    .pipe(autoprefixer({
      browsers: ['last 2 versions', 'Android >= 4.0'],
      cascade: true,
      remove: true
    }))
    .on('error', console.error.bind(console))
    .pipe(gulp.dest('src/styles'))
    .pipe(gulp.dest('build/styles'));
});

gulp.task('styles:sass', () => {
  var sass = require('gulp-ruby-sass');
  return sass(['src/scss/**/*.scss'], {
    style: 'expanded',
    precision: 10
  })
    .on('error', console.error.bind(console))
    .pipe(gulp.dest('src/styles'))
    .pipe(gulp.dest('build/styles'))
    .pipe($.size({ title: 'build/styles' }));
});

// 压缩图片
gulp.task('mini',['spriter'], () => {
  return gulp.src('src/images/**/*')
    .pipe(imagemin({
      progressive: true,
      svgoPlugins: [{ removeViewBox: false }],
      use: [pngquant()]
    }))
    .pipe(gulp.dest('build/images'));
})
// 合并routers中路由信息,处理假数据

// 压缩css html
gulp.task('html', () => {
  return gulp.src('src/index.html')
    .pipe(useref({ searchPath: '{src,test}' }))
    .pipe(gulpif('*.css', minifycss()))
    // 输出路径在html中指定
    .pipe(debug())
    // js混淆交给webpack来做
    .pipe(gulpif('*.js', uglify().on('error', function (err) {
      gutil.log(gutil.colors.red('[Error]'), err.toString());
    })))
    .pipe(gulp.dest('build/'));
})

// 拷贝打包完成的目录到joywok项目中
gulp.task('copy', () => {
  gulp.src('build/**/*')
    .pipe(gulp.dest('../../../dist/joywok-web/'));
});
gulp.task('copyotherfile', () => {
  return gulp.src('src/otherfiles/*')
    .pipe(gulp.dest('build/otherfiles/'));
})
gulp.task('watch', function(){
  gulp.watch(['src/images/icons/**'], ['spriter']);
  gulp.watch(['src/scss/**/*.scss'], ['styles:sass']);
  gulp.watch(['src/scripts/i18n.js'], ['i18n']);
})

const js_to_css = function (obj) {
  let _decode = [];
  let _css = "";
  for (n in obj) {
    _decode.push({ selector: n, styles: obj[n], number_of_objs: 0 })
  }
  while (_decode.length > 0) {
    var selector = _decode[0].selector;
    var styles = _decode[0].styles;
    _css += "\n\r" + selector + " {";
    for (var n in styles) {
      if (styles.hasOwnProperty(n)) {
        if (typeof styles[n] === "string") {
          _css += n + ": " + styles[n] + "; ";
        } else {
          const _index = _decode[0].number_of_objs + 1;
          _decode.splice(_index, 0, { selector: selector + " " + n, styles: styles[n], number_of_objs: 0 })
          _decode[0].number_of_objs++;
        }
      }
    }
    _css += "}  ";
    _decode.splice(0, 1);
  }
  return _css;
}
gulp.task('spriter',()=>{
  const spritesmith = require('gulp.spritesmith');
  let key = 0;
  return gulp.src('src/images/icons/**')
        .pipe(through.obj(function(file,enc,cb){
          if(file.relative && file.relative.indexOf('.')=='-1'){
            gulp.src('src/images/icons/'+file.relative+'/*.png')
              .pipe(spritesmith({
                  imgName:'src/images/'+file.relative+'_sprite.png',  //保存合并后图片的地址
                  cssName:'src/scss/'+file.relative+'_sprite.scss',   //保存合并后对于css样式的地址
                  padding:20,
                  algorithm:'top-down',
                  cssTemplate:function(data){
                    var mobileSpriteObj = {};
                    var webSpriteObj = {};
                    data.sprites.forEach(function (sprite) {
                      var name = '.icon-'+file.relative+'-'+sprite.name
                      var base64Data = base64Img.base64Sync(process.cwd()+'/src/images/icons/'+file.relative+'/'+sprite.name+'.png');
                      // web端px布局的
                      let newWebData = {
                        "display":"inline-block",
                        "background-image": 'url('+base64Data+')',
                        "background-size":"cover",
                        "background-repeat":'no-repeat',
                        "width":((parseInt(sprite.px.width.replace("px",'')))/2+'px'),
                        "height":((parseInt(sprite.px.height.replace("px",'')))/2+'px')
                      }
                      webSpriteObj[name] = newWebData;
                      delete sprite.name;
                    });
                    return js_to_css(webSpriteObj);
                  }
              }))
            .pipe(gulp.dest('.'));
            this.push(file);
          } else {
            if(key == 0){
              let spriteData = gulp.src('src/images/icons/*.png')
              .pipe(spritesmith({
                  imgName:'src/images/sprite.png',  //保存合并后图片的地址
                  cssName:'src/scss/sprite.scss',   //保存合并后对于css样式的地址
                  padding:20,
                  algorithm:'top-down',
                  cssOpts: Object.assign(
                    {
                       base64: true
                    }
                  ),
                  cssTemplate:function(data){
                    var spriteObj = {};
                    data.sprites.forEach(function (sprite) {
                      var base64Data = base64Img.base64Sync(process.cwd()+'/src/images/icons/'+sprite.name+'.png');
                      let newData = {
                        "display":"inline-block",
                        "background-image": 'url('+base64Data+')',
                        "background-size":"cover",
                        "background-repeat":'no-repeat',
                        "width":((parseInt(sprite.px.width.replace("px",'')))/2+'px'),
                        "height":((parseInt(sprite.px.height.replace("px",'')))/2+'px')
                      }
                      var name = '.icon-'+sprite.name;
                      spriteObj[name] = newData;
                      delete sprite.name;
                    });
                    return js_to_css(spriteObj);
                  }
              }))
              .pipe(gulp.dest('.'));
              this.push(file);
              key = 1;
            }
          }
          cb();
        }));
})
gulp.task('i18n', function(){
  return gulp.src('src/scripts/i18n.js')
    .pipe(gulp.dest('build/scripts/'));
})

gulp.task('default', runSequence('copyotherfile',"styles:sass",'i18n', 'watch'));
gulp.task('publish', runSequence('copyotherfile','mini',"styles:sass",'i18n','html'))

