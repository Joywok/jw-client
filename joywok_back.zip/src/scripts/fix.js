if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(searchString, position){
      position = position || 0;
      return this.substr(position, searchString.length) === searchString;
  };
}
window.Store = function(name) {
  this.name = name; 
  var store = localStorage.getItem(this.name);
  this.data = (store && JSON.parse(store)) || {};
};
_.extend(Store.prototype, {
  save: function() {
    localStorage.setItem(this.name, JSON.stringify(this.data));
  },

  create: function(model) {
    if (!model.id) model.id = model.attributes.id = guid();
    this.data[model.id] = model;
    this.save();
    return model;
  },

  update: function(model) {
  	var self = this;
    this.data[model.id] = model;
    this.save();
    return model;
  },

  find: function(name) {
    return this.data[model.id];
  },

  findAll: function() {
    return _.values(this.data);
  },

  destroy: function(model) {
    delete this.data[model.id];
    this.save();
    return model;
  }

});

// 生成ID
var jschars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
function generateMixed(n) {
  var res = "";
  for(var i = 0; i < n ; i ++) {
    var id = Math.ceil(Math.random()*61);
    res += jschars[id];
  }
  return res;
}

//获取指定时间0:0:0的时间戳
window.getNowDate = function(data){
  if(data){
    var date = new Date(data); //获取当前Date对象
  }else{
    var date = new Date(); //获取当前Date对象
  }
  //var date = new Date('2020/10/10 11:22:33'); //获取指定时间的Date对象，这里只能用"2020/10/10"格式，其他格式如"2020-10-10"浏览器兼容性不好
  date.setHours(0);
  date.setMinutes(0);
  date.setSeconds(0);
  date.setMilliseconds(0);
  return (date.getTime()/1000)
}
