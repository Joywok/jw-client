import 'babel-polyfill';
import dva from 'dva';
import createLoading from 'dva-loading';
const app = dva();
window.dvaApp = app;
window.app = app;
NProgress.configure({ showSpinner: false });
NProgress.start();


window.id = window.generateMixed(16);
window.upTabsData = function(namespace,type,data){
	if(type == 'publish'){
		let datas = {
			events:namespace,
			uid:window.id,
			type:'publish',
			data:_.extend({},data),
		}
		jw.shareData(datas)
	}else if(type=='cache'){
		let datas = {
			namespace:namespace,
			uid:window.id,
			type:type || 'publish',
			id:'tab:cache',
			data:data,
		}
		window.localstore = new Store('Joywok:cache:tabs:'+namespace);
		window.localstore.update(datas);
	}
}
window.subShareData = function(data){
	if(typeof(data) == 'string'){
		data = JSON.parse(data);
	}
	if(data['uid']!=window.id){
		if(data['type'] == 'publish'){
			console.log(data['events'],data['data'],'events');
			PubSub.publish(data['events'],data['data']);
		}
	}
}

<%jssdk-config%>







