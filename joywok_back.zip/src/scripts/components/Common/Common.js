// xml 转 string
function xmlToString(xmlData) {  
    var xmlString;  
    //IE  
    if (window.ActiveXObject){  
        xmlString = xmlData.xml;  
    }  
    // code for Mozilla, Firefox, Opera, etc.  
    else{  
        xmlString = (new XMLSerializer()).serializeToString(xmlData);  
    }  
    return xmlString;  
} 
// 加载xml
function loadXMLDoc(dname) {
    let xhttp,
        loadXMLDoc
    if(window.XMLHttpRequest) {
         xhttp = new XMLHttpRequest();
    } else {
        loadXMLDoc
        xhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xhttp.open("GET", dname, false);
    xhttp.send();
    return xhttp.responseXML;
}
export {xmlToString,loadXMLDoc}