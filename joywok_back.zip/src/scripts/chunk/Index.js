import React , {Component} from 'react';
import {connect} from 'dva';
import { Router,hashHistory,browserHistory} from 'dva/router';
class Index extends Component{
  render(){
    var self=this;
    return(
        <div className="Index">
        	<div class="init-container">
				    <div class="init-avatar"></div>
				    <div class="init-name">Hello Developer</div>
				    <div class="init-title">
				      <img src="images/init.png" class="init-img"/>    
				    </div>
				  </div>
        </div>
      );
  }
}

export default connect((state)=>{return state})(Index);
