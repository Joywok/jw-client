import React , {Component} from 'react';
import {connect} from 'dva';
import { Router,hashHistory,browserHistory} from 'dva/router';
class Index extends Component{
  render(){
    var self=this;
    return(
        <div className="Index">
        	这是一个Demo
        </div>
      );
  }
}

export default connect((state)=>{return state})(Index);
