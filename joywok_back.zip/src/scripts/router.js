import React, { Component} from 'react';
import PropTypes from "prop-types";
import { Router,hashHistory,browserHistory} from 'dva/router';
import NotFound from './chunk/NotFound';
const registerModel = (app, model)=>{
  if (!(app._models.filter(m => m.namespace === model.namespace).length === 1)) {
    app.model(model)
  }
}

module.exports = function({hashHistory,app}){
  const routeConfig = [
    {
      path:'/',
      indexRoute: {
        getComponents(location, callback) {
          require.ensure([], function (require) {
            callback(null, require('./chunk/Index')["default"]);
          },'Index')
        },
        onEnter:function(){
        },
      },
      getChildRoutes(partialNextState, cb) {
        require.ensure([], (require) => {
          cb(null,[
          ])
        })
      }
    },{
      path: '*',
      component: NotFound,
      onEnter:function(){
        alert(1);
      }
    }
  ]
  return (
    <Router routes={routeConfig} history={hashHistory}/>
  );
};