import {xmlToString,loadXMLDoc} from './../components/Common/Common';
import fetch from 'dva/fetch';
import async from './../services/request';
export default{
  namespace:'IndexPage',
  state:{
  },
  reducers:{
  },
  effects:{
  },
  reducers:{
  }
}